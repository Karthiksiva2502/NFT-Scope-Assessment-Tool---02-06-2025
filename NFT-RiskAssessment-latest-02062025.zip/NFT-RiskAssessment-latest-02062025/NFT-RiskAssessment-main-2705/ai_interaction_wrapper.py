"""
AI Interaction Wrapper for NFT Risk Assessment Tool
Wraps existing AI functions to add comprehensive logging and transparency.
"""

import time
import json
from typing import Dict, List, Optional, Any
from core.ai_interaction_logger import ai_logger, get_user_identifier, get_session_identifier

class AIInteractionWrapper:
    """
    Wrapper class that adds logging to all AI interactions while maintaining 
    backward compatibility with existing functions.
    """
    
    @staticmethod
    def log_and_call_openai(
        interaction_type: str,
        prompt: str,
        api_function,
        model_used: str = None,
        context_data: Dict = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Generic wrapper for OpenAI API calls with comprehensive logging.
        
        Args:
            interaction_type: Type of AI interaction
            prompt: The prompt being sent to AI
            api_function: The actual API function to call
            model_used: AI model being used
            context_data: Additional context information
            **kwargs: Arguments to pass to the API function
            
        Returns:
            Response from AI with logging metadata
        """
        session_id = get_session_identifier()
        user_id = get_user_identifier()
        start_time = time.time()
        
        try:
            # Call the actual API function
            response = api_function(prompt, **kwargs)
            
            # Calculate response time
            response_time_ms = int((time.time() - start_time) * 1000)
            
            # Determine if successful
            success = response is not None and "error" not in response
            error_message = response.get("error") if isinstance(response, dict) else None
            
            # Extract response text for logging
            response_text = json.dumps(response) if isinstance(response, dict) else str(response)
            
            # Log the interaction
            interaction_id = ai_logger.log_interaction(
                session_id=session_id,
                user_identifier=user_id,
                interaction_type=interaction_type,
                prompt=prompt,
                response=response_text,
                model_used=model_used,
                context_data=context_data,
                metadata={
                    'function_name': api_function.__name__,
                    'kwargs': {k: str(v) for k, v in kwargs.items()},
                    'interaction_id': None  # Will be updated after logging
                },
                response_time_ms=response_time_ms,
                success=success,
                error_message=error_message
            )
            
            # Add logging metadata to response
            if isinstance(response, dict):
                response['_ai_interaction_id'] = interaction_id
                response['_logged_at'] = time.time()
            
            return response
            
        except Exception as e:
            # Log failed interaction
            response_time_ms = int((time.time() - start_time) * 1000)
            
            interaction_id = ai_logger.log_interaction(
                session_id=session_id,
                user_identifier=user_id,
                interaction_type=interaction_type,
                prompt=prompt,
                response=None,
                model_used=model_used,
                context_data=context_data,
                metadata={
                    'function_name': api_function.__name__,
                    'kwargs': {k: str(v) for k, v in kwargs.items()},
                    'exception_type': type(e).__name__
                },
                response_time_ms=response_time_ms,
                success=False,
                error_message=str(e)
            )
            
            # Re-raise the exception
            raise e

# Wrapper functions for specific AI interactions

def wrapped_requirement_analysis(requirement_text: str, context: Dict, api_key: str) -> Dict[str, Any]:
    """
    Wrapped version of requirement analysis with proper structured prompt following the format:
    - Application Overview: {Application overview content}
    - Contextual Information: {Q&A about the Application Requirement}  
    - Requirement text/file Upload contents: {All requirement information}
    - Action to AI model: Hey, analyze all the information provided above and generate the proper Scope Assessment Result using it. If you have any additional questions needs to be answered, Ask them in a single statement includes all questions/information to want further.
    """
    
    def _internal_analysis(prompt_text, **kwargs):
        # Implement AI analysis directly to avoid circular import
        import openai
        
        try:
            client = openai.OpenAI(api_key=api_key)
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are an expert requirement analyst specializing in scope assessment and risk analysis. Analyze the provided information and generate a comprehensive scope assessment result. If you need additional information, ask for it in a single comprehensive statement."},
                    {"role": "user", "content": prompt_text}
                ],
                temperature=0.3,
                max_tokens=2000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"Error in analysis: {str(e)}"
    
    # Build the structured prompt following the exact format specified
    structured_prompt = ""
    
    # 1. Application Overview section
    application_overview = context.get('Application Overview', '')
    if application_overview and application_overview.strip():
        structured_prompt += f"Application Overview: {application_overview}\n\n"
    else:
        structured_prompt += "Application Overview: No specific application overview provided.\n\n"
    
    # 2. Contextual Information section (Q&A format)
    structured_prompt += "Contextual Information: "
    
    if context:
        # Convert context to Q&A format
        qa_items = []
        
        # Define question mappings for better Q&A format
        question_mappings = {
            'project_name': 'What is the project name?',
            'change_type': 'What type of change is being implemented?',
            'component_name': 'Which component is being modified?',
            'components_involved': 'What components are involved in this change?',
            'customization_level': 'What is the level of customization required?',
            'channel_impact': 'Which channels will be impacted?',
            'performance_issues': 'Are there any known performance issues?',
            'business_disruption': 'What is the potential business disruption?',
            'contingency_plans': 'What contingency plans are in place?',
            'assessment_coverage': 'What areas should the assessment cover?',
            'ui_volume': 'What is the expected UI volume/load?',
            'ui_response_time': 'What are the UI response time requirements?',
            'backend_volume': 'What is the expected backend volume/load?',
            'backend_response_time': 'What are the backend response time requirements?',
            'batch_volume': 'What is the expected batch processing volume?',
            'batch_response_time': 'What are the batch processing time requirements?',
            'growth_rate': 'What is the expected growth rate?',
            'infrastructure_changes': 'Are there any infrastructure changes planned?',
            'third_party_involvement': 'Are there any third-party systems involved?'
        }
        
        for key, value in context.items():
            if key != 'Application Overview' and value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...', '']:
                # Get the question or create a generic one
                question = question_mappings.get(key, f"What is the {key.replace('_', ' ')}?")
                
                # Format the value
                if isinstance(value, list):
                    answer = ', '.join(str(v) for v in value if v)
                else:
                    answer = str(value)
                
                qa_items.append(f"Q: {question} A: {answer}")
        
        if qa_items:
            structured_prompt += " ".join(qa_items)
        else:
            structured_prompt += "Limited contextual information available."
    else:
        structured_prompt += "No specific contextual information provided."
    
    structured_prompt += "\n\n"
    
    # 3. Requirement text/file Upload contents section
    structured_prompt += f"Requirement text/file Upload contents: {requirement_text}\n\n"
    
    # 4. Action to AI model section
    structured_prompt += "Action to AI model: Hey, analyze all the information provided above and generate the proper Scope Assessment Result using it. If you have any additional questions needs to be answered, Ask them in a single statement includes all questions/information to want further."
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="requirement_analysis",
        prompt=structured_prompt,
        api_function=_internal_analysis,
        model_used="gpt-4o",
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()),
            'has_application_overview': bool(context.get('Application Overview', '').strip()),
            'context_items_count': len([k for k, v in context.items() if v and str(v).strip() and str(v).lower() != 'n/a']),
            'function': 'requirement_analysis',
            'structured_prompt_length': len(structured_prompt)
        }
    )

def wrapped_generate_ai_questions(requirement_text: str, context: Dict, api_key: str) -> str:
    """
    Legacy wrapper for backwards compatibility. 
    Now redirects to the new structured requirement analysis and extracts the response.
    """
    result = wrapped_requirement_analysis(requirement_text, context, api_key)
    
    # Extract just the response content for backwards compatibility
    if isinstance(result, dict):
        if 'response' in result:
            return result['response']
        elif 'choices' in result and len(result['choices']) > 0:
            return result['choices'][0].get('message', {}).get('content', str(result))
        else:
            return str(result)
    else:
        return str(result)

def wrapped_get_gpt_assessment(prompt: str, api_key: str, model: str = "gpt-4o") -> Dict[str, Any]:
    """Wrapped version of get_gpt_assessment with logging."""
    
    def _internal_get_assessment(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from core import gpt_logic
        return gpt_logic.get_gpt_assessment(prompt, api_key)
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="risk_assessment",
        prompt=prompt,
        api_function=_internal_get_assessment,
        model_used=model,
        context_data={
            'prompt_length': len(prompt),
            'function': 'get_gpt_assessment'
        }
    )

def wrapped_analyze_requirement_quality(requirement_text: str, context: Dict, api_key: str, model: str = "gpt-4o") -> Dict[str, Any]:
    """Wrapped version of analyze_requirement_quality with logging."""
    
    def _internal_analyze_quality(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from core import req_quality_checker
        return req_quality_checker.analyze_requirement_quality(requirement_text, context, api_key, model)
    
    prompt_for_logging = f"""
    Requirement Text: {requirement_text}
    Context: {json.dumps(context, default=str)}
    """
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="quality_analysis",
        prompt=prompt_for_logging,
        api_function=_internal_analyze_quality,
        model_used=model,
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()),
            'function': 'analyze_requirement_quality'
        }
    )

def wrapped_generate_embedding(text: str, api_key: str) -> List[float]:
    """Wrapped version of generate_embedding with logging."""
    
    def _internal_generate_embedding(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from core import chroma_logic
        return chroma_logic.generate_embedding(text, api_key)
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="embedding_generation",
        prompt=text,
        api_function=_internal_generate_embedding,
        model_used="text-embedding-3-small",
        context_data={
            'text_length': len(text),
            'function': 'generate_embedding'
        }
    )

def get_ai_transparency_report(session_id: str = None) -> Dict[str, Any]:
    """
    Generate a transparency report showing what was sent to AI and what was received.
    This helps users understand exactly what information was shared with AI.
    """
    if session_id is None:
        session_id = get_session_identifier()
    
    return ai_logger.validate_interaction_transparency(session_id)

def get_current_session_interactions() -> List[Dict]:
    """Get all AI interactions for the current session."""
    session_id = get_session_identifier()
    return ai_logger.get_session_interactions(session_id)

def export_ai_interaction_logs(output_format: str = "json", filters: Optional[Dict] = None) -> str:
    """Export AI interaction logs for audit purposes."""
    return ai_logger.export_interactions(output_format, filters)

def get_ai_interaction_summary(hours: int = 24) -> Dict[str, Any]:
    """Get summary statistics of AI interactions."""
    return ai_logger.get_interaction_summary(hours)
