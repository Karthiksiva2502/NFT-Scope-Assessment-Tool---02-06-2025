# Core module for NFT Risk Assessment Tool
# This module contains all the core logic and functionality

__version__ = "1.0.0"
__author__ = "NFT Risk Assessment Team"

# Export main classes and functions for easy importing
from .ai_interaction_logger import AIInteractionLogger, ai_logger, get_session_identifier, get_user_identifier
from .ai_interaction_wrapper import (
    wrapped_generate_ai_questions,
    wrapped_requirement_analysis,
    wrapped_get_gpt_assessment,
    wrapped_analyze_requirement_quality,
    wrapped_generate_embedding,
    get_ai_transparency_report,
    get_current_session_interactions,
    export_ai_interaction_logs
)

__all__ = [
    'AIInteractionLogger',
    'ai_logger',
    'get_session_identifier',
    'get_user_identifier',
    'wrapped_generate_ai_questions',
    'wrapped_requirement_analysis',
    'wrapped_get_gpt_assessment',
    'wrapped_analyze_requirement_quality',
    'wrapped_generate_embedding',
    'get_ai_transparency_report',
    'get_current_session_interactions',
    'export_ai_interaction_logs'
]
