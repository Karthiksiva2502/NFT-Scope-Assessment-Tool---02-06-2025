import sqlite3
import json
from datetime import datetime

def generate_structured_format_export():
    """Generate JSON export demonstrating the new structured format."""
    try:
        conn = sqlite3.connect('ai_interactions.db')
        cursor = conn.cursor()
        
        # Get all interactions with structured format
        cursor.execute("""
            SELECT id, user_id, session_id, interaction_type, prompt, response, timestamp, metadata
            FROM ai_interactions 
            WHERE prompt LIKE '%Application Overview:%'
            ORDER BY timestamp DESC
        """)
        
        interactions = cursor.fetchall()
        
        # Get total interactions for comparison
        cursor.execute("SELECT COUNT(*) FROM ai_interactions")
        total_interactions = cursor.fetchone()[0]
        
        conn.close()
        
        # Create export data
        export_data = {
            "export_metadata": {
                "timestamp": datetime.now().isoformat(),
                "format_type": "structured_requirement_analysis",
                "description": "Structured format with Application Overview, Contextual Information, Requirements, and Action directive",
                "total_interactions_in_db": total_interactions,
                "structured_format_interactions": len(interactions)
            },
            "structured_interactions": []
        }
        
        for interaction in interactions:
            # Analyze the prompt structure
            prompt = interaction[4]
            prompt_analysis = {
                "has_application_overview": "Application Overview:" in prompt,
                "has_contextual_information": "Contextual Information:" in prompt,
                "has_requirement_content": "Requirement text/file Upload contents:" in prompt,
                "has_action_directive": "Action to AI model:" in prompt,
                "has_qa_format": "Q:" in prompt and "A:" in prompt,
                "prompt_length": len(prompt)
            }
            
            interaction_data = {
                "interaction_id": interaction[0],
                "user_id": interaction[1],
                "session_id": interaction[2],
                "interaction_type": interaction[3],
                "timestamp": interaction[6],
                "prompt_analysis": prompt_analysis,
                "prompt_preview": prompt[:1000] + "..." if len(prompt) > 1000 else prompt,
                "response_preview": interaction[5][:500] + "..." if len(interaction[5]) > 500 else interaction[5],
                "metadata": json.loads(interaction[7]) if interaction[7] else {}
            }
            
            export_data["structured_interactions"].append(interaction_data)
        
        # Save export
        filename = f"structured_format_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Export completed: {filename}")
        print(f"📊 Found {len(interactions)} structured format interactions")
        print(f"📊 Total interactions in database: {total_interactions}")
        
        if interactions:
            print("\n🔍 Sample structured interaction:")
            sample = export_data["structured_interactions"][0]
            print(f"   ID: {sample['interaction_id']}")
            print(f"   Type: {sample['interaction_type']}")
            print(f"   Timestamp: {sample['timestamp']}")
            print(f"   All sections present: {all(sample['prompt_analysis'].values())}")
            print(f"   Q&A format: {sample['prompt_analysis']['has_qa_format']}")
            
        return filename
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

if __name__ == "__main__":
    print("🚀 GENERATING STRUCTURED FORMAT EXPORT")
    print("=" * 50)
    generate_structured_format_export()
