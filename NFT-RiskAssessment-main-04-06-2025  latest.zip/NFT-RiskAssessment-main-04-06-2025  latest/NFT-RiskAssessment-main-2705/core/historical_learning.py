# Historical Learning System - PROPOSAL 4 Implementation
# Learning from Historical Assessments with feedback loop capabilities

import logging
import json
import sqlite3
import os
import time
import statistics
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from collections import defaultdict
import numpy as np

# Configure logging
logger = logging.getLogger("historical_learning")

# --- Configuration ---
FEEDBACK_DB_PATH = "./data/feedback_db"
LEARNING_DB_NAME = "assessment_feedback.db"
MIN_FEEDBACK_COUNT = 5  # Minimum feedback entries needed for pattern learning
LEARNING_WINDOW_DAYS = 90  # Days to look back for learning patterns
OPTIMIZATION_THRESHOLD = 0.75  # Accuracy threshold for prompt optimization

@dataclass
class AssessmentFeedback:
    """Data class for storing assessment feedback"""
    assessment_id: str
    requirement_text: str
    ai_prediction: str  # The AI's risk assessment
    actual_outcome: str  # User-confirmed actual outcome
    accuracy_score: float  # 0.0 to 1.0
    feedback_type: str  # 'correct', 'partial', 'incorrect'
    user_comments: str
    timestamp: int
    project_type: str
    requirement_category: str
    
@dataclass
class LearningMetrics:
    """Data class for tracking learning metrics"""
    total_assessments: int
    correct_predictions: int
    accuracy_rate: float
    improvement_rate: float
    common_error_patterns: List[Dict]
    optimization_suggestions: List[str]
    confidence_scores: Dict[str, float]

class HistoricalLearningSystem:
    """
    Advanced learning system that tracks assessment outcomes, measures accuracy,
    learns from patterns, and optimizes prompts based on historical feedback.
    """
    
    def __init__(self, db_path: str = FEEDBACK_DB_PATH):
        """Initialize the historical learning system"""
        self.db_path = db_path
        self.db_file = os.path.join(db_path, LEARNING_DB_NAME)
        self._ensure_database_exists()
        
    def _ensure_database_exists(self):
        """Create the feedback database and tables if they don't exist"""
        os.makedirs(self.db_path, exist_ok=True)
        
        with sqlite3.connect(self.db_file) as conn:
            cursor = conn.cursor()
            
            # Assessment feedback table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS assessment_feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    assessment_id TEXT NOT NULL,
                    requirement_text TEXT NOT NULL,
                    ai_prediction TEXT NOT NULL,
                    actual_outcome TEXT NOT NULL,
                    accuracy_score REAL NOT NULL,
                    feedback_type TEXT NOT NULL,
                    user_comments TEXT,
                    timestamp INTEGER NOT NULL,
                    project_type TEXT,
                    requirement_category TEXT,
                    UNIQUE(assessment_id, timestamp)
                )
            ''')
            
            # Learning patterns table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS learning_patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pattern_type TEXT NOT NULL,
                    pattern_data TEXT NOT NULL,
                    confidence_score REAL NOT NULL,
                    usage_count INTEGER DEFAULT 0,
                    success_rate REAL DEFAULT 0.0,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL
                )
            ''')
            
            # Prompt optimization history
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS prompt_optimization (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    original_prompt TEXT NOT NULL,
                    optimized_prompt TEXT NOT NULL,
                    improvement_reason TEXT NOT NULL,
                    accuracy_before REAL NOT NULL,
                    accuracy_after REAL,
                    created_at INTEGER NOT NULL,
                    is_active BOOLEAN DEFAULT 1
                )
            ''')
            
            # Learning metrics tracking
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS learning_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    metric_date TEXT NOT NULL,
                    total_assessments INTEGER NOT NULL,
                    correct_predictions INTEGER NOT NULL,
                    accuracy_rate REAL NOT NULL,
                    improvement_rate REAL NOT NULL,
                    metrics_data TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    UNIQUE(metric_date)
                )
            ''')
            
            conn.commit()
            logger.info("Historical learning database initialized successfully")

    def record_feedback(self, feedback: AssessmentFeedback) -> bool:
        """
        Record feedback for an assessment to learn from outcomes
        
        Args:
            feedback: AssessmentFeedback object containing the feedback data
            
        Returns:
            bool: Success status
        """
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.cursor()
                
                # Insert feedback record
                cursor.execute('''
                    INSERT OR REPLACE INTO assessment_feedback 
                    (assessment_id, requirement_text, ai_prediction, actual_outcome, 
                     accuracy_score, feedback_type, user_comments, timestamp, 
                     project_type, requirement_category)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    feedback.assessment_id,
                    feedback.requirement_text,
                    feedback.ai_prediction,
                    feedback.actual_outcome,
                    feedback.accuracy_score,
                    feedback.feedback_type,
                    feedback.user_comments,
                    feedback.timestamp,
                    feedback.project_type,
                    feedback.requirement_category
                ))
                
                conn.commit()
                logger.info(f"Recorded feedback for assessment {feedback.assessment_id}")
                
                # Trigger learning pattern analysis if enough data
                self._analyze_patterns_async()
                
                return True
                
        except Exception as e:
            logger.error(f"Error recording feedback: {str(e)}")
            return False

    def calculate_accuracy_metrics(self, project_type: str = None, 
                                 days_back: int = LEARNING_WINDOW_DAYS) -> LearningMetrics:
        """
        Calculate comprehensive accuracy metrics and learning insights
        
        Args:
            project_type: Optional filter by project type
            days_back: Number of days to look back for metrics
            
        Returns:
            LearningMetrics object with comprehensive metrics
        """
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.cursor()
                
                # Build query with optional project type filter
                base_query = '''
                    SELECT ai_prediction, actual_outcome, accuracy_score, 
                           feedback_type, project_type, requirement_category, timestamp
                    FROM assessment_feedback 
                    WHERE timestamp > ?
                '''
                params = [int(time.time()) - (days_back * 24 * 60 * 60)]
                
                if project_type:
                    base_query += ' AND project_type = ?'
                    params.append(project_type)
                
                cursor.execute(base_query, params)
                results = cursor.fetchall()
                
                if not results:
                    return LearningMetrics(0, 0, 0.0, 0.0, [], [], {})
                
                # Calculate basic metrics
                total_assessments = len(results)
                correct_predictions = len([r for r in results if r[3] == 'correct'])
                accuracy_rate = correct_predictions / total_assessments if total_assessments > 0 else 0.0
                
                # Calculate improvement rate (comparing last 30 days vs previous 30 days)
                improvement_rate = self._calculate_improvement_rate(cursor, project_type)
                
                # Analyze error patterns
                error_patterns = self._analyze_error_patterns(results)
                
                # Generate optimization suggestions
                optimization_suggestions = self._generate_optimization_suggestions(results, accuracy_rate)
                
                # Calculate confidence scores by category
                confidence_scores = self._calculate_confidence_scores(results)
                
                return LearningMetrics(
                    total_assessments=total_assessments,
                    correct_predictions=correct_predictions,
                    accuracy_rate=accuracy_rate,
                    improvement_rate=improvement_rate,
                    common_error_patterns=error_patterns,
                    optimization_suggestions=optimization_suggestions,
                    confidence_scores=confidence_scores
                )
                
        except Exception as e:
            logger.error(f"Error calculating accuracy metrics: {str(e)}")
            return LearningMetrics(0, 0, 0.0, 0.0, [], [], {})

    def _calculate_improvement_rate(self, cursor, project_type: str = None) -> float:
        """Calculate the improvement rate over time"""
        try:
            # Get accuracy for last 30 days
            thirty_days_ago = int(time.time()) - (30 * 24 * 60 * 60)
            sixty_days_ago = int(time.time()) - (60 * 24 * 60 * 60)
            
            query_recent = '''
                SELECT COUNT(*) as total, 
                       SUM(CASE WHEN feedback_type = 'correct' THEN 1 ELSE 0 END) as correct
                FROM assessment_feedback 
                WHERE timestamp > ?
            '''
            query_previous = '''
                SELECT COUNT(*) as total, 
                       SUM(CASE WHEN feedback_type = 'correct' THEN 1 ELSE 0 END) as correct
                FROM assessment_feedback 
                WHERE timestamp BETWEEN ? AND ?
            '''
            
            params_recent = [thirty_days_ago]
            params_previous = [sixty_days_ago, thirty_days_ago]
            
            if project_type:
                query_recent += ' AND project_type = ?'
                query_previous += ' AND project_type = ?'
                params_recent.append(project_type)
                params_previous.append(project_type)
            
            cursor.execute(query_recent, params_recent)
            recent = cursor.fetchone()
            
            cursor.execute(query_previous, params_previous)
            previous = cursor.fetchone()
            
            if recent[0] > 0 and previous[0] > 0:
                recent_accuracy = recent[1] / recent[0]
                previous_accuracy = previous[1] / previous[0]
                return recent_accuracy - previous_accuracy
            
            return 0.0
            
        except Exception as e:
            logger.error(f"Error calculating improvement rate: {str(e)}")
            return 0.0

    def _analyze_error_patterns(self, results: List[Tuple]) -> List[Dict]:
        """Analyze common error patterns in assessments"""
        try:
            error_patterns = []
            error_data = [r for r in results if r[3] in ['partial', 'incorrect']]
            
            # Group by prediction vs actual outcome
            pattern_groups = defaultdict(list)
            for result in error_data:
                ai_pred, actual, accuracy, feedback_type, project_type, category, timestamp = result
                pattern_groups[f"{ai_pred}_vs_{actual}"].append(result)
            
            # Find the most common error patterns
            for pattern, occurrences in pattern_groups.items():
                if len(occurrences) >= 3:  # Only patterns with 3+ occurrences
                    avg_accuracy = statistics.mean([r[2] for r in occurrences])
                    categories = list(set([r[5] for r in occurrences if r[5]]))
                    
                    error_patterns.append({
                        'pattern': pattern,
                        'count': len(occurrences),
                        'average_accuracy': round(avg_accuracy, 3),
                        'affected_categories': categories,
                        'frequency': round(len(occurrences) / len(results), 3)
                    })
            
            # Sort by frequency (most common first)
            error_patterns.sort(key=lambda x: x['count'], reverse=True)
            return error_patterns[:10]  # Top 10 patterns
            
        except Exception as e:
            logger.error(f"Error analyzing error patterns: {str(e)}")
            return []

    def _generate_optimization_suggestions(self, results: List[Tuple], accuracy_rate: float) -> List[str]:
        """Generate suggestions for improving assessment accuracy"""
        suggestions = []
        
        try:
            # Analyze accuracy by category
            category_accuracy = defaultdict(list)
            for result in results:
                if result[5]:  # requirement_category
                    category_accuracy[result[5]].append(result[2])  # accuracy_score
            
            # Find categories with low accuracy
            for category, accuracies in category_accuracy.items():
                avg_accuracy = statistics.mean(accuracies)
                if avg_accuracy < 0.7 and len(accuracies) >= 3:
                    suggestions.append(f"Improve prompts for {category} requirements (current accuracy: {avg_accuracy:.2%})")
            
            # Overall accuracy suggestions
            if accuracy_rate < 0.6:
                suggestions.append("Consider major prompt revision - accuracy below 60%")
            elif accuracy_rate < 0.75:
                suggestions.append("Review and refine assessment criteria - accuracy below 75%")
            
            # Risk level specific suggestions
            risk_accuracy = defaultdict(list)
            for result in results:
                risk_level = result[0]  # ai_prediction
                risk_accuracy[risk_level].append(result[2])
            
            for risk, accuracies in risk_accuracy.items():
                if len(accuracies) >= 3:
                    avg_accuracy = statistics.mean(accuracies)
                    if avg_accuracy < 0.7:
                        suggestions.append(f"Improve {risk} risk detection criteria (accuracy: {avg_accuracy:.2%})")
            
            return suggestions[:5]  # Top 5 suggestions
            
        except Exception as e:
            logger.error(f"Error generating optimization suggestions: {str(e)}")
            return ["Error generating suggestions - check logs"]

    def _calculate_confidence_scores(self, results: List[Tuple]) -> Dict[str, float]:
        """Calculate confidence scores for different categories"""
        try:
            confidence_scores = {}
            
            # By risk level
            risk_scores = defaultdict(list)
            for result in results:
                risk_level = result[0]  # ai_prediction
                accuracy = result[2]  # accuracy_score
                risk_scores[risk_level].append(accuracy)
            
            for risk, accuracies in risk_scores.items():
                if len(accuracies) >= 3:
                    confidence_scores[f"risk_{risk.lower()}"] = statistics.mean(accuracies)
            
            # By project type
            project_scores = defaultdict(list)
            for result in results:
                project_type = result[4]  # project_type
                accuracy = result[2]  # accuracy_score
                if project_type:
                    project_scores[project_type].append(accuracy)
            
            for project, accuracies in project_scores.items():
                if len(accuracies) >= 3:
                    confidence_scores[f"project_{project.lower().replace(' ', '_')}"] = statistics.mean(accuracies)
            
            return confidence_scores
            
        except Exception as e:
            logger.error(f"Error calculating confidence scores: {str(e)}")
            return {}

    def _analyze_patterns_async(self):
        """Analyze patterns and update learning database (async trigger)"""
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.cursor()
                
                # Check if we have enough data for pattern analysis
                cursor.execute('SELECT COUNT(*) FROM assessment_feedback')
                count = cursor.fetchone()[0]
                
                if count >= MIN_FEEDBACK_COUNT:
                    self._update_learning_patterns(cursor)
                    
        except Exception as e:
            logger.error(f"Error in pattern analysis: {str(e)}")

    def _update_learning_patterns(self, cursor):
        """Update learning patterns based on recent feedback"""
        try:
            # Identify successful prediction patterns
            cursor.execute('''
                SELECT requirement_category, project_type, ai_prediction, 
                       AVG(accuracy_score) as avg_accuracy, COUNT(*) as count
                FROM assessment_feedback 
                WHERE timestamp > ?
                GROUP BY requirement_category, project_type, ai_prediction
                HAVING count >= 3 AND avg_accuracy > 0.8
            ''', [int(time.time()) - (LEARNING_WINDOW_DAYS * 24 * 60 * 60)])
            
            patterns = cursor.fetchall()
            current_time = int(time.time())
            
            for pattern in patterns:
                category, project, prediction, accuracy, count = pattern
                
                pattern_data = {
                    'category': category,
                    'project_type': project,
                    'prediction': prediction,
                    'success_contexts': []
                }
                
                # Store or update the pattern
                cursor.execute('''
                    INSERT OR REPLACE INTO learning_patterns 
                    (pattern_type, pattern_data, confidence_score, usage_count, 
                     success_rate, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    'successful_prediction',
                    json.dumps(pattern_data),
                    accuracy,
                    count,
                    accuracy,
                    current_time,
                    current_time
                ))
            
            logger.info(f"Updated {len(patterns)} learning patterns")
            
        except Exception as e:
            logger.error(f"Error updating learning patterns: {str(e)}")

    def get_prompt_optimization_recommendations(self) -> Dict[str, Any]:
        """
        Get recommendations for optimizing assessment prompts based on historical data
        
        Returns:
            Dictionary with optimization recommendations
        """
        try:
            metrics = self.calculate_accuracy_metrics()
            
            if metrics.accuracy_rate < OPTIMIZATION_THRESHOLD:
                recommendations = {
                    'needs_optimization': True,
                    'current_accuracy': metrics.accuracy_rate,
                    'target_accuracy': OPTIMIZATION_THRESHOLD,
                    'priority_areas': [],
                    'suggested_improvements': metrics.optimization_suggestions,
                    'error_patterns': metrics.common_error_patterns
                }
                
                # Identify priority areas based on error patterns
                for pattern in metrics.common_error_patterns:
                    if pattern['frequency'] > 0.1:  # More than 10% of errors
                        recommendations['priority_areas'].append({
                            'area': pattern['pattern'],
                            'frequency': pattern['frequency'],
                            'impact': 'high' if pattern['frequency'] > 0.2 else 'medium'
                        })
                
                return recommendations
            else:
                return {
                    'needs_optimization': False,
                    'current_accuracy': metrics.accuracy_rate,
                    'status': 'performing_well',
                    'minor_improvements': metrics.optimization_suggestions[:2]
                }
                
        except Exception as e:
            logger.error(f"Error getting optimization recommendations: {str(e)}")
            return {'error': str(e)}

    def record_prompt_optimization(self, original_prompt: str, optimized_prompt: str, 
                                 improvement_reason: str, accuracy_before: float) -> bool:
        """
        Record a prompt optimization attempt
        
        Args:
            original_prompt: The original prompt
            optimized_prompt: The improved prompt
            improvement_reason: Explanation of why this optimization was made
            accuracy_before: Accuracy rate before optimization
            
        Returns:
            bool: Success status
        """
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO prompt_optimization 
                    (original_prompt, optimized_prompt, improvement_reason, 
                     accuracy_before, created_at)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    original_prompt,
                    optimized_prompt,
                    improvement_reason,
                    accuracy_before,
                    int(time.time())
                ))
                
                conn.commit()
                logger.info("Recorded prompt optimization")
                return True
                
        except Exception as e:
            logger.error(f"Error recording prompt optimization: {str(e)}")
            return False

    def get_learning_dashboard_data(self) -> Dict[str, Any]:
        """
        Get comprehensive data for the learning dashboard
        
        Returns:
            Dictionary with dashboard data
        """
        try:
            metrics = self.calculate_accuracy_metrics()
            
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.cursor()
                
                # Get recent feedback trends
                cursor.execute('''
                    SELECT DATE(timestamp, 'unixepoch') as date, 
                           AVG(accuracy_score) as avg_accuracy,
                           COUNT(*) as count
                    FROM assessment_feedback 
                    WHERE timestamp > ?
                    GROUP BY date
                    ORDER BY date DESC
                    LIMIT 30
                ''', [int(time.time()) - (30 * 24 * 60 * 60)])
                
                daily_trends = cursor.fetchall()
                
                # Get optimization history
                cursor.execute('''
                    SELECT created_at, accuracy_before, accuracy_after, improvement_reason
                    FROM prompt_optimization 
                    ORDER BY created_at DESC 
                    LIMIT 10
                ''')
                
                optimization_history = cursor.fetchall()
                
                return {
                    'overall_metrics': asdict(metrics),
                    'daily_trends': [
                        {
                            'date': trend[0],
                            'accuracy': trend[1],
                            'count': trend[2]
                        } for trend in daily_trends
                    ],
                    'optimization_history': [
                        {
                            'date': datetime.fromtimestamp(opt[0]).strftime('%Y-%m-%d'),
                            'accuracy_before': opt[1],
                            'accuracy_after': opt[2],
                            'reason': opt[3]
                        } for opt in optimization_history
                    ],
                    'recommendations': self.get_prompt_optimization_recommendations()
                }
                
        except Exception as e:
            logger.error(f"Error getting dashboard data: {str(e)}")
            return {'error': str(e)}

    def export_learning_data(self, output_file: str = "learning_data_export.json") -> bool:
        """
        Export all learning data for backup or analysis
        
        Args:
            output_file: Output file path
            
        Returns:
            bool: Success status
        """
        try:
            with sqlite3.connect(self.db_file) as conn:
                cursor = conn.cursor()
                
                # Export all tables
                export_data = {
                    'export_timestamp': int(time.time()),
                    'export_date': datetime.now().isoformat(),
                    'feedback_data': [],
                    'learning_patterns': [],
                    'optimization_history': [],
                    'metrics_history': []
                }
                
                # Export feedback data
                cursor.execute('SELECT * FROM assessment_feedback')
                columns = [description[0] for description in cursor.description]
                for row in cursor.fetchall():
                    export_data['feedback_data'].append(dict(zip(columns, row)))
                
                # Export learning patterns
                cursor.execute('SELECT * FROM learning_patterns')
                columns = [description[0] for description in cursor.description]
                for row in cursor.fetchall():
                    export_data['learning_patterns'].append(dict(zip(columns, row)))
                
                # Export optimization history
                cursor.execute('SELECT * FROM prompt_optimization')
                columns = [description[0] for description in cursor.description]
                for row in cursor.fetchall():
                    export_data['optimization_history'].append(dict(zip(columns, row)))
                
                # Save to file
                with open(output_file, 'w') as f:
                    json.dump(export_data, f, indent=2, default=str)
                
                logger.info(f"Learning data exported to {output_file}")
                return True
                
        except Exception as e:
            logger.error(f"Error exporting learning data: {str(e)}")
            return False

# Global instance for easy access
learning_system = HistoricalLearningSystem()

# Helper functions for integration with existing system
def record_assessment_feedback(assessment_id: str, requirement_text: str, 
                             ai_prediction: str, actual_outcome: str, 
                             user_comments: str = "", project_type: str = "", 
                             requirement_category: str = "") -> bool:
    """
    Convenience function to record feedback for an assessment
    
    Args:
        assessment_id: ID of the assessment
        requirement_text: The requirement text
        ai_prediction: AI's risk prediction
        actual_outcome: Actual outcome/risk level
        user_comments: Optional user comments
        project_type: Type of project
        requirement_category: Category of requirement
        
    Returns:
        bool: Success status
    """
    # Calculate accuracy score based on prediction vs outcome
    accuracy_score = calculate_prediction_accuracy(ai_prediction, actual_outcome)
    
    # Determine feedback type
    if accuracy_score >= 0.9:
        feedback_type = 'correct'
    elif accuracy_score >= 0.6:
        feedback_type = 'partial'
    else:
        feedback_type = 'incorrect'
    
    feedback = AssessmentFeedback(
        assessment_id=assessment_id,
        requirement_text=requirement_text,
        ai_prediction=ai_prediction,
        actual_outcome=actual_outcome,
        accuracy_score=accuracy_score,
        feedback_type=feedback_type,
        user_comments=user_comments,
        timestamp=int(time.time()),
        project_type=project_type,
        requirement_category=requirement_category
    )
    
    return learning_system.record_feedback(feedback)

def calculate_prediction_accuracy(ai_prediction: str, actual_outcome: str) -> float:
    """
    Calculate accuracy score between AI prediction and actual outcome
    
    Args:
        ai_prediction: AI's risk prediction
        actual_outcome: Actual risk level
        
    Returns:
        float: Accuracy score (0.0 to 1.0)
    """
    # Normalize the strings for comparison
    ai_pred = ai_prediction.lower().strip()
    actual = actual_outcome.lower().strip()
    
    # Exact match
    if ai_pred == actual:
        return 1.0
    
    # Risk level mapping for partial matches
    risk_levels = {
        'low': 1, 'medium': 2, 'high': 3,
        'l': 1, 'm': 2, 'h': 3,
        'minimal': 1, 'moderate': 2, 'critical': 3,
        'green': 1, 'yellow': 2, 'red': 3
    }
    
    ai_level = risk_levels.get(ai_pred, 0)
    actual_level = risk_levels.get(actual, 0)
    
    if ai_level > 0 and actual_level > 0:
        # Calculate partial accuracy based on distance
        distance = abs(ai_level - actual_level)
        if distance == 0:
            return 1.0
        elif distance == 1:
            return 0.7  # One level off
        elif distance == 2:
            return 0.3  # Two levels off
    
    return 0.0  # No match

def get_learning_metrics(project_type: str = None) -> LearningMetrics:
    """Get learning metrics for the system"""
    return learning_system.calculate_accuracy_metrics(project_type)

def get_optimization_recommendations() -> Dict[str, Any]:
    """Get prompt optimization recommendations"""
    return learning_system.get_prompt_optimization_recommendations()

def get_learning_dashboard_data() -> Dict[str, Any]:
    """Get data for the learning dashboard"""
    return learning_system.get_learning_dashboard_data()
