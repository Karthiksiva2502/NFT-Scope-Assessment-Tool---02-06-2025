# Main Streamlit application file
import streamlit as st
import time
import pandas as pd
import json
import openai # Import the openai library
from streamlit_chat import message  # Re-enable chat import
from plotly.graph_objects import Figure as go  # Import plotly.graph_objects as go

# Import core application modules
from core import file_parser
from core import chroma_logic
from core import gpt_logic
from core import pdf_generator
from core import req_quality_checker
from core import risk_visualization
from core import historical_learning  # Import the new historical learning module
from core.intelligent_assessment_logic import IntelligentAssessmentDecision  # Import intelligent assessment logic

# Import AI interaction logging wrapper
from core.ai_interaction_wrapper import (
    wrapped_generate_nft_questions,  # Import the new NFT questions function
    wrapped_requirement_analysis,
    wrapped_get_gpt_assessment,
    wrapped_analyze_requirement_quality,
    wrapped_generate_embedding,
    get_ai_transparency_report,
    get_current_session_interactions,
    export_ai_interaction_logs
)
from core.ai_interaction_logger import get_session_identifier

# Apply custom styling to the app - this must be the first Streamlit command
st.set_page_config(layout="wide", page_title="NFT Requirement Risk Assessor", page_icon="🛡️")

# Custom CSS for better look and feel
st.markdown("""
<style>
    /* Main background gradient */
    .stApp {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }
    
    /* Header styling */
    h1, h2, h3 {
        color: #2c3e50;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    h1 {
        text-align: center;
        padding: 20px 0;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        border-bottom: 2px solid #3498db;
        margin-bottom: 30px;
        background-color: rgba(255, 255, 255, 0.7);
        border-radius: 10px;
    }
    
    /* Card-like styling for containers */
    .stTabs [data-baseweb="tab-panel"] {
        background-color: rgba(255, 255, 255, 0.8);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    /* Make sidebar more distinct */
    [data-testid="stSidebar"] {
        background-color: rgba(236, 240, 243, 0.9);
        border-right: 1px solid #ddd;
        padding: 10px;
    }
    
    /* Buttons styling */
    .stButton > button {
        background-color: #3498db;
        color: white;
        border-radius: 5px;
        border: none;
        padding: 5px 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: all 0.3s;
    }
    .stButton > button:hover {
        background-color: #2980b9;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    /* Success and error messages */
    .stSuccess, .stInfo {
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    /* Tables and dataframes */
    [data-testid="stTable"] {
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    
    /* Assessment results */
    .element-container:has(h3:contains("Assessment Results")) {
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        margin: 15px 0;
    }
    
    /* AI Assistant styling */
    .element-container:has(h3:contains("AI Assistant")) {
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        margin: 15px 0;
    }
    
    /* Chat container */
    .chat-container {
        background-color: rgba(255, 255, 255, 0.9) !important;
        border: none !important;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05) !important;
    }
    
    /* Text areas */
    .stTextArea textarea {
        border-radius: 8px;
        border: 1px solid #ddd;
    }
    
    /* Expandable sections */
    .streamlit-expanderHeader {
        background-color: rgba(236, 240, 243, 0.9);
        border-radius: 5px;
    }
    
    /* Status indicators */
    .element-container:has(p:contains("Approved")) {
        color: #27ae60;
    }
    .element-container:has(p:contains("Rejected")) {
        color: #e74c3c;
    }
    .element-container:has(p:contains("Pending")) {
        color: #f39c12;
    }
</style>
""", unsafe_allow_html=True)

# --- Initialize session state ---
# Initialize API key in session state first since check_mandatory_fields() depends on it
if 'api_key_input_global' not in st.session_state:
    st.session_state.api_key_input_global = ""

if 'assessment_result' not in st.session_state:
    st.session_state.assessment_result = None
if 'similar_requirements' not in st.session_state:
    st.session_state.similar_requirements = None
if 'current_requirement_text' not in st.session_state:
    st.session_state.current_requirement_text = ""
if 'current_context' not in st.session_state:
    st.session_state.current_context = {} # Will be populated by sidebar
if 'assessment_id' not in st.session_state:
    st.session_state.assessment_id = None
if 'all_fields_filled' not in st.session_state:
    st.session_state.all_fields_filled = False
if 'project_type_selection' not in st.session_state: # To store the project type
    st.session_state.project_type_selection = 'New Project' # Default
if 'quality_check_result' not in st.session_state:
    st.session_state.quality_check_result = None
# Ensure the radio button's state key is initialized
if 'ctx_change_type_sidebar_global' not in st.session_state:
    st.session_state.ctx_change_type_sidebar_global = 'New Change (New Feature/Application)'
if 'batch_assessment_results' not in st.session_state:
    st.session_state.batch_assessment_results = [] # For storing results of batch processing
if 'initial_assessment' not in st.session_state:
    st.session_state.initial_assessment = {} # For storing the initial assessment before showing question
# Note: Search parameters are now configured in backend (chroma_logic.py) with DEFAULT values
# Add session state for API key validation
if 'api_key_valid' not in st.session_state:
    st.session_state.api_key_valid = False
# Add session state for Phase 1 features
if 'dashboard_tab_selected' not in st.session_state:
    st.session_state.dashboard_tab_selected = False
if 'component_map_tab_selected' not in st.session_state:
    st.session_state.component_map_tab_selected = False
# Add session state for NFT chat assistant
if 'nft_chat_active' not in st.session_state:
    st.session_state.nft_chat_active = False
if 'nft_chat_history' not in st.session_state:
    st.session_state.nft_chat_history = []
if 'nft_questions' not in st.session_state:
    st.session_state.nft_questions = []
if 'nft_gather_complete' not in st.session_state:
    st.session_state.nft_gather_complete = False
if 'nft_additional_info' not in st.session_state:
    st.session_state.nft_additional_info = ""

# Function to analyze if we need additional NFT information
def is_nft_info_sufficient(requirement_text, context):
    """
    Evaluates if we have sufficient information for NFT assessment based on the selected testing coverage.
    Returns True if sufficient, False if we need to gather more information.
    """
    # Even stricter check for requirement text (less than 40 words)
    if not requirement_text or len(requirement_text.split()) < 40:
        return False, {
            "completeness_percentage": 50,
            "message": "Requirement text is too brief. Please provide much more comprehensive details about the non-functional requirements including performance expectations, security needs, and business impact."
        }
        
    # Also check if the text has sufficient NFT-related keywords
    nfr_keywords = ['performance', 'security', 'scalability', 'reliability', 'availability', 'usability', 
                   'response time', 'throughput', 'load', 'users', 'concurrent', 'volume']
    keyword_count = sum(1 for keyword in nfr_keywords if keyword in requirement_text.lower())
    if keyword_count < 3:
        return False, {
            "completeness_percentage": 50,
            "message": "Requirement text lacks sufficient non-functional details. Please provide specific information about performance, security, scalability, or other NFT aspects."
        }
    
    # Get selected testing coverage from context
    selected_testing = context.get('assessment_coverage', [])
    
    # Create a mapping of required info fields for each testing type
    testing_type_requirements = {
        'Performance Testing (Load, Stress, etc.)': [
            'business_critical_volume', 
            'response_time_sla',
            'growth_rate',
            'components_involved'
        ],
        'Device Level Testing': [
            'components_involved'  # Specifically looking for 'User Interface' in components
        ],
        'OAT': [
            'business_disruption',
            'contingency_plans'
        ],
        'Accessibility': [
            # No specific fields required beyond mandatory fields
        ],
        'Security': [
            # No specific fields required beyond mandatory fields
        ],
        'All Non-Functional Testing': [
            'business_critical_volume', 
            'response_time_sla',
            'growth_rate',
            'components_involved',
            'business_disruption',
            'contingency_plans'
        ]
    }
    
    # Check if requirements already mention the specific NFT concerns
    # This will help avoid asking questions when the requirement text already covers the details
    requirement_text_lower = requirement_text.lower() if requirement_text else ""
    
    # If specific testing types are selected, check if we have the necessary information
    if selected_testing:
        # If the requirement text is extensive, check if it has enough NFT-specific information
        # Increased the length requirement to be more aggressive in showing the NFT chat
        if len(requirement_text_lower) > 700:  # Increased from 500 to 700
            has_performance_keywords = any(kw in requirement_text_lower for kw in 
                ['performance', 'load', 'stress', 'response time', 'throughput', 'concurrent', 'users', 'milliseconds', 'seconds', 'scalability'])
            has_device_keywords = any(kw in requirement_text_lower for kw in 
                ['device', 'browser', 'responsive', 'screen', 'resolution', 'mobile', 'tablet', 'desktop', 'compatibility'])
            has_oat_keywords = any(kw in requirement_text_lower for kw in 
                ['operational', 'monitoring', 'backup', 'recovery', 'maintenance', 'deployment', 'logging', 'alerting'])
            has_accessibility_keywords = any(kw in requirement_text_lower for kw in 
                ['accessibility', 'wcag', 'aria', 'screen reader', 'keyboard navigation', 'disabled users', 'a11y'])
            has_security_keywords = any(kw in requirement_text_lower for kw in 
                ['security', 'authentication', 'authorization', 'encryption', 'data protection', 'penetration testing', 'vulnerability'])
            
            # If requirement already extensively covers the selected testing types, consider it sufficient
            requirements_covered = True
            for testing_type in selected_testing:
                if 'Performance' in testing_type and not has_performance_keywords:
                    requirements_covered = False
                    break
                if 'Device' in testing_type and not has_device_keywords:
                    requirements_covered = False
                    break
                if 'OAT' in testing_type and not has_oat_keywords:
                    requirements_covered = False
                    break
                if 'Accessibility' in testing_type and not has_accessibility_keywords:
                    requirements_covered = False
                    break
                if 'Security' in testing_type and not has_security_keywords:
                    requirements_covered = False
                    break
            
            if requirements_covered:
                return True, {"completeness_percentage": 95, "message": "Requirement text already covers needed details"}
        
        # Check if we have the necessary information in context for each selected testing type
        missing_fields = []
        for testing_type in selected_testing:
            # Skip if "All Non-Functional Testing" is also selected
            if "All Non-Functional Testing" in selected_testing and testing_type != "All Non-Functional Testing":
                continue
                
            # Check required fields for this testing type
            required_fields = testing_type_requirements.get(testing_type, [])
            for field in required_fields:
                # Special handling for Device Level Testing - check if User Interface is in components_involved
                if field == 'components_involved' and testing_type == 'Device Level Testing':
                    if 'User Interface' not in context.get('components_involved', []):
                        missing_fields.append('UI component information')
                # For normal fields, check if they exist and have valid values
                elif field not in context or not context[field]:
                    missing_fields.append(field)
        
        # If missing fields are found, we need more information
        if missing_fields:
            # Use intelligent assessment for context
            assessment = IntelligentAssessmentDecision.analyze_information_completeness(
                requirement_text, context, context.get('Application Overview', '')
            )
            
            # Calculate a more accurate completeness percentage based on both missing fields and intelligent assessment
            completeness_percentage = assessment['completeness_percentage'] * (1 - (len(missing_fields) / 10))
            
            # Return needs more info
            return False, {
                "completeness_percentage": completeness_percentage,
                "missing_fields": missing_fields,
                "message": "Missing information required for selected testing types"
            }
        
        # If no missing fields, we have sufficient information
        return True, {"completeness_percentage": 90, "message": "Required information for selected testing is sufficient"}
    
    # If no specific testing types are selected, fall back to intelligent assessment
    assessment = IntelligentAssessmentDecision.analyze_information_completeness(
        requirement_text, context, context.get('Application Overview', '')
    )
    
    # If completion percentage is below threshold, we need more information
    if assessment['completeness_percentage'] < 90:  # Increased from 85% to 90% to be even more strict about requirements
        return False, assessment
    
    return True, assessment

# Function to generate NFT-specific questions
def generate_nft_questions(requirement_text, context, api_key):
    """
    Generates NFT-specific questions to gather essential missing information.
    Uses the new wrapped_generate_nft_questions function.
    
    Returns a list of questions or "SUFFICIENT_INFO_FOR_NFT_ASSESSMENT" if no questions needed.
    """
    try:
        # Call the NFT-specific question generator
        response = wrapped_generate_nft_questions(requirement_text, context, api_key)
        
        if isinstance(response, dict) and "questions" in response:
            questions_text = response["questions"].strip()
            
            # Check if we have sufficient information
            if questions_text == "SUFFICIENT_INFO_FOR_NFT_ASSESSMENT":
                return []
                
            # Parse the numbered list of questions
            questions = []
            for line in questions_text.split('\n'):
                line = line.strip()
                if line and (line[0].isdigit() or line.startswith('*') or line.startswith('-')):
                    # Clean up the line to remove numbering and other formatting
                    clean_line = line.lstrip('0123456789.*- ').strip()
                    if clean_line:
                        questions.append(clean_line)
            
            # If questions list is empty but text isn't "SUFFICIENT_INFO", there might be
            # parsing issues, so we add the whole text as one question
            if not questions and questions_text and questions_text != "SUFFICIENT_INFO_FOR_NFT_ASSESSMENT":
                questions.append(questions_text)
            
            # Remove duplicate questions to prevent repetition
            questions = list(dict.fromkeys(questions))
            
            # Always add specific questions about NFT details if the requirement text is brief
            # Significantly increased the word count threshold to be more aggressive about gathering information
            if requirement_text and len(requirement_text.split()) < 50:
                default_questions = [
                    "Please describe your requirement in more detail. What is the feature trying to accomplish?",
                    "What are the specific performance requirements or constraints for this feature?",
                    "Are there any security considerations or compliance requirements?",
                    "How many concurrent users will use this feature and what's the expected load?",
                    "What is the business criticality of this feature and impact of failure?"
                ]
                # Only add default questions that aren't already in the list
                for q in default_questions:
                    if q not in questions:
                        questions.append(q)
                
            return questions
        else:
            # If there was an error or unexpected response format
            return ["What specific non-functional requirements (like performance, security, scalability) are critical for this implementation?", 
                   "Please provide additional details about the requirement - what is it trying to accomplish?"]
            
    except Exception as e:
        print(f"Error generating NFT questions: {e}")
        # Return a default question as fallback
        return ["What specific non-functional requirements (like performance, security, scalability) are critical for this implementation?"]

# Function to handle NFT chat interactions
def handle_nft_chat(question, api_key):
    """
    Handles the NFT chat assistant interactions.
    Adds the question to the chat history and displays the chat interface.
    """
    # Initialize chat history if it doesn't exist
    if not st.session_state.nft_chat_history:
        st.session_state.nft_chat_history = []
        
    # Add the initial welcome message from assistant to chat history if it's the first interaction
    if not st.session_state.nft_chat_history:
        st.session_state.nft_chat_history.append({
            "role": "assistant", 
            "content": "Your requirement description needs more details for an accurate non-functional testing assessment. Please answer the following questions to provide the necessary information."
        })
    
    # Only add a new question if there is a question to add and we're ready for a new question
    # (last message in history is from the user or we're just starting the chat)
    if question and (
        len(st.session_state.nft_chat_history) == 1 or  # Only welcome message exists
        (st.session_state.nft_chat_history and st.session_state.nft_chat_history[-1]["role"] == "user")
    ):
        # Check if this question has already been asked to prevent repetition
        existing_questions = [msg["content"] for msg in st.session_state.nft_chat_history if msg["role"] == "assistant"]
        if question not in existing_questions:
            st.session_state.nft_chat_history.append({"role": "assistant", "content": question})
        else:
            # If this question was already asked, move to the next one if available
            if st.session_state.nft_questions:
                next_question = st.session_state.nft_questions.pop(0)
                # Make sure the next question is also not a duplicate
                while next_question in existing_questions and st.session_state.nft_questions:
                    next_question = st.session_state.nft_questions.pop(0)
                
                if next_question not in existing_questions:
                    st.session_state.nft_chat_history.append({"role": "assistant", "content": next_question})
                else:
                    # If we've exhausted all unique questions, mark as complete
                    st.session_state.nft_gather_complete = True
        
    # Create a container for the chat interface
    chat_container = st.container()
    
    with chat_container:
        st.subheader("📝 NFT Information Gathering")
        st.markdown("*Please answer these specific questions about non-functional aspects to improve your assessment accuracy:*")
        
        # Render the chat messages
        for i, msg in enumerate(st.session_state.nft_chat_history):
            if msg["role"] == "assistant":
                message(msg["content"], key=f"msg_{i}", is_user=False)
            else:
                message(msg["content"], key=f"msg_{i}", is_user=True)
        
        # Check if we're waiting for a user response
        # (last message in history is from the assistant)
        waiting_for_user = st.session_state.nft_chat_history and st.session_state.nft_chat_history[-1]["role"] == "assistant"
        
        # Only show the input box if we're waiting for a user response
        if waiting_for_user:
            # User input for chat
            user_input = st.text_area("Your answer:", "", key="nft_chat_input", height=100)
            
            # Submit button for the answer
            if st.button("Submit Answer", key="submit_nft_answer"):
                if user_input:
                    # Add user response to chat history
                    st.session_state.nft_chat_history.append({"role": "user", "content": user_input})
                    
                    # If we have more questions in the queue, get the next one ready
                    if st.session_state.nft_questions:
                        next_question = st.session_state.nft_questions.pop(0)
                        
                        # Check if this question has already been asked
                        existing_questions = [msg["content"] for msg in st.session_state.nft_chat_history if msg["role"] == "assistant"]
                        while next_question in existing_questions and st.session_state.nft_questions:
                            # Skip this question and get the next one
                            next_question = st.session_state.nft_questions.pop(0)
                        
                        # Only add the question if it's not a duplicate
                        if next_question not in existing_questions:
                            st.session_state.nft_chat_history.append({"role": "assistant", "content": next_question})
                        elif not st.session_state.nft_questions:
                            # We've gone through all questions - add completion message
                            st.session_state.nft_chat_history.append({
                                "role": "assistant", 
                                "content": "Thank you for providing the additional information. I now have what I need to proceed with your NFT assessment."
                            })
                            
                            # Compile all gathered information
                            gathered_info = ""
                            for i in range(1, len(st.session_state.nft_chat_history)-1, 2):  # -1 to exclude the thank you message
                                if i < len(st.session_state.nft_chat_history):
                                    question = st.session_state.nft_chat_history[i]["content"] if i < len(st.session_state.nft_chat_history) else ""
                                    answer = st.session_state.nft_chat_history[i+1]["content"] if i+1 < len(st.session_state.nft_chat_history) else ""
                                    if question and answer and "Thank you for providing" not in question:
                                        gathered_info += f"Q: {question}\nA: {answer}\n\n"
                            
                            # Save the gathered information to session state
                            st.session_state.nft_additional_info = gathered_info
                            st.session_state.nft_gather_complete = True
                    else:
                        # We've gone through all questions - add completion message
                        st.session_state.nft_chat_history.append({
                            "role": "assistant", 
                            "content": "Thank you for providing the additional information. I now have what I need to proceed with your NFT assessment."
                        })
                        
                        # Compile all gathered information
                        gathered_info = ""
                        for i in range(1, len(st.session_state.nft_chat_history)-1, 2):  # -1 to exclude the thank you message
                            if i < len(st.session_state.nft_chat_history):
                                question = st.session_state.nft_chat_history[i]["content"] if i < len(st.session_state.nft_chat_history) else ""
                                answer = st.session_state.nft_chat_history[i+1]["content"] if i+1 < len(st.session_state.nft_chat_history) else ""
                                if question and answer and "Thank you for providing" not in question:
                                    gathered_info += f"Q: {question}\nA: {answer}\n\n"
                        
                        # Save the gathered information to session state
                        st.session_state.nft_additional_info = gathered_info
                        st.session_state.nft_gather_complete = True
                    
                    st.rerun()
        
        # Check if we've gone through all questions and the gathering is complete
        if st.session_state.nft_gather_complete:
            st.success("Thank you for providing the additional information. Proceeding with your NFT assessment...")

st.title("NFT Requirement Risk Assessment Tool")

# AI chat feature variables have been removed as requested

# Define lists of widget keys for the new contextual questions
mandatory_widget_keys = [
    'ctx_project_name_sidebar_global',
    'ctx_change_type_sidebar_global',
    'ctx_application_component_name_sidebar_global',
    'ctx_components_involved_sidebar_global',
    'ctx_business_critical_volume_sidebar_global',
    'ctx_response_time_sla_sidebar_global',
    'ctx_expected_growth_rate_sidebar_global',
    'ctx_customization_level_sidebar_global',
    'ctx_channel_impact_sidebar_global',
    'ctx_performance_issues_sidebar_global',
    'ctx_business_disruption_sidebar_global',
    'ctx_contingency_plans_sidebar_global',
    'ctx_assessment_coverage_sidebar_global'
]

# Follow-up question widget keys
followup_widget_keys = [
    'ctx_infrastructure_changes_sidebar_global',
    'ctx_third_party_involvement_sidebar_global'
]

# Function to check if all mandatory fields are filled
def check_mandatory_fields():
    # Check if API key is provided
    if not st.session_state.api_key_input_global:
        return False
    
    # Check all mandatory fields
    for field in mandatory_widget_keys:
        # Special handling for assessment_coverage which is now a list from checkboxes
        if field == 'ctx_assessment_coverage_sidebar_global':
            # Check if at least one assessment option is selected
            assessment_coverage = st.session_state.current_context.get('assessment_coverage', [])
            if not assessment_coverage or len(assessment_coverage) == 0:
                return False
        # Special handling for components_involved which is now a list from checkboxes
        elif field == 'ctx_components_involved_sidebar_global':
            # Check if at least one component is selected
            components_involved = st.session_state.current_context.get('components_involved', [])
            if not components_involved or len(components_involved) == 0:
                return False
        # Conditional validation for fields that depend on change type
        elif field in ['ctx_customization_level_sidebar_global', 'ctx_performance_issues_sidebar_global']:
            change_type = st.session_state.current_context.get('change_type', '')
            # Only validate these fields if change type is NOT "New Change (New Feature/Application)"
            if change_type != 'New Change (New Feature/Application)':
                if field not in st.session_state or not st.session_state[field]:
                    return False
            # If change type is "New Change", these fields are optional/hidden, so skip validation
        else:
            if field not in st.session_state or not st.session_state[field]:
                return False
    
    # Check follow-up questions based on component selection
    components_involved = st.session_state.current_context.get('components_involved', [])
    
    if 'Infrastructure' in components_involved:
        if not st.session_state.get('ctx_infrastructure_changes_sidebar_global', ''):
            return False
    if 'Third-Party' in components_involved:
        if not st.session_state.get('ctx_third_party_involvement_sidebar_global', ''):
            return False
            
    return True

# Function to clear follow-up question states when component selection changes
def components_changed_callback():
    # Clear all follow-up question states
    for key in followup_widget_keys:
        if key in st.session_state:
            st.session_state.pop(key, None)
    
    # Clear follow-up questions from context
    if 'infrastructure_changes' in st.session_state.current_context:
        del st.session_state.current_context['infrastructure_changes']
    if 'third_party_involvement' in st.session_state.current_context:
        del st.session_state.current_context['third_party_involvement']
    
    # Reset assessment details as context has changed
    st.session_state.assessment_result = None
    st.session_state.assessment_id = None
    st.session_state.current_requirement_text = ""
    st.session_state.similar_requirements = []

# Function to clear conditional fields when change type changes
def change_type_changed_callback():
    # Clear conditional fields that depend on change type
    conditional_fields = ['ctx_customization_level_sidebar_global', 'ctx_performance_issues_sidebar_global']
    for key in conditional_fields:
        if key in st.session_state:
            st.session_state.pop(key, None)
    
    # Clear from context as well
    if 'customization_level' in st.session_state.current_context:
        del st.session_state.current_context['customization_level']
    if 'performance_issues' in st.session_state.current_context:
        del st.session_state.current_context['performance_issues']
    
    # Reset assessment details as context has changed
    st.session_state.assessment_result = None
    st.session_state.assessment_id = None
    st.session_state.current_requirement_text = ""
    st.session_state.similar_requirements = []

# --- Sidebar (Contextual Info always visible, API key always visible) ---
st.sidebar.header("Configuration")
# api_key variable is local to this scope, session state holds the persistent value
st.sidebar.text_input("Enter OpenAI API Key: *", type="password", key="api_key_input_global", help="Your OpenAI API key is required for analysis.")
st.sidebar.header("Contextual Information (for New Assessment)")
st.sidebar.markdown("##### All fields are mandatory *")

# 1. Project Name
st.session_state.current_context['project_name'] = st.sidebar.text_input(
    "1. Project Name: *", 
    help="Enter the name of the project",
    key='ctx_project_name_sidebar_global'
)

# 2. Describe the Type of Change
st.session_state.current_context['change_type'] = st.sidebar.radio(
    "2. Describe the Type of Change: *",
    ('New Change (New Feature/Application)', 
     'Enhancement (Upgrade Existing Feature)', 
     'Modification (Defect Fixes... etc.)'),
    key='ctx_change_type_sidebar_global',
    on_change=change_type_changed_callback,
    help="Select the type of change being implemented"
)

# 3. Name of the Application/Component
st.session_state.current_context['application_component_name'] = st.sidebar.text_input(
    "3. Name of the Application/Component: *", 
    help="Enter the name of the application or component involved",
    key='ctx_application_component_name_sidebar_global'
)

# 4. Components Involved in the Change
st.sidebar.markdown("4. Components Involved in the Change: * (Select all that apply)")
component_options = ['User Interface', 'Backend Change', 'Batch Jobs', 'Infrastructure', 'Third-Party']
selected_components = []
for option in component_options:
    if st.sidebar.checkbox(
        option, 
        key=f'ctx_component_{option.replace(" ", "_").replace("-", "_").lower()}_sidebar_global',
        on_change=components_changed_callback,
        help=("Select if there is any change in:\n"
              "- User Interface: Web/Application Interface, Public Site, mobile UI\n"
              "- Backend Change: Code-level change (Cross Layer, SOA, API, Database)\n"
              "- Batch Jobs: Daily, weekly, or monthly jobs\n"
              "- Infrastructure: Host servers, Database, Network, Architecture\n"
              "- Third-Party: Systems like Fiserv, Experian, Vocalink, etc.")
    ):
        selected_components.append(option)
st.session_state.current_context['components_involved'] = selected_components

# Follow-up questions based on component selection
components_involved = st.session_state.current_context.get('components_involved', [])

if 'Infrastructure' in components_involved:
    st.sidebar.markdown("**Follow-up for Infrastructure:**")
    st.session_state.current_context['infrastructure_changes'] = st.sidebar.text_area(
        "Brief about the infra changes (Database migration, Cloud platform changes, subscription changes, etc.): *",
        height=100,
        key='ctx_infrastructure_changes_sidebar_global'
    )

if 'Third-Party' in components_involved:
    st.sidebar.markdown("**Follow-up for Third-Party:**")
    st.session_state.current_context['third_party_involvement'] = st.sidebar.text_area(
        "Brief about third-party involvement (Fiserv, Experian, Vocalink etc.): *",
        height=100,
        key='ctx_third_party_involvement_sidebar_global'
    )

# 5. Expected Volume of Business-Critical Process/Flow
business_critical_volume = st.sidebar.radio(
    "5. Expected Volume of Business-Critical Process/Flow: *",
    ('<1K (Transactions Daily)', '1K to 5K (Transactions Daily)', '>5K (Transactions Daily)', 'Others'),
    key='ctx_business_critical_volume_sidebar_global',
    help="Select the expected daily transaction volume for your process/flow"
)

if business_critical_volume == 'Others':
    st.session_state.current_context['business_critical_volume_other'] = st.sidebar.text_input(
        "Specify other volume details: *",
        key='ctx_business_critical_volume_other_sidebar_global'
    )
    # Update main value to include the custom input
    if st.session_state.current_context.get('business_critical_volume_other'):
        st.session_state.current_context['business_critical_volume'] = f"Others: {st.session_state.current_context['business_critical_volume_other']}"
else:
    # Clear the other field if not selected
    if 'business_critical_volume_other' in st.session_state.current_context:
        del st.session_state.current_context['business_critical_volume_other']
    st.session_state.current_context['business_critical_volume'] = business_critical_volume

# 6. Expected Response Time SLA
response_time_sla = st.sidebar.radio(
    "6. Expected Response Time SLA: *",
    ('<1 second', '1 to 3 seconds', '>3 seconds', 'Others'),
    key='ctx_response_time_sla_sidebar_global',
    help="Select the expected response time Service Level Agreement"
)

if response_time_sla == 'Others':
    st.session_state.current_context['response_time_sla_other'] = st.sidebar.text_input(
        "Specify other SLA details: *",
        key='ctx_response_time_sla_other_sidebar_global'
    )
    # Update main value to include the custom input
    if st.session_state.current_context.get('response_time_sla_other'):
        st.session_state.current_context['response_time_sla'] = f"Others: {st.session_state.current_context['response_time_sla_other']}"
else:
    # Clear the other field if not selected
    if 'response_time_sla_other' in st.session_state.current_context:
        del st.session_state.current_context['response_time_sla_other']
    st.session_state.current_context['response_time_sla'] = response_time_sla

# 7. Expected Growth Rate Over the Next Year
growth_rate = st.sidebar.radio(
    "7. Expected Growth Rate Over the Next Year: *",
    ('<=5%', '5% to 15%', '15% to 25%', '>25%', 'Others'),
    key='ctx_expected_growth_rate_sidebar_global',
    help="Select the expected growth rate over the next year"
)

if growth_rate == 'Others':
    st.session_state.current_context['growth_rate_other'] = st.sidebar.text_input(
        "Specify other growth rate details: *",
        key='ctx_growth_rate_other_sidebar_global'
    )
    # Update main value to include the custom input
    if st.session_state.current_context.get('growth_rate_other'):
        st.session_state.current_context['growth_rate'] = f"Others: {st.session_state.current_context['growth_rate_other']}"
else:
    # Clear the other field if not selected
    if 'growth_rate_other' in st.session_state.current_context:
        del st.session_state.current_context['growth_rate_other']
    st.session_state.current_context['growth_rate'] = growth_rate

# 8. Level of Customization/Modification (only for non-new changes)
change_type = st.session_state.current_context.get('change_type', '')
if change_type != 'New Change (New Feature/Application)':
    st.session_state.current_context['customization_level'] = st.sidebar.radio(
        "8. Level of Customization/Modification Done as Part of the Change: *",
        ('Minimal', 'Moderate', 'Significant'),
        key='ctx_customization_level_sidebar_global',
        help="Select the level of customization or modification required"
    )
else:
    # Clear the field if it exists and change type is "New Change"
    if 'customization_level' in st.session_state.current_context:
        del st.session_state.current_context['customization_level']
    # Also clear from session state
    if 'ctx_customization_level_sidebar_global' in st.session_state:
        del st.session_state['ctx_customization_level_sidebar_global']

# 9. Channel/Component Impacted
st.session_state.current_context['channel_impact'] = st.sidebar.text_input(
    "9. Channel/Component Impacted by the Change: *",
    key='ctx_channel_impact_sidebar_global',
    help="Specify the channel or component impacted by this change"
)

# 10. Performance/Scalability Issues (only for non-new changes)
if change_type != 'New Change (New Feature/Application)':
    st.session_state.current_context['performance_issues'] = st.sidebar.radio(
        "10. Performance/Scalability Issues in Current Production Environment: *",
        ('Yes', 'No'),
        key='ctx_performance_issues_sidebar_global',
        help="Indicate if there are any current performance or scalability issues"
    )
else:
    # Clear the field if it exists and change type is "New Change"
    if 'performance_issues' in st.session_state.current_context:
        del st.session_state.current_context['performance_issues']
    # Also clear from session state
    if 'ctx_performance_issues_sidebar_global' in st.session_state:
        del st.session_state['ctx_performance_issues_sidebar_global']

# 11. Business Disruption Impact
st.session_state.current_context['business_disruption'] = st.sidebar.radio(
    "11. Potential Business Disruption Due to Change Failure: *",
    ('Yes – Slows down the application', 'Yes – Completely stops the application', 'No'),
    key='ctx_business_disruption_sidebar_global',
    help="Select the potential impact of a change failure on business operations"
)

# 12. Contingency Plans
st.session_state.current_context['contingency_plans'] = st.sidebar.radio(
    "12. Contingency Plans for Business Continuity: *",
    ('Yes', 'No'),
    key='ctx_contingency_plans_sidebar_global',
    help="Indicate if contingency plans are in place"
)

# 13. Assessment Coverage
st.sidebar.markdown("13. Assessment Coverage: * (Select all that apply)")
assessment_options = ['Performance Testing (Load, Stress, etc.)', 'Device Level Testing', 'OAT', 'Accessibility', 'Security', 'All Non-Functional Testing']
selected_assessments = []
for option in assessment_options:
    if st.sidebar.checkbox(option, key=f'ctx_assessment_{option.replace(" ", "_").replace("(", "").replace(")", "").replace(",", "").lower()}_sidebar_global'):
        selected_assessments.append(option)
st.session_state.current_context['assessment_coverage'] = selected_assessments

# Check if all fields are filled after any change
st.session_state.all_fields_filled = check_mandatory_fields()

# Display a message about mandatory fields if not all filled
if not st.session_state.all_fields_filled:
    st.sidebar.warning("⚠️ All fields marked with * are mandatory. Please fill them all to proceed.")

# --- AI Transparency Section ---
st.sidebar.markdown("---")
st.sidebar.header("🔍 AI Interaction Transparency")

with st.sidebar.expander("View AI Interactions", expanded=True):  # Set to expanded=True for debugging
    st.markdown("**AI Interactions:**")
    
    # Get current session interactions
    try:
        # Import necessary modules
        from core.ai_interaction_logger import ai_logger, get_session_identifier
        from core.ai_interaction_wrapper import get_current_session_interactions
        import sqlite3
        import time
        
        session_id = get_session_identifier()
        
        # Check if database exists
        import os
        if not os.path.exists(ai_logger.db_path):
            st.warning(f"Database not found at: {ai_logger.db_path}")
        else:
            try:
                # Connect to database to get counts
                conn = sqlite3.connect(ai_logger.db_path)
                cursor = conn.cursor()
                cursor.execute('SELECT COUNT(*) FROM ai_interactions')
                total_count = cursor.fetchone()[0]
                cursor.execute('SELECT COUNT(*) FROM ai_interactions WHERE session_id = ?', (session_id,))
                session_count = cursor.fetchone()[0]
                
                # Get most recent timestamp to check for recent activity
                cursor.execute('SELECT timestamp_utc FROM ai_interactions ORDER BY timestamp_utc DESC LIMIT 1')
                most_recent = cursor.fetchone()
                conn.close()
                
                if most_recent:
                    st.info(f"Total interactions in DB: {total_count}, Current session interactions: {session_count}")
                    # Removed the warning message about session having no interactions
                else:
                    # Removed the warning about no interactions in database
                    pass
            except Exception as e:
                st.warning(f"Database error: {str(e)}")
            
        # Get interactions (enhanced function will fall back to recent interactions if current session has none)
        session_interactions = get_current_session_interactions()
        
        if session_interactions and len(session_interactions) > 0:
            st.success(f"Showing {min(5, len(session_interactions))} of {len(session_interactions)} interactions")
            
            for i, interaction in enumerate(session_interactions[:5], 1):  # Show first 5 (most recent)
                interaction_time = interaction.get('timestamp_utc', 'Unknown')
                interaction_type = interaction.get('interaction_type', 'Unknown')
                model_used = interaction.get('model_used', 'Unknown')
                success = interaction.get('success', False)
                interaction_session = interaction.get('session_id', 'Unknown')
                
                status_icon = "✅" if success else "❌"
                st.markdown(f"**{i}. {status_icon} {interaction_type}**")
                st.text(f"   Time: {interaction_time}")
                st.text(f"   Model: {model_used}")
                if interaction_session != session_id:
                    st.text(f"   Note: From different session")
                
                if st.button(f"View Details #{i}", key=f"view_interaction_{i}"):
                    st.text_area(
                        "Prompt:", 
                        interaction.get('prompt_text', 'N/A')[:200] + "..." if len(interaction.get('prompt_text', '')) > 200 else interaction.get('prompt_text', 'N/A'),
                        height=100,
                        disabled=True
                    )
                    st.text_area(
                        "Response:", 
                        interaction.get('response_text', 'N/A')[:200] + "..." if len(interaction.get('response_text', '')) > 200 else interaction.get('response_text', 'N/A'),
                        height=100,
                        disabled=True
                    )
                st.markdown("---")
        else:
            # Removed the warning messages about no AI interactions found
            pass
            
        # Export functionality
        if st.button("📊 Export AI Interaction Report"):
            try:
                report_data = get_ai_transparency_report()
                if report_data:
                    st.download_button(
                        label="💾 Download Report (JSON)",
                        data=json.dumps(report_data, indent=2),
                        file_name=f"ai_interactions_report_{int(time.time())}.json",
                        mime="application/json"
                    )
                else:
                    st.info("No interactions to export")
            except Exception as e:
                st.error(f"Export failed: {str(e)}")
                
    except Exception as e:
        st.error(f"Error loading AI interactions: {str(e)}")

# Logging configuration
with st.sidebar.expander("AI Logging Settings", expanded=False):
    st.markdown("**Logging Configuration:**")
    
    # Add toggle for logging (future enhancement)
    logging_enabled = st.checkbox("Enable AI Interaction Logging", value=True, disabled=True)
    st.info("AI interaction logging is currently always enabled for transparency")
    
    # Show database info
    try:
        from core.ai_interaction_logger import ai_logger
        total_interactions = len(ai_logger.get_session_interactions(get_session_identifier()))
        st.metric("Current Session Interactions", total_interactions)
    except Exception as e:
        st.text("Logging system status: Unknown")

# --- Main App Area with Tabs ---
tab1, tab2, tab3, tab4 = st.tabs(["New Assessment", "Previous Results", "Risk Dashboard", "Learning Analytics"])

# Handle tab selection state from other tabs
if st.session_state.get("dashboard_tab_selected", False):
    tab3.selectbox = True
    st.session_state.dashboard_tab_selected = False

with tab1:
    st.header("Submit New Requirement")
    
    # Display a notice at the top if fields aren't filled
    if not st.session_state.all_fields_filled:
        st.warning("⚠️ Please fill all mandatory fields in the sidebar before proceeding.")
    
    # Feature 1: Add Application Overview Text Box
    st.subheader("📝 Application Overview")
    st.markdown("*Provide a brief background of the application under scope assessment to improve AI analysis accuracy.*")
    
    # Initialize application overview in session state if not exists
    if 'application_overview' not in st.session_state:
        st.session_state.application_overview = ""
    
    application_overview = st.text_area(
        "Application Overview:",
        height=120,
        placeholder="Example: This is a customer-facing e-commerce platform built on microservices architecture, handling payment processing, user authentication, and order management. The system serves 10,000+ daily users and requires high availability...",
        key='application_overview_input',
        help="Describe the application's purpose, architecture, key functionalities, user base, performance requirements, and any critical business aspects. This context helps the AI provide more accurate scope assessments."
    )
    
    # Store in session state
    st.session_state.application_overview = application_overview
    
    st.markdown("---")
    
    input_method = st.radio("Choose input method:", ("Upload File", "Enter Text Manually", "Bulk Upload (CSV)"), horizontal=True, key="input_method_choice_tab1")
    uploaded_file = None
    manual_text = ""

    if input_method == "Upload File":
        uploaded_file = st.file_uploader("Upload Requirement Document (.txt or .docx)", type=['txt', 'docx'], key='file_uploader_tab1_single')
        if uploaded_file: 
            st.session_state.manual_text_tab1 = ""
            st.session_state.batch_assessment_results = [] # Clear batch results
    elif input_method == "Enter Text Manually":
        # Show the requirement text area
        manual_text = st.text_area("Enter Requirement Text:", height=200, key='manual_text_tab1')
        st.session_state.batch_assessment_results = [] # Clear batch results
    elif input_method == "Bulk Upload (CSV)":
        uploaded_file = st.file_uploader("Upload CSV file with a 'requirement_text' column", type=['csv'], key='file_uploader_tab1_bulk')
        st.info("Ensure your CSV has a column named 'requirement_text' (or similar like 'Requirement Text', 'requirement'). Context from the sidebar will be applied to all requirements in the file.")
        if uploaded_file:
            st.session_state.manual_text_tab1 = "" # Clear manual text
            st.session_state.assessment_result = None # Clear single assessment result
            st.session_state.assessment_id = None

    # Determine if analysis button should be enabled
    button_disabled = not st.session_state.all_fields_filled
    if input_method == "Enter Text Manually":
        button_disabled = not st.session_state.all_fields_filled or not manual_text.strip()
    elif input_method == "Bulk Upload (CSV)":
        if not uploaded_file: # Disable if no file is uploaded for bulk
            button_disabled = True
    elif input_method == "Upload File":
        if not uploaded_file: # Disable if no file is uploaded for single
            button_disabled = True

    # Disable the analyze button if mandatory fields aren't filled
    analyze_button = st.button("Analyze Requirement(s)", key="analyze_button_tab1", disabled=button_disabled)

    # If the NFT chat gathering is active, show the chat interface
    if st.session_state.nft_chat_active and not st.session_state.nft_gather_complete:
        # If we have questions in the queue, process them
        if st.session_state.nft_questions:
            current_question = st.session_state.nft_questions[0]
            handle_nft_chat(current_question, st.session_state.api_key_input_global)
        else:
            # If we run out of questions before marking complete, mark as complete
            st.session_state.nft_gather_complete = True
            st.rerun()
    
    # If we've just completed gathering NFT information, proceed with the assessment
    elif st.session_state.nft_chat_active and st.session_state.nft_gather_complete:
        # Reset the chat state after gathering info
        st.session_state.nft_chat_active = False
        
        # Add the gathered information to the context and requirement
        # Update current requirement text with gathered additional information
        if st.session_state.nft_additional_info and st.session_state.current_requirement_text:
            enhanced_requirement = f"{st.session_state.current_requirement_text}\n\nAdditional NFT-Specific Information:\n{st.session_state.nft_additional_info}"
            st.session_state.current_requirement_text = enhanced_requirement
            st.session_state.current_context['NFT Additional Information'] = st.session_state.nft_additional_info
            
        # Now proceed with the comprehensive analysis using the enhanced information
        with st.spinner("Performing comprehensive NFT assessment with all gathered information..."):
            try:
                current_api_key = st.session_state.api_key_input_global
                requirement_text = st.session_state.current_requirement_text
                context = st.session_state.current_context
                
                # Get similar requirements
                collection = chroma_logic.get_or_create_collection(current_api_key)
                embedding = wrapped_generate_embedding(requirement_text, current_api_key)
                st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                    collection,
                    embedding,
                    n_results=chroma_logic.DEFAULT_N_RESULTS,
                    custom_threshold=chroma_logic.DEFAULT_SIMILARITY_THRESHOLD
                )
                
                # Add application overview to context
                context_for_prompt = dict(context)  # Create a copy of the context
                if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                    context_for_prompt["Application Overview"] = st.session_state.application_overview
                
                # Compose enhanced prompt with all gathered information
                prompt = gpt_logic.EnhancedPromptComposer.compose_enhanced_prompt(
                    requirement_text=requirement_text,
                    context=context_for_prompt,
                    similar_requirements=st.session_state.similar_requirements,
                    user_selected_testing_types=context.get('assessment_coverage')
                )
                
                # Get final assessment
                gpt_response = wrapped_get_gpt_assessment(
                    prompt, 
                    current_api_key, 
                    "gpt-4o",
                    context.get('assessment_coverage')
                )
                
                if gpt_response and "error" in gpt_response:
                    st.error(f"Analysis failed: {gpt_response['error']}")
                    st.session_state.assessment_result = None
                    st.session_state.assessment_id = None
                elif gpt_response:
                    st.session_state.assessment_result = gpt_response
                    doc_id = chroma_logic.add_assessment(
                        collection, requirement_text, embedding,
                        gpt_response.get('risk'), gpt_response.get('reasoning'),
                        gpt_response.get('recommendations'), gpt_response.get('impact'),
                        context.get('project_name', 'N/A')
                    )
                    st.session_state.assessment_id = doc_id
                    if doc_id:
                        st.success("NFT assessment complete!")
                        # Clean up the NFT chat session
                        st.session_state.nft_additional_info = ""
                        st.session_state.nft_gather_complete = False
                        st.session_state.nft_chat_history = []
                        st.rerun()
                    else:
                        st.error("Failed to save to database.")
                else:
                    st.error("Analysis failed. No response.")
                    st.session_state.assessment_result = None
                    st.session_state.assessment_id = None
                    
            except Exception as e:
                st.error(f"Analysis error: {e}")
                st.session_state.assessment_result = None
                st.session_state.assessment_id = None

    if analyze_button:
        st.session_state.batch_assessment_results = [] # Clear previous batch results
        st.session_state.assessment_result = None # Clear single result
        st.session_state.assessment_id = None
        
        # Reset NFT chat state when starting a new analysis
        st.session_state.nft_chat_active = False
        st.session_state.nft_gather_complete = False
        st.session_state.nft_chat_history = []
        st.session_state.nft_questions = []
        st.session_state.nft_additional_info = ""

        if input_method == "Bulk Upload (CSV)" and uploaded_file is not None:
            # Handle bulk upload - existing code...
            requirements_list, error_msg = file_parser.parse_file(uploaded_file)
            if error_msg:
                st.error(error_msg)
            elif not requirements_list:
                st.warning("No requirements found in the CSV file or the 'requirement_text' column is empty.")
            else:
                # Process batch requirements - existing code...
                pass

        elif input_method == "Upload File" and uploaded_file is not None:
            try:
                requirement_text, error_msg = file_parser.parse_file(uploaded_file)
                if error_msg:
                    st.error(error_msg)
                    requirement_text = None
                if requirement_text is None and not error_msg: 
                    st.error("Could not extract text from the file.")
                    requirement_text = None
            except Exception as e: 
                st.error(f"Error reading file: {e}")
                requirement_text = None
                
            st.session_state.current_requirement_text = requirement_text
            
            # Process single requirement with NFT chat assistance
            if requirement_text:
                # Store context in session state
                st.session_state.current_context = {
                    'project_name': st.session_state.get('ctx_project_name_sidebar_global', ''),
                    'change_type': st.session_state.get('ctx_change_type_sidebar_global', ''),
                    'component_name': st.session_state.get('ctx_application_component_name_sidebar_global', ''),
                    'components_involved': st.session_state.get('components_involved', []),
                    'customization_level': st.session_state.get('ctx_customization_level_sidebar_global', ''),
                    'channel_impact': st.session_state.get('ctx_channel_impact_sidebar_global', ''),
                    'performance_issues': st.session_state.get('ctx_performance_issues_sidebar_global', ''),
                    'business_disruption': st.session_state.get('ctx_business_disruption_sidebar_global', ''),
                    'contingency_plans': st.session_state.get('ctx_contingency_plans_sidebar_global', ''),
                    'assessment_coverage': st.session_state.get('assessment_coverage', []),
                    'application_overview': st.session_state.get('application_overview', '')
                }
                
                # First check if we need to gather more NFT information
                sufficient, assessment_details = is_nft_info_sufficient(requirement_text, st.session_state.current_context)
                
                if not sufficient:
                    # Get NFT-specific questions
                    nft_questions = generate_nft_questions(requirement_text, st.session_state.current_context, st.session_state.api_key_input_global)
                    
                    # If we have questions, activate the NFT chat assistant
                    if nft_questions:
                        st.session_state.nft_chat_active = True
                        st.session_state.nft_questions = nft_questions
                        st.rerun()  # Rerun to show the chat interface
                    else:
                        # If no questions are needed, proceed directly with assessment
                        st.success("NFT information is sufficient. Proceeding with assessment...")
                        
                        # Proceed directly with comprehensive analysis
                        with st.spinner("Performing comprehensive NFT assessment..."):
                            try:
                                current_api_key = st.session_state.api_key_input_global
                                context = st.session_state.current_context
                                
                                # Add application overview to context
                                if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                                    context["Application Overview"] = st.session_state.application_overview
                                
                                # Get similar requirements
                                collection = chroma_logic.get_or_create_collection(current_api_key)
                                embedding = wrapped_generate_embedding(requirement_text, current_api_key)
                                st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                                    collection,
                                    embedding,
                                    n_results=chroma_logic.DEFAULT_N_RESULTS,
                                    custom_threshold=chroma_logic.DEFAULT_SIMILARITY_THRESHOLD
                                )
                                
                                # Compose enhanced prompt
                                prompt = gpt_logic.EnhancedPromptComposer.compose_enhanced_prompt(
                                    requirement_text=requirement_text,
                                    context=context,
                                    similar_requirements=st.session_state.similar_requirements,
                                    user_selected_testing_types=context.get('assessment_coverage')
                                )
                                
                                # Get assessment
                                gpt_response = wrapped_get_gpt_assessment(
                                    prompt, 
                                    current_api_key, 
                                    "gpt-4o",
                                    context.get('assessment_coverage')
                                )
                                
                                if gpt_response and "error" in gpt_response:
                                    st.error(f"Analysis failed: {gpt_response['error']}")
                                elif gpt_response:
                                    st.session_state.assessment_result = gpt_response
                                    doc_id = chroma_logic.add_assessment(
                                        collection, requirement_text, embedding,
                                        gpt_response.get('risk'), gpt_response.get('reasoning'),
                                        gpt_response.get('recommendations'), gpt_response.get('impact'),
                                        context.get('project_name', 'N/A')
                                    )
                                    st.session_state.assessment_id = doc_id
                                    if doc_id:
                                        st.success("NFT assessment complete!")
                                    else:
                                        st.error("Failed to save to database.")
                                else:
                                    st.error("Analysis failed. No response.")
                            
                            except Exception as e:
                                st.error(f"Analysis error: {e}")
                                import traceback
                                st.error(traceback.format_exc())
                else:
                    # If sufficient info, proceed directly with assessment
                    # Code for direct assessment...
                    pass
                
                # Start the assessment process
                with st.spinner("Analyzing requirement..."):
                    try:
                        current_api_key = st.session_state.api_key_input_global
                        
                        # Standard assessment flow when NFT chat isn't active
                        if not st.session_state.nft_chat_active:
                            collection = chroma_logic.get_or_create_collection(current_api_key)
                            embedding = wrapped_generate_embedding(requirement_text, current_api_key)
                            st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                                collection,
                                embedding,
                                n_results=chroma_logic.DEFAULT_N_RESULTS,
                                custom_threshold=chroma_logic.DEFAULT_SIMILARITY_THRESHOLD
                            )
                            
                            context_for_prompt = dict(st.session_state.current_context)
                            if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                                context_for_prompt["Application Overview"] = st.session_state.application_overview
                            
                            prompt = gpt_logic.EnhancedPromptComposer.compose_enhanced_prompt(
                                requirement_text=requirement_text,
                                context=context_for_prompt,
                                similar_requirements=st.session_state.similar_requirements,
                                user_selected_testing_types=context_for_prompt.get('assessment_coverage')
                            )
                            
                            gpt_response = wrapped_get_gpt_assessment(
                                prompt, 
                                current_api_key, 
                                "gpt-4o",
                                context_for_prompt.get('assessment_coverage')
                            )
                            
                            if gpt_response and "error" in gpt_response:
                                st.error(f"Analysis failed: {gpt_response['error']}")
                                st.session_state.assessment_result = None
                                st.session_state.assessment_id = None
                            elif gpt_response:
                                st.session_state.assessment_result = gpt_response
                                doc_id = chroma_logic.add_assessment(
                                    collection, requirement_text, embedding,
                                    gpt_response.get('risk'), gpt_response.get('reasoning'),
                                    gpt_response.get('recommendations'), gpt_response.get('impact'),
                                    context_for_prompt.get('project_name', 'N/A')
                                )
                                st.session_state.assessment_id = doc_id
                                if doc_id: st.success("Analysis complete!")
                                else: st.error("Failed to save to database.")
                            else:
                                st.error("Analysis failed. No response.")
                                st.session_state.assessment_result = None
                                st.session_state.assessment_id = None
                    except Exception as e:
                        st.error(f"Analysis error: {e}")
                        st.session_state.assessment_result = None
                        st.session_state.assessment_id = None

        elif input_method == "Enter Text Manually":
            requirement_text = manual_text
            st.session_state.current_requirement_text = requirement_text
            
            # Process manual text input with NFT chat assistance
            if requirement_text:
                # Store context in session state
                st.session_state.current_context = {
                    'project_name': st.session_state.get('ctx_project_name_sidebar_global', ''),
                    'change_type': st.session_state.get('ctx_change_type_sidebar_global', ''),
                    'component_name': st.session_state.get('ctx_application_component_name_sidebar_global', ''),
                    'components_involved': st.session_state.get('components_involved', []),
                    'customization_level': st.session_state.get('ctx_customization_level_sidebar_global', ''),
                    'channel_impact': st.session_state.get('ctx_channel_impact_sidebar_global', ''),
                    'performance_issues': st.session_state.get('ctx_performance_issues_sidebar_global', ''),
                    'business_disruption': st.session_state.get('ctx_business_disruption_sidebar_global', ''),
                    'contingency_plans': st.session_state.get('ctx_contingency_plans_sidebar_global', ''),
                    'assessment_coverage': st.session_state.get('assessment_coverage', []),
                    'application_overview': st.session_state.get('application_overview', '')
                }
                
                # First check if we need to gather more NFT information
                sufficient, assessment_details = is_nft_info_sufficient(requirement_text, st.session_state.current_context)
                
                if not sufficient:
                    # Get NFT-specific questions
                    nft_questions = generate_nft_questions(requirement_text, st.session_state.current_context, st.session_state.api_key_input_global)
                    
                    # If we have questions, activate the NFT chat assistant
                    if nft_questions:
                        st.session_state.nft_chat_active = True
                        st.session_state.nft_questions = nft_questions
                        st.rerun()  # Rerun to show the chat interface
                    else:
                        # If no questions are needed, proceed directly with assessment
                        st.success("NFT information is sufficient. Proceeding with assessment...")
                        
                        # Proceed directly with comprehensive analysis
                        with st.spinner("Performing comprehensive NFT assessment..."):
                            try:
                                current_api_key = st.session_state.api_key_input_global
                                context = st.session_state.current_context
                                
                                # Add application overview to context
                                if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                                    context["Application Overview"] = st.session_state.application_overview
                                
                                # Get similar requirements
                                collection = chroma_logic.get_or_create_collection(current_api_key)
                                embedding = wrapped_generate_embedding(requirement_text, current_api_key)
                                st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                                    collection,
                                    embedding,
                                    n_results=chroma_logic.DEFAULT_N_RESULTS,
                                    custom_threshold=chroma_logic.DEFAULT_SIMILARITY_THRESHOLD
                                )
                                
                                # Compose enhanced prompt
                                prompt = gpt_logic.EnhancedPromptComposer.compose_enhanced_prompt(
                                    requirement_text=requirement_text,
                                    context=context,
                                    similar_requirements=st.session_state.similar_requirements,
                                    user_selected_testing_types=context.get('assessment_coverage')
                                )
                                
                                # Get assessment
                                gpt_response = wrapped_get_gpt_assessment(
                                    prompt, 
                                    current_api_key, 
                                    "gpt-4o",
                                    context.get('assessment_coverage')
                                )
                                
                                if gpt_response and "error" in gpt_response:
                                    st.error(f"Analysis failed: {gpt_response['error']}")
                                elif gpt_response:
                                    st.session_state.assessment_result = gpt_response
                                    doc_id = chroma_logic.add_assessment(
                                        collection, requirement_text, embedding,
                                        gpt_response.get('risk'), gpt_response.get('reasoning'),
                                        gpt_response.get('recommendations'), gpt_response.get('impact'),
                                        context.get('project_name', 'N/A')
                                    )
                                    st.session_state.assessment_id = doc_id
                                    if doc_id:
                                        st.success("NFT assessment complete!")
                                    else:
                                        st.error("Failed to save to database.")
                                else:
                                    st.error("Analysis failed. No response.")
                            
                            except Exception as e:
                                st.error(f"Analysis error: {e}")
                                import traceback
                                st.error(traceback.format_exc())
                else:
                    # If sufficient info, proceed directly with assessment
                    # Code for direct assessment...
                    pass
                
                # Start the assessment process
                with st.spinner("Analyzing requirement..."):
                    try:
                        current_api_key = st.session_state.api_key_input_global
                        
                        # Standard assessment flow when NFT chat isn't active
                        if not st.session_state.nft_chat_active:
                            collection = chroma_logic.get_or_create_collection(current_api_key)
                            embedding = wrapped_generate_embedding(requirement_text, current_api_key)
                            st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                                collection,
                                embedding,
                                n_results=chroma_logic.DEFAULT_N_RESULTS,
                                custom_threshold=chroma_logic.DEFAULT_SIMILARITY_THRESHOLD
                            )
                            
                            context_for_prompt = dict(st.session_state.current_context)
                            if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                                context_for_prompt["Application Overview"] = st.session_state.application_overview
                            
                            prompt = gpt_logic.EnhancedPromptComposer.compose_enhanced_prompt(
                                requirement_text=requirement_text,
                                context=context_for_prompt,
                                similar_requirements=st.session_state.similar_requirements,
                                user_selected_testing_types=context_for_prompt.get('assessment_coverage')
                            )
                            
                            gpt_response = wrapped_get_gpt_assessment(
                                prompt, 
                                current_api_key, 
                                "gpt-4o",
                                context_for_prompt.get('assessment_coverage')
                            )
                            
                            if gpt_response and "error" in gpt_response:
                                st.error(f"Analysis failed: {gpt_response['error']}")
                                st.session_state.assessment_result = None
                                st.session_state.assessment_id = None
                            elif gpt_response:
                                st.session_state.assessment_result = gpt_response
                                doc_id = chroma_logic.add_assessment(
                                    collection, requirement_text, embedding,
                                    gpt_response.get('risk'), gpt_response.get('reasoning'),
                                    gpt_response.get('recommendations'), gpt_response.get('impact'),
                                    context_for_prompt.get('project_name', 'N/A')
                                )
                                st.session_state.assessment_id = doc_id
                                if doc_id: st.success("Analysis complete!")
                                else: st.error("Failed to save to database.")
                            else:
                                st.error("Analysis failed. No response.")
                                st.session_state.assessment_result = None
                                st.session_state.assessment_id = None
                    except Exception as e:
                        st.error(f"Analysis error: {e}")
                        st.session_state.assessment_result = None
                        st.session_state.assessment_id = None

    # No longer need to handle AI chat display

    # Display assessment results if available
    if st.session_state.assessment_result and "error" not in st.session_state.assessment_result and input_method != "Bulk Upload (CSV)":
        st.markdown("---")
        
        # Add requirement quality check section
        st.header("Requirement Quality Analysis")
        
        # Get requirement text from session state
        req_text = st.session_state.current_requirement_text
        
        # Perform basic quality check first (this doesn't require API call)
        basic_quality = req_quality_checker.perform_basic_quality_checks(req_text)
        
        # Display basic checks in an expander
        with st.expander("Basic Quality Checks", expanded=True):
            if basic_quality["warnings"]:
                for warning in basic_quality["warnings"]:
                    st.warning(warning)
            else:
                st.success("No basic quality issues detected.")
            
            # Show word count
            st.info(f"Word count: {basic_quality['simple_checks'].get('word_count', 0)}")
        
        # Comprehensive quality analysis with AI
        with st.spinner("Analyzing requirement quality..."):
            quality_results = wrapped_analyze_requirement_quality(
                req_text, 
                st.session_state.current_context,
                st.session_state.api_key_input_global
            )
        
        if "error" in quality_results:
            st.error(f"Quality analysis error: {quality_results['error']}")
        else:
            # Create columns for the quality scores
            st.subheader("Quality Scores")
            
            # Get scores
            scores = quality_results.get("scores", {})
            
            # Create a progress bar for the overall score
            overall = scores.get("overall", 0)
            overall_color = "#ff5252" if overall < 4 else "#FFC107" if overall < 7 else "#4CAF50"
            
            st.markdown(f"### Overall Quality: {overall}/10")
            st.progress(overall/10, text=f"{overall}/10")
            
            # Create columns for individual metrics
            cols = st.columns(5)
            
            # Define the metrics to display
            metrics = ["clarity", "testability", "completeness", "consistency", "traceability"]
            
            # Display each metric in a column
            for i, metric in enumerate(metrics):
                score = scores.get(metric, 0)
                cols[i].metric(
                    metric.capitalize(), 
                    f"{score}/10",
                    delta=None
                )
            
            # Display analysis and suggestions
            st.subheader("Analysis & Improvement Suggestions")
            
            # Create tabs for each quality aspect
            quality_tabs = st.tabs(["Clarity", "Testability", "Completeness", "Consistency", "Traceability"])
            
            for i, metric in enumerate(metrics):
                with quality_tabs[i]:
                    # Display analysis
                    st.markdown(f"**Analysis:**")
                    st.info(quality_results.get("analysis", {}).get(metric, "No analysis available."))
                    
                    # Display suggestions
                    st.markdown(f"**Improvement Suggestions:**")
                    suggestions = quality_results.get("suggestions", {}).get(metric, [])
                    if suggestions:
                        for j, suggestion in enumerate(suggestions):
                            st.markdown(f"- {suggestion}")
                    else:
                        st.markdown("No specific suggestions available.")
        
        st.markdown("---")
        st.markdown("""
        <style>
        .risk-assessment-header {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #1E3A8A;
            border-bottom: 2px solid #3B82F6;
            padding-bottom: 8px;
        }
        .risk-level {
            font-size: 22px;
            font-weight: 500;
            margin-bottom: 15px;
        }
        .section-header {
            font-size: 20px;
            font-weight: 500;
            margin-top: 25px;
            margin-bottom: 15px;
            color: #1E3A8A;
            background-color: #F3F4F6;
            padding: 8px 12px;
            border-radius: 5px;
        }
        .subsection-header {
            font-size: 18px;
            font-weight: 500;
            margin-top: 18px;
            margin-bottom: 12px;
        }
        .content-text {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 12px;
        }
        .mandatory-section {
            border-left: 4px solid #EF4444;
            padding-left: 15px;
            margin-bottom: 20px;
            background-color: #FEF2F2;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .recommended-section {
            border-left: 4px solid #F59E0B;
            padding-left: 15px;
            margin-bottom: 20px;
            background-color: #FFFBEB;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .component-section {
            border-left: 4px solid #3B82F6;
            padding-left: 15px;
            margin-bottom: 20px;
            background-color: #EFF6FF;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .list-item {
            margin-bottom: 8px;
            font-size: 16px;
        }
        </style>
        """, unsafe_allow_html=True)
        
        st.markdown('<div class="risk-assessment-header">Risk Assessment Results</div>', unsafe_allow_html=True)
        if st.session_state.similar_requirements:
            with st.expander("Similar Past Assessments Found"):
                for sim_req in st.session_state.similar_requirements:
                    meta = sim_req.get('metadata', {})
                    st.markdown(f"**ID:** `{meta.get('id')}` (Similarity: {1-sim_req.get('distance', 1):.2f})")
                    st.markdown(f"**Risk:** {meta.get('risk', 'N/A')}")
                    st.text_area(f"Requirement (similar):", value=meta.get('requirement_text', 'N/A'), height=70, disabled=True, key=f"sim_req_text_disp_{meta.get('id')}")
                    st.markdown("---")

        res = st.session_state.assessment_result
        st.markdown(f'<div class="risk-level">Risk Level: {res.get("risk", "N/A")}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="content-text"><strong>Reasoning:</strong> {res.get("reasoning", "N/A")}</div>', unsafe_allow_html=True)
        
        # Display mandatory testing requirements
        if 'mandatory_testing' in res:
            st.markdown('<div class="section-header">🔴 Mandatory NFT Requirements</div>', unsafe_allow_html=True)
            mandatory_testing = res.get('mandatory_testing', {})
            
            if isinstance(mandatory_testing, dict):
                for test_type, details in mandatory_testing.items():
                    st.markdown(f'<div class="subsection-header">{test_type}</div>', unsafe_allow_html=True)
                    
                    # Create a container div for consistent styling
                    st.markdown('<div class="mandatory-section">', unsafe_allow_html=True)
                    
                    if isinstance(details, dict):
                        for key, value in details.items():
                            # Format key for display
                            display_key = key.replace('_', ' ').replace('technical rationale', 'Testing Rationale').title()
                            
                            # Convert list values to string
                            if isinstance(value, list):
                                # Remove brackets and format list items
                                formatted_value = ", ".join([str(item).strip("'[]") for item in value])
                            else:
                                formatted_value = value
                            
                            st.markdown(f'<div class="content-text"><strong>{display_key}:</strong> {formatted_value}</div>', unsafe_allow_html=True)
                    else:
                        st.markdown(f'<div class="content-text">{details}</div>', unsafe_allow_html=True)
                    
                    # Close container div
                    st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="content-text">{mandatory_testing}</div>', unsafe_allow_html=True)
        
        # Display recommended testing strategy
        if 'recommended_testing' in res:
            st.markdown('<div class="section-header">🟡 Recommended NFT Strategy</div>', unsafe_allow_html=True)
            recommended_testing = res.get('recommended_testing', {})
            
            if isinstance(recommended_testing, dict):
                for test_type, components in recommended_testing.items():
                    st.markdown(f'<div class="subsection-header">{test_type}</div>', unsafe_allow_html=True)
                    
                    # Create a container div for consistent styling
                    st.markdown('<div class="recommended-section">', unsafe_allow_html=True)
                    
                    if isinstance(components, dict):  # Structured components
                        for component, details in components.items():
                            # Format component name for display
                            display_component = component.replace('_', ' ').title()
                            
                            # Handle lists inside details
                            if isinstance(details, list):
                                # Remove brackets and format list items
                                formatted_details = ", ".join([str(item).strip("'[]") for item in details])
                                st.markdown(f'<div class="content-text"><strong>{display_component}:</strong> {formatted_details}</div>', unsafe_allow_html=True)
                            else:
                                st.markdown(f'<div class="content-text"><strong>{display_component}:</strong> {details}</div>', unsafe_allow_html=True)
                    else:  # Fallback for string value
                        st.markdown(f'<div class="content-text">{components}</div>', unsafe_allow_html=True)
                    
                    # Close container div
                    st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="content-text">{recommended_testing}</div>', unsafe_allow_html=True)
        elif 'recommendations' in res:  # Backward compatibility
            st.markdown('<div class="section-header">🟡 Recommended Testing</div>', unsafe_allow_html=True)
            st.markdown(f'<div class="content-text">{res.get("recommendations", "N/A")}</div>', unsafe_allow_html=True)
        
        # Display component analysis with technical focus
        if 'component_analysis' in res:
            st.markdown('<div class="section-header">🔧 Component-Specific NFT Analysis</div>', unsafe_allow_html=True)
            component_analysis = res.get('component_analysis', {})
            
            if isinstance(component_analysis, dict):
                for component, analysis in component_analysis.items():
                    st.markdown(f'<div class="subsection-header">{component}</div>', unsafe_allow_html=True)
                    
                    # Create a container div for consistent styling
                    st.markdown('<div class="component-section">', unsafe_allow_html=True)
                    
                    if isinstance(analysis, dict):
                        # Technical focus areas
                        for key, value in analysis.items():
                            # Format key for display
                            display_key = key.replace('_', ' ').title()
                            
                            if isinstance(value, list):
                                # Create a formatted list without brackets
                                st.markdown(f'<div class="content-text"><strong>{display_key}:</strong></div>', unsafe_allow_html=True)
                                for item in value:
                                    formatted_item = str(item).strip("'[]")
                                    st.markdown(f'<div class="list-item">• {formatted_item}</div>', unsafe_allow_html=True)
                            else:
                                st.markdown(f'<div class="content-text"><strong>{display_key}:</strong> {value}</div>', unsafe_allow_html=True)
                    else:
                        st.markdown(f'<div class="content-text">{analysis}</div>', unsafe_allow_html=True)
                    
                    # Close container div
                    st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="content-text">{component_analysis}</div>', unsafe_allow_html=True)
        
        # Display impact of not performing NFT section
        if 'nft_impact' in res:
            st.markdown('<div class="section-header">⚠️ Impact of Not Performing NFT</div>', unsafe_allow_html=True)
            nft_impact = res.get('nft_impact', {})
            
            if isinstance(nft_impact, dict):
                # Create impact categories in a structured format
                impact_categories = ['technical_impact', 'business_impact', 'financial_impact', 'customer_impact']
                category_titles = {
                    'technical_impact': 'Technical Impact',
                    'business_impact': 'Business Impact',
                    'financial_impact': 'Financial Impact',
                    'customer_impact': 'Customer Impact'
                }
                
                for impact_cat in impact_categories:
                    if impact_cat in nft_impact:
                        # Get the display title for this category
                        display_title = category_titles.get(impact_cat, impact_cat.replace('_', ' ').title())
                        st.markdown(f'<div class="subsection-header">{display_title}</div>', unsafe_allow_html=True)
                        
                        # Create a container div with distinctive styling for impacts
                        st.markdown('<div class="mandatory-section">', unsafe_allow_html=True)
                        
                        impact_details = nft_impact.get(impact_cat, {})
                        if isinstance(impact_details, dict):
                            # Display structured impact details
                            for key, value in impact_details.items():
                                # Format key for display
                                display_key = key.replace('_', ' ').title()
                                
                                # Format value based on type
                                if isinstance(value, list):
                                    st.markdown(f'<div class="content-text"><strong>{display_key}:</strong></div>', unsafe_allow_html=True)
                                    for item in value:
                                        formatted_item = str(item).strip("'[]")
                                        st.markdown(f'<div class="list-item">• {formatted_item}</div>', unsafe_allow_html=True)
                                else:
                                    st.markdown(f'<div class="content-text"><strong>{display_key}:</strong> {value}</div>', unsafe_allow_html=True)
                        elif isinstance(impact_details, list):
                            # Display list of impact points
                            for item in impact_details:
                                st.markdown(f'<div class="list-item">• {item}</div>', unsafe_allow_html=True)
                        else:
                            # Display as simple text if not structured
                            st.markdown(f'<div class="content-text">{impact_details}</div>', unsafe_allow_html=True)
                        
                        # Close container div
                        st.markdown('</div>', unsafe_allow_html=True)
            else:
                # Fallback for string format
                st.markdown(f'<div class="content-text">{nft_impact}</div>', unsafe_allow_html=True)
        
        st.markdown("---")
        st.subheader("Architect Review")
        
        # Add feedback collection for learning
        with st.expander("🧠 Assessment Feedback (for AI Learning)", expanded=False):
            st.info("Help improve the AI's accuracy by providing feedback on this assessment:")
            
            col1_feedback, col2_feedback = st.columns(2)
            with col1_feedback:
                actual_outcome = st.selectbox(
                    "What was the actual risk level?",
                    ["Select...", "High", "Medium", "Low"],
                    key="actual_outcome_feedback"
                )
            with col2_feedback:
                feedback_comments = st.text_area(
                    "Additional Comments (optional):",
                    height=100,
                    key="feedback_comments",
                    placeholder="Any insights about why the AI assessment was accurate/inaccurate..."
                )
        
        review_comment = st.text_area("Review Comments:", key="review_comment_tab1")
        
        col1_approve, col2_reject = st.columns(2)
        if col1_approve.button("Mark as Approved", key="approve_btn_tab1", use_container_width=True):
            if st.session_state.assessment_id:
                with st.spinner("Updating..."):
                    current_api_key = st.session_state.api_key_input_global
                    success = chroma_logic.update_assessment_status(chroma_logic.get_or_create_collection(current_api_key), st.session_state.assessment_id, "Approved", review_comment)
                    if success: 
                        st.success("Marked as Approved!")
                        st.session_state.assessment_result['status'] = "Approved"
                        st.session_state.assessment_result['comments'] = review_comment
                        
                        # Record feedback for learning if provided
                        if st.session_state.get("actual_outcome_feedback") != "Select...":
                            try:
                                project_type = st.session_state.current_context.get('project_type', '')
                                ai_prediction = st.session_state.assessment_result.get('risk', '')
                                actual_outcome = st.session_state.actual_outcome_feedback
                                user_comments = st.session_state.get('feedback_comments', '')
                                
                                feedback_recorded = historical_learning.record_assessment_feedback(
                                    assessment_id=st.session_state.assessment_id,
                                    requirement_text=st.session_state.current_requirement_text,
                                    ai_prediction=ai_prediction,
                                    actual_outcome=actual_outcome,
                                    user_comments=user_comments,
                                    project_type=project_type,
                                    requirement_category="NFT"
                                )
                                
                                if feedback_recorded:
                                    st.success("✅ Feedback recorded for AI learning!")
                                else:
                                    st.warning("⚠️ Could not record feedback for learning")
                            except Exception as e:
                                st.warning(f"⚠️ Feedback recording failed: {str(e)}")
                    else: 
                        st.error("Failed to update status.")
            else: 
                st.warning("No assessment ID. Run analysis first.")

        if col2_reject.button("Mark as Rejected", key="reject_btn_tab1", use_container_width=True):
            if st.session_state.assessment_id:
                with st.spinner("Updating..."):
                    current_api_key = st.session_state.api_key_input_global
                    success = chroma_logic.update_assessment_status(chroma_logic.get_or_create_collection(current_api_key), st.session_state.assessment_id, "Rejected", review_comment)
                    if success: 
                        st.success("Marked as Rejected!")
                        st.session_state.assessment_result['status'] = "Rejected"
                        st.session_state.assessment_result['comments'] = review_comment
                        
                        # Record feedback for learning if provided
                        if st.session_state.get("actual_outcome_feedback") != "Select...":
                            try:
                                project_type = st.session_state.current_context.get('project_type', '')
                                ai_prediction = st.session_state.assessment_result.get('risk', '')
                                actual_outcome = st.session_state.actual_outcome_feedback

                                user_comments = st.session_state.get('feedback_comments', '')
                                
                                feedback_recorded = historical_learning.record_assessment_feedback(
                                    assessment_id=st.session_state.assessment_id,
                                    requirement_text=st.session_state.current_requirement_text,
                                    ai_prediction=ai_prediction,
                                    actual_outcome=actual_outcome,
                                    user_comments=user_comments,
                                    project_type=project_type,
                                    requirement_category="NFT"
                                )
                                
                                if feedback_recorded:
                                    st.success("✅ Feedback recorded for AI learning!")
                                else:
                                    st.warning("⚠️ Could not record feedback for learning")
                            except Exception as e:
                                st.warning(f"⚠️ Feedback recording failed: {str(e)}")
                    else: 
                        st.error("Failed to update status.")
            else: 
                st.warning("No assessment ID. Run analysis first.")

        st.markdown("---")
        pdf_report_data = {
            'requirement_text': st.session_state.current_requirement_text,
            'context': st.session_state.current_context, 
            **res,
            'status': st.session_state.assessment_result.get('status', 'Pending'),
            'comments': st.session_state.assessment_result.get('comments', ''),
            'timestamp': int(time.time()), 
            'id': st.session_state.assessment_id or "N/A",
            'project_name': st.session_state.current_context.get('project_name', 'N/A')
        }
        if 'approved' in pdf_report_data: 
            del pdf_report_data['approved']
        pdf_data = pdf_generator.generate_pdf_report(pdf_report_data)
        st.download_button("Download Report as PDF", pdf_data, f"assessment_{st.session_state.assessment_id or 'report'}.pdf", "application/pdf", key="download_pdf_tab1")

with tab2:
    st.header("Past Assessments")
    current_api_key_for_tab2 = st.session_state.get("api_key_input_global") # Consistent usage
    if not current_api_key_for_tab2:
        st.info("Please enter OpenAI API Key in the sidebar to view past assessments.")
    else:
        try:
            collection = chroma_logic.get_or_create_collection(current_api_key_for_tab2)
            # Make sure to get all assessments correctly
            all_assessments = chroma_logic.get_all_assessments(collection)
            
            # Debug statement to check if assessments are being retrieved
            st.write(f"Found {len(all_assessments)} past assessment(s) in the database.")

            # --- Ensure all assessments have 'project_name' ---
            for a in all_assessments:
                if 'project_name' not in a or not a['project_name']:
                    a['project_name'] = 'N/A'

            # --- Filtering & Sorting controls moved into Tab 2 main area ---
            st.markdown("#### Filter & Sort Past Assessments")
            filter_cols = st.columns(3)
            with filter_cols[0]:
                filter_project_name_tab2 = st.text_input("Filter by Project Name:", key="filter_project_name_main_tab2")
            with filter_cols[1]:
                filter_risk_level_tab2 = st.multiselect("Filter by Risk Level:", options=["High", "Medium", "Low"], key="filter_risk_level_main_tab2")
            with filter_cols[2]:
                filter_approval_status_tab2 = st.selectbox("Filter by Status:", options=["All", "Pending", "Approved", "Rejected"], index=0, key="filter_approval_status_main_tab2")

            sort_cols = st.columns(2)
            with sort_cols[0]:
                sort_column_tab2 = st.selectbox("Sort by:", options=["Timestamp", "Project Name", "Risk Level", "Approval Status"], key="sort_column_main_tab2")
            with sort_cols[1]:
                sort_ascending_tab2 = st.radio("Sort Order:", options=["Ascending", "Descending"], key="sort_order_main_tab2", horizontal=True) == "Ascending"
            st.markdown("---")

            # --- Debug: Show count of loaded assessments ---
            st.caption(f"Total assessments in database: {len(all_assessments)}")

            if not all_assessments:
                st.info("No past assessments found. Complete an analysis in the 'New Assessment' tab to see results here.")
            else:
                # Create a dictionary of assessments by ID for quick lookup
                assessment_dict = {assessment.get('id'): assessment for assessment in all_assessments if assessment.get('id')}
                
                filtered_assessments = all_assessments.copy()  # Make a copy before filtering
                
                # --- Defensive filtering logic: always use .get() and lower() safely ---
                if filter_project_name_tab2:
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if filter_project_name_tab2.lower() in str(a.get('project_name', '')).lower()
                    ]
                
                if filter_risk_level_tab2:
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if a.get('risk') in filter_risk_level_tab2
                    ]
                
                if filter_approval_status_tab2 != "All":
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if a.get('status') == filter_approval_status_tab2
                    ]
                
                # Debug message for filtered results
                st.caption(f"Filtered to {len(filtered_assessments)} assessment(s) based on current filters")
                
                if filtered_assessments:
                    # Improved sorting function with proper error handling
                    def get_sort_key_tab2(assessment):
                        if sort_column_tab2 == "Timestamp":
                            return assessment.get('timestamp', 0) 
                        elif sort_column_tab2 == "Project Name":
                            return str(assessment.get('project_name', '')).lower()
                        elif sort_column_tab2 == "Risk Level":
                            risk_level = assessment.get('risk', '')
                            # Map risk levels to numeric values for sorting
                            risk_values = {"Low": 0, "Medium": 1, "High": 2}
                            return risk_values.get(risk_level, -1)
                        elif sort_column_tab2 == "Approval Status":
                            return str(assessment.get('status', '')).lower()
                        return 0  # Default fallback
                    
                    # Apply sorting
                    filtered_assessments.sort(key=get_sort_key_tab2, reverse=not sort_ascending_tab2)

                    st.write(f"Displaying {len(filtered_assessments)} assessment(s):")
                    cols_names_tab2 = ["Project Name", "Risk Level", "Status", "Timestamp", "Details"]
                    header_cols_tab2 = st.columns(len(cols_names_tab2))
                    for col, name in zip(header_cols_tab2, cols_names_tab2): 
                        col.markdown(f"**{name}**")
                    st.markdown("---")

                    for assess_data in filtered_assessments:
                        row_cols_tab2 = st.columns(len(cols_names_tab2))
                        row_cols_tab2[0].write(assess_data.get('project_name', 'N/A'))
                        row_cols_tab2[1].write(assess_data.get('risk', 'N/A'))
                        row_cols_tab2[2].write(assess_data.get('status', 'N/A'))
                        # Handle timestamp safely
                        timestamp = assess_data.get('timestamp', 0)
                        if timestamp:
                            row_cols_tab2[3].write(time.strftime('%Y-%m-%d %H:%M', time.localtime(timestamp)))
                        else:
                            row_cols_tab2[3].write("Unknown")
                        
                        with row_cols_tab2[4]:
                            details_popover = st.popover("View", use_container_width=True) 
                        
                        with details_popover:
                            assess_id = assess_data.get('id')
                            full_details = assessment_dict.get(assess_id) if assess_id else None
                            
                            if full_details:
                                st.markdown(f"#### Details for ID: {full_details.get('id')}")
                                st.markdown(f"**Project:** {full_details.get('project_name', 'N/A')}")
                                
                                detail_timestamp = full_details.get('timestamp', 0)
                                if detail_timestamp:
                                    st.markdown(f"**Timestamp:** {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(detail_timestamp))}")
                                else:
                                    st.markdown("**Timestamp:** N/A")
                                
                                st.markdown(f"**Risk:** {full_details.get('risk', 'N/A')}")
                                st.markdown(f"**Status:** {full_details.get('status', 'N/A')}")
                                st.markdown(f"**Comments:** {full_details.get('comments', 'None')}")
                                st.markdown(f"**Requirement:**")
                                st.text_area("req_text_popup_disp", value=full_details.get('requirement_text','N/A'), 
                                            height=100, disabled=True, key=f"popup_req_disp_{assess_id}")
                                
                                # Display reasoning
                                st.markdown(f"**Reasoning:** {full_details.get('reasoning', 'N/A')}")
                                
                                # Display mandatory testing with new structured format
                                if 'mandatory_testing' in full_details:
                                    st.markdown("#### Mandatory Testing (Centrica Services)")
                                    mandatory_testing = full_details.get('mandatory_testing', {})
                                    
                                    if isinstance(mandatory_testing, dict):  # New structured format
                                        for test_type, components in mandatory_testing.items():
                                            st.markdown(f"**{test_type}**")
                                            if isinstance(components, dict):  # Structured components
                                                for component, details in components.items():
                                                    st.markdown(f"- *{component}:* {details}")
                                            else:  # Fallback for string value
                                                st.markdown(f"- {components}")
                                    else:  # Fallback for string format
                                        st.markdown(mandatory_testing)
                                
                                # Display recommended testing with new structured format
                                if 'recommended_testing' in full_details:
                                    st.markdown("#### Recommended Testing")
                                    recommended_testing = full_details.get('recommended_testing', {})
                                    
                                    if isinstance(recommended_testing, dict):  # New structured format
                                        for test_type, components in recommended_testing.items():
                                            st.markdown(f"**{test_type}**")
                                            if isinstance(components, dict):  # Structured components
                                                for component, details in components.items():
                                                    st.markdown(f"- *{component}:* {details}")
                                            else:  # Fallback for string value
                                                st.markdown(f"- {components}")
                                    else:  # Fallback for string format
                                        st.markdown(recommended_testing)
                                elif 'recommendations' in full_details:  # Backward compatibility
                                    st.markdown(f"**Recommended Testing:** {full_details.get('recommendations', 'N/A')}")
                                
                                # Display component analysis with new structured format
                                if 'component_analysis' in full_details:
                                    st.markdown("#### Component Analysis")
                                    component_analysis = full_details.get('component_analysis', {})
                                    
                                    if isinstance(component_analysis, dict):  # New structured format
                                        for component, tests in component_analysis.items():
                                            st.markdown(f"**{component}**")
                                            if isinstance(tests, dict):  # Structured tests
                                                for test_type, details in tests.items():
                                                    st.markdown(f"- *{test_type}:* {details}")
                                            else:  # Fallback for string value
                                                st.markdown(f"- {tests}")
                                    else:  # Fallback for string format
                                        st.markdown(component_analysis)
                                
                                # Impact analysis has been removed as per user request
                                
                                try:
                                    # Create PDF payload with necessary data
                                    pdf_payload = {
                                        **full_details, 
                                        'context': {'project_name': full_details.get('project_name', 'N/A')}
                                    }
                                    pdf_bytes = pdf_generator.generate_pdf_report(pdf_payload)
                                    st.download_button(
                                        "Download Report", 
                                        pdf_bytes, 
                                        f"assessment_{assess_id}.pdf", 
                                        "application/pdf", 
                                        key=f"dl_popup_btn_{assess_id}"
                                    )
                                except Exception as e_pdf: 
                                    st.error(f"PDF Error: {e_pdf}")
                            else: 
                                st.error("Details not found for this assessment.")
                        st.markdown("---")
                else:
                    st.info("No assessments match your current filter criteria. Try adjusting your filters.")
        except Exception as e:
            st.error(f"Error loading past assessments: {str(e)}")
            # Log detailed error for debugging
            st.error(f"Error details: {type(e).__name__}")
            import traceback
            st.code(traceback.format_exc())

with tab3:
    st.header("Risk Visualization Dashboard")
    current_api_key_for_tab3 = st.session_state.get("api_key_input_global")
    if not current_api_key_for_tab3:
        st.info("Please enter OpenAI API Key in the sidebar to view risk visualizations.")
    else:
        try:
            collection = chroma_logic.get_or_create_collection(current_api_key_for_tab3)
            # Get all assessments for visualization
           
            all_assessments = chroma_logic.get_all_assessments(collection)
            
            if not all_assessments:
                st.info("No assessment data available for visualization. Complete some assessments to see risk analytics.")
            else:
                # Display risk visualization dashboard
                risk_visualization.display_risk_dashboard(all_assessments)
        
        except Exception as e:
            st.error(f"Error loading risk dashboard: {str(e)}")

with tab4:
    st.header("🧠 Learning Analytics Dashboard")
    
    current_api_key_for_tab4 = st.session_state.get("api_key_input_global")
    if not current_api_key_for_tab4:
        st.info("Please enter OpenAI API Key in the sidebar to view learning analytics.")
    else:
        try:
            # Get learning dashboard data
            dashboard_data = historical_learning.get_learning_dashboard_data()
            
            if 'error' in dashboard_data:
                st.error(f"Error loading learning data: {dashboard_data['error']}")
            else:
                # Display overall metrics
                st.subheader("📈 Overall Learning Metrics")
                metrics = dashboard_data.get('overall_metrics', {})
                
                if metrics.get('total_assessments', 0) == 0:
                    st.info("🎯 No feedback data available yet. Provide feedback on assessments in the 'New Assessment' tab to see learning analytics here.")
                    st.markdown("""
                    **How to contribute to AI learning:**
                    1. Complete an assessment in the 'New Assessment' tab
                    2. When marking it as Approved/Rejected, expand the 'Assessment Feedback' section
                    3. Select the actual risk level and add comments
                    4. The AI will learn from your feedback to improve future assessments
                    """)
                else:
                    # Create metrics columns
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("Total Assessments", metrics.get('total_assessments', 0))
                    with col2:
                        st.metric("Correct Predictions", metrics.get('correct_predictions', 0))
                    with col3:
                        accuracy = metrics.get('accuracy_rate', 0)
                        st.metric("Accuracy Rate", f"{accuracy:.2%}")
                    with col4:
                        improvement = metrics.get('improvement_rate', 0)
                        delta = f"+{improvement:.2%}" if improvement > 0 else f"{improvement:.2%}"
                        st.metric("Improvement Rate", delta, delta=delta)
                    
                    # Display confidence scores
                    st.subheader("🎯 Confidence Scores by Category")
                    confidence_scores = metrics.get('confidence_scores', {})
                    if confidence_scores:
                        confidence_cols = st.columns(min(len(confidence_scores), 4))
                        for i, (category, score) in enumerate(confidence_scores.items()):
                            with confidence_cols[i % 4]:
                                st.metric(category.replace('_', ' ').title(), f"{score:.2%}")
                    else:
                        st.info("Not enough data for confidence scores yet.")
                    
                    # Display daily trends
                    st.subheader("📊 Daily Accuracy Trends")
                    daily_trends = dashboard_data.get('daily_trends', [])
                    if daily_trends:
                        import plotly.express as px
                        import pandas as pd
                        
                        df_trends = pd.DataFrame(daily_trends)
                        if not df_trends.empty:
                            fig = px.line(df_trends, x='date', y='accuracy', 
                                        title='Assessment Accuracy Over Time',
                                        labels={'accuracy': 'Accuracy Rate', 'date': 'Date'})
                            fig.update_yaxes(tickformat='.0%')
                            st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("Not enough daily data for trends yet.")
                    
                    # Display error patterns
                    st.subheader("🔍 Common Error Patterns")
                    error_patterns = metrics.get('common_error_patterns', [])
                    if error_patterns:
                        for i, pattern in enumerate(error_patterns[:5]):  # Show top 5
                            with st.expander(f"Pattern {i+1}: {pattern.get('pattern', 'Unknown')}"):
                                st.write(f"**Frequency:** {pattern.get('frequency', 0):.1%}")
                                st.write(f"**Occurrences:** {pattern.get('count', 0)}")
                                st.write(f"**Average Accuracy:** {pattern.get('average_accuracy', 0):.2%}")
                                if pattern.get('affected_categories'):
                                    st.write(f"**Affected Categories:** {', '.join(pattern['affected_categories'])}")
                    else:
                        st.info("No significant error patterns detected yet.")
                    
                    # Display optimization suggestions
                    st.subheader("💡 AI Improvement Suggestions")
                    suggestions = metrics.get('optimization_suggestions', [])
                    if suggestions:
                        for suggestion in suggestions:
                            st.warning(f"💡 {suggestion}")
                    else:
                        st.success("🎉 No immediate improvements needed - AI is performing well!")
                    
                    # Display optimization recommendations
                    st.subheader("🛠️ Optimization Recommendations")
                    recommendations = dashboard_data.get('recommendations', {})
                    if recommendations.get('needs_optimization'):
                        st.error(f"⚠️ Accuracy below threshold: {recommendations.get('current_accuracy', 0):.2%}")
                        st.info(f"🎯 Target accuracy: {recommendations.get('target_accuracy', 0.75):.2%}")
                        
                        priority_areas = recommendations.get('priority_areas', [])
                        if priority_areas:
                            st.write("**Priority Areas for Improvement:**")
                            for area in priority_areas:
                                impact_color = "🔴" if area['impact'] == 'high' else "🟡"
                                st.write(f"{impact_color} {area['area']} (frequency: {area['frequency']:.1%})")
                    else:
                        st.success("✅ AI accuracy is within acceptable range!")
                        minor_improvements = recommendations.get('minor_improvements', [])
                        if minor_improvements:
                            st.info("**Minor improvements you could consider:**")
                            for improvement in minor_improvements:
                                st.write(f"• {improvement}")
                    
                    # Export functionality
                    st.subheader("📤 Export Learning Data")
                    col1_export, col2_export = st.columns(2)
                    
                    with col1_export:
                        if st.button("📊 Export Learning Metrics", use_container_width=True):
                            try:
                                metrics_json = json.dumps(dashboard_data, indent=2, default=str)
                                st.download_button(
                                    label="Download Metrics JSON",
                                    data=metrics_json,
                                    file_name=f"learning_metrics_{int(time.time())}.json",
                                    mime="application/json"
                                )
                            except Exception as e:
                                st.error(f"Export failed: {str(e)}")
                    
                    with col2_export:
                        if st.button("💾 Export Full Learning Database", use_container_width=True):
                            try:
                                export_success = historical_learning.learning_system.export_learning_data(
                                    f"learning_export_{int(time.time())}.json"
                                )
                                if export_success:
                                    st.success("✅ Learning data exported successfully!")
                                else:
                                    st.error("❌ Export failed")
                            except Exception as e:
                                st.error(f"Export failed: {str(e)}")
                    
                    # Quick insights
                    st.subheader("🧠 Quick Insights")
                    if accuracy >= 0.9:
                        st.success("🎯 Excellent! AI accuracy is above 90%")
                    elif accuracy >= 0.75:
                        st.info("👍 Good performance - AI accuracy is above 75%")
                    elif accuracy >= 0.60:
                        st.warning("⚠️ Moderate performance - consider reviewing assessment criteria")
                    else:
                        st.error("🔴 Low accuracy - immediate attention needed")
                    
                    total = metrics.get('total_assessments', 0)
                    if total < 10:
                        st.info(f"💡 Tip: Collect more feedback ({total}/10+ recommended) for better learning insights")
                    elif total >= 50:
                        st.success(f"🎉 Great! You have {total} feedback entries - excellent learning dataset!")
        
        except Exception as e:
            st.error(f"Error loading learning analytics: {str(e)}")
            import traceback
            st.code(traceback.format_exc())
