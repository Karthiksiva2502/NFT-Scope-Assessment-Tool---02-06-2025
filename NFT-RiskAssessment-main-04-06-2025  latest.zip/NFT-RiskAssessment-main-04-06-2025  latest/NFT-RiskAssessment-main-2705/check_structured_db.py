import sqlite3

def check_structured_format():
    """Check database for structured format interactions."""
    try:
        conn = sqlite3.connect('ai_interactions.db')
        cursor = conn.cursor()
        
        # Count structured interactions
        cursor.execute("SELECT COUNT(*) FROM ai_interactions WHERE prompt LIKE '%Application Overview:%'")
        structured_count = cursor.fetchone()[0]
        
        # Get latest structured interaction
        cursor.execute("""
            SELECT prompt, timestamp 
            FROM ai_interactions 
            WHERE prompt LIKE '%Application Overview:%'
            ORDER BY timestamp DESC 
            LIMIT 1
        """)
        
        latest = cursor.fetchone()
        
        print(f"Structured format interactions: {structured_count}")
        
        if latest:
            print(f"Latest structured interaction timestamp: {latest[1]}")
            print("Prompt preview:")
            print(latest[0][:500] + "..." if len(latest[0]) > 500 else latest[0])
        
        conn.close()
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    check_structured_format()
