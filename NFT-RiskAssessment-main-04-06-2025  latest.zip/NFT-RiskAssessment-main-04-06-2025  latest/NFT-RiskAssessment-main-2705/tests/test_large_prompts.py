#!/usr/bin/env python3
"""
Edge case testing for very long prompts and responses to verify no truncation occurs.
"""

import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_large_prompt_handling():
    """Test handling of very large prompts."""
    print("="*60)
    print("LARGE PROMPT HANDLING TEST")
    print("="*60)
    
    try:
        from core.intelligent_assessment_logic import IntelligentAssessmentDecision
        
        # Create a very large requirement text (simulate real-world complex requirements)
        large_requirement = """
        COMPLEX SYSTEM REQUIREMENT:
        
        The enterprise-grade financial trading platform must support real-time processing of 
        100,000+ concurrent trading transactions with sub-millisecond latency requirements.
        
        DETAILED SPECIFICATIONS:
        
        1. PERFORMANCE REQUIREMENTS:
        - Handle 100,000 concurrent users during market open
        - Process 1,000,000 transactions per second at peak
        - Maintain sub-100ms response times for order execution
        - Support real-time market data feeds from 50+ exchanges
        - Handle high-frequency trading algorithms with microsecond precision
        
        2. SECURITY REQUIREMENTS:
        - End-to-end encryption for all financial data
        - Multi-factor authentication for all user access
        - Compliance with SOX, GDPR, MiFID II regulations
        - Real-time fraud detection and prevention
        - Secure API endpoints with rate limiting and throttling
        
        3. RELIABILITY REQUIREMENTS:
        - 99.999% uptime (5 minutes downtime per year maximum)
        - Zero data loss during system failures
        - Automated failover within 30 seconds
        - Disaster recovery with RPO < 1 minute, RTO < 5 minutes
        - Load balancing across multiple data centers globally
        
        4. SCALABILITY REQUIREMENTS:
        - Auto-scaling based on trading volume
        - Support for horizontal scaling during market volatility
        - Database sharding for transaction history storage
        - CDN distribution for market data globally
        - Microservices architecture for independent scaling
        
        5. INTEGRATION REQUIREMENTS:
        - Integration with 50+ stock exchanges worldwide
        - Real-time data feeds from Bloomberg, Reuters, and other providers
        - Connection to clearing houses and settlement systems
        - Integration with regulatory reporting systems
        - API connectivity for third-party trading applications
        
        6. DATA MANAGEMENT:
        - Store 10+ years of historical trading data
        - Real-time analytics on trading patterns
        - Compliance audit trails for all transactions
        - Data archiving and retention policies
        - Backup and recovery procedures for critical data
        
        7. MONITORING AND ALERTING:
        - Real-time system health monitoring
        - Trading volume and performance metrics
        - Security incident detection and response
        - Regulatory compliance monitoring
        - Custom alerting for business-critical events
        
        BUSINESS CONTEXT:
        This system processes $50+ billion in daily trading volume and serves institutional 
        clients including major banks, hedge funds, and investment firms. Any system downtime 
        results in significant financial losses and regulatory penalties.
        """ * 3  # Multiply by 3 to make it very large
        
        # Create extensive context
        large_context = {
            'project_name': 'Enterprise Financial Trading Platform',
            'change_type': 'Complete System Overhaul',
            'component_name': 'Core Trading Engine',
            'ui_response_time': '< 100ms',
            'backend_volume': '100,000 concurrent users',
            'backend_response_time': '< 50ms',
            'batch_volume': '1,000,000 transactions/second',
            'business_disruption': 'Critical - $1M+ loss per minute of downtime',
            'security_requirements': 'SOX, GDPR, MiFID II compliance, end-to-end encryption',
            'integration_points': '50+ stock exchanges, Bloomberg, Reuters, clearing houses',
            'growth_rate': '50% YoY trading volume growth',
            'infrastructure_changes': 'Multi-region cloud deployment with edge computing',
            'third_party_involvement': 'Multiple financial data providers and exchanges',
            'contingency_plans': 'Hot standby systems, automated failover, disaster recovery',
            'performance_issues': 'Latency spikes during high volatility periods',
            'compliance_needs': 'Real-time regulatory reporting, audit trails',
            'customization_level': 'Highly customized for institutional trading requirements'
        }
        
        # Create very large application overview
        large_app_overview = """
        ENTERPRISE FINANCIAL TRADING PLATFORM OVERVIEW:
        
        This is a mission-critical financial trading platform serving the world's largest 
        institutional investors, including:
        
        - 500+ major investment banks and financial institutions
        - 1,000+ hedge funds and asset management companies  
        - 200+ proprietary trading firms
        - 50+ central banks and sovereign wealth funds
        
        PLATFORM STATISTICS:
        - $50+ billion in daily trading volume
        - 10+ million trades executed daily
        - 99.999% historical uptime over 10 years
        - Sub-millisecond average execution latency
        - Global presence across 25 countries
        
        REGULATORY ENVIRONMENT:
        The platform operates under strict financial regulations including:
        - Sarbanes-Oxley Act (SOX) compliance
        - General Data Protection Regulation (GDPR)
        - Markets in Financial Instruments Directive II (MiFID II)
        - Dodd-Frank Wall Street Reform Act
        - Basel III banking regulations
        
        TECHNOLOGY INFRASTRUCTURE:
        - Distributed across 12 data centers globally
        - Real-time replication and synchronization
        - Advanced security with multiple layers of protection
        - Custom hardware for ultra-low latency trading
        - Machine learning for fraud detection and risk management
        
        BUSINESS IMPACT:
        Any system disruption has immediate and severe consequences:
        - Financial losses exceeding $1 million per minute
        - Regulatory penalties and compliance violations  
        - Reputational damage affecting client relationships
        - Market disruption affecting global trading activities
        - Legal liability for client losses during outages
        """ * 2  # Multiply to make it larger
        
        # Create large AI gathered information
        large_ai_info = """
        DETAILED ANALYSIS FROM AI ASSISTANT INVESTIGATION:
        
        Through comprehensive analysis, the following critical insights have been gathered:
        
        PERFORMANCE BOTTLENECKS IDENTIFIED:
        1. Database Performance: Current system shows 200ms+ query times above 80,000 concurrent users
        2. Network Latency: Cross-region synchronization adds 50-100ms during high-volume periods
        3. Memory Management: JVM garbage collection pauses cause 500ms+ delays during peak trading
        4. Cache Invalidation: Redis cluster performance degrades with 1M+ operations per second
        
        SECURITY VULNERABILITIES DISCOVERED:
        1. API Rate Limiting: Current implementation insufficient for DDoS protection
        2. Encryption Overhead: SSL/TLS handshakes add 10-20ms latency per connection
        3. Authentication Bottlenecks: OAuth token validation becomes slow under high load
        4. Audit Trail Performance: Compliance logging impacts real-time performance
        
        SCALABILITY LIMITATIONS:
        1. Database Sharding: Current approach shows degradation above 500,000 TPS
        2. Microservices Communication: Service mesh latency increases with scale
        3. Load Balancer Limits: Current infrastructure maxes out at 75,000 concurrent connections
        4. Message Queue Throughput: Kafka clusters show lag during extreme volume spikes
        
        INTEGRATION CHALLENGES:
        1. Exchange Connectivity: Some exchanges have rate limits that conflict with volume requirements
        2. Data Feed Processing: Market data processing creates CPU bottlenecks during volatility
        3. Settlement System Delays: Clearing house connections add 2-5 second delays
        4. Regulatory Reporting: Real-time compliance reporting impacts system performance
        
        RECOMMENDED MITIGATION STRATEGIES:
        1. Implement advanced caching strategies with sub-millisecond Redis clusters
        2. Upgrade to dedicated hardware with FPGA acceleration for ultra-low latency
        3. Deploy edge computing nodes closer to major exchanges for reduced network latency
        4. Implement intelligent load balancing with predictive scaling based on market conditions
        5. Optimize database queries with advanced indexing and query optimization
        6. Implement circuit breakers and bulkhead patterns for system resilience
        """ * 2  # Multiply to make it larger
        
        print(f"Creating comprehensive prompt with:")
        print(f"- Requirement text: {len(large_requirement):,} characters")
        print(f"- Context entries: {len(large_context)} items")
        print(f"- Application overview: {len(large_app_overview):,} characters")
        print(f"- AI gathered info: {len(large_ai_info):,} characters")
        
        # Create the comprehensive prompt
        comprehensive_prompt = IntelligentAssessmentDecision.create_comprehensive_prompt(
            requirement_text=large_requirement,
            context=large_context,
            application_overview=large_app_overview,
            ai_gathered_info=large_ai_info,
            similar_requirements=None
        )
        
        total_prompt_length = len(comprehensive_prompt)
        print(f"\n✅ Comprehensive prompt created successfully")
        print(f"✅ Total prompt length: {total_prompt_length:,} characters")
        
        # Verify all components are still present in the large prompt
        components_check = [
            ("Large requirement", "100,000 concurrent users" in comprehensive_prompt),
            ("Extensive context", "Enterprise Financial Trading Platform" in comprehensive_prompt),
            ("Large app overview", "$50+ billion in daily trading volume" in comprehensive_prompt),
            ("Large AI info", "PERFORMANCE BOTTLENECKS IDENTIFIED" in comprehensive_prompt),
            ("Assessment framework", "ASSESSMENT FRAMEWORK" in comprehensive_prompt),
            ("JSON format instruction", "json" in comprehensive_prompt.lower())
        ]
        
        print(f"\nLarge prompt component verification:")
        all_components_present = True
        for component, present in components_check:
            status = "✅" if present else "❌"
            print(f"{status} {component}: {'Present' if present else 'Missing'}")
            if not present:            all_components_present = False
        
        if all_components_present and total_prompt_length > 20000:
            # Test actual database storage by logging this large prompt
            try:
                from ai_interaction_wrapper import ai_logger
                
                # Log the large prompt to verify database storage
                interaction_id = ai_logger.log_interaction(
                    session_id="large_prompt_test",
                    user_identifier="test_user",
                    interaction_type="large_prompt_test",
                    prompt_text=comprehensive_prompt,
                    response_text="Large prompt test completed successfully",
                    model_used="test_model",
                    success=True,
                    context_data=large_context,
                    metadata={"test_type": "large_prompt_verification", "prompt_length": total_prompt_length}
                )
                
                print(f"\n✅ Large prompt logged to database (ID: {interaction_id})")
                
                # Verify it was stored correctly
                import sqlite3
                conn = sqlite3.connect('ai_interactions.db')
                cursor = conn.cursor()
                cursor.execute('SELECT LENGTH(prompt_text) FROM ai_interactions WHERE id = ?', (interaction_id,))
                stored_length = cursor.fetchone()[0]
                conn.close()
                
                if stored_length == total_prompt_length:
                    print(f"✅ Database verification: {stored_length:,} characters stored (no truncation)")
                else:
                    print(f"❌ Database verification failed: {stored_length} != {total_prompt_length}")
                    
            except Exception as e:
                print(f"⚠️  Could not verify database storage: {e}")
            
            print(f"\n🎉 LARGE PROMPT TEST PASSED")
            print(f"✅ No truncation detected in {total_prompt_length:,} character prompt")
            print(f"✅ All user inputs properly formatted into large comprehensive prompt")
            return True
        else:
            print(f"\n❌ LARGE PROMPT TEST FAILED")
            return False
            
    except Exception as e:
        print(f"❌ Error in large prompt test: {e}")
        return False

if __name__ == "__main__":
    test_large_prompt_handling()
