"""
AI Transparency Tracker for NFT Risk Assessment Tool
Tracks and logs all AI interactions for transparency and auditing purposes.
"""

import json
import os
import datetime
from typing import Dict, Any, Optional, List

class AITransparencyTracker:
    """
    Handles tracking and storing of all AI interactions for transparency.
    """
    
    def __init__(self, log_dir: Optional[str] = None):
        """
        Initialize the AI Transparency Tracker.
        
        Args:
            log_dir: Directory to store interaction logs (default: 'ai_interaction_logs' in project root)
        """
        if log_dir:
            self.log_dir = log_dir
        else:
            # Default to 'ai_interaction_logs' in project root
            self.log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ai_interaction_logs')
        
        # Create the log directory if it doesn't exist
        os.makedirs(self.log_dir, exist_ok=True)
    
    def capture_interaction(self, input_prompt: str, ai_response: str, context: Dict, 
                           interaction_type: str = "requirement_analysis") -> Dict[str, Any]:
        """
        Capture and log an AI interaction.
        
        Args:
            input_prompt: The complete prompt sent to the AI
            ai_response: The complete raw response received from the AI
            context: The context information used for the assessment
            interaction_type: Type of interaction (e.g., "requirement_analysis", "question_generation")
            
        Returns:
            Dict containing interaction metadata
        """
        timestamp = datetime.datetime.now().isoformat()
        project_name = context.get('project_name', 'Unnamed Project')
        
        # Create unique interaction ID
        interaction_id = f"{interaction_type}_{project_name.replace(' ', '_')}_{timestamp.replace(':', '-').split('.')[0]}"
        
        # Create interaction record
        interaction_record = {
            'interaction_id': interaction_id,
            'timestamp': timestamp,
            'interaction_type': interaction_type,
            'project_name': project_name,
            'input_prompt_length': len(input_prompt),
            'ai_response_length': len(ai_response),
            'input_prompt': input_prompt,
            'ai_response': ai_response,
            'context_summary': {
                'provided_fields': [k for k, v in context.items() if v and str(v).strip()],
                'missing_fields': [k for k, v in context.items() if not v or not str(v).strip()],
                'assessment_coverage': context.get('assessment_coverage', [])
            }
        }
        
        # Save the interaction log
        filename = f"{interaction_id}.json"
        filepath = os.path.join(self.log_dir, filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(interaction_record, f, indent=2)
        except Exception as e:
            print(f"Error logging AI interaction: {e}")
        
        return {
            'interaction_id': interaction_id,
            'log_filepath': filepath,
            'timestamp': timestamp
        }
    
    def get_interaction_log(self, interaction_id: str) -> Dict[str, Any]:
        """
        Retrieve a specific interaction log by ID.
        
        Args:
            interaction_id: The ID of the interaction to retrieve
            
        Returns:
            Dict containing the interaction record, or empty dict if not found
        """
        filepath = os.path.join(self.log_dir, f"{interaction_id}.json")
        
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error reading interaction log {interaction_id}: {e}")
                return {}
        else:
            return {}
    
    def list_interactions(self, project_name: Optional[str] = None, 
                         limit: int = 20) -> List[Dict[str, Any]]:
        """
        List recent interactions, optionally filtered by project name.
        
        Args:
            project_name: Optional project name to filter by
            limit: Maximum number of interactions to return
            
        Returns:
            List of interaction summary dictionaries
        """
        interactions = []
        
        try:
            files = os.listdir(self.log_dir)
            files.sort(key=lambda x: os.path.getmtime(os.path.join(self.log_dir, x)), reverse=True)
            
            for filename in files[:limit]:
                if not filename.endswith('.json'):
                    continue
                
                filepath = os.path.join(self.log_dir, filename)
                
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        
                        # Filter by project name if specified
                        if project_name and data.get('project_name') != project_name:
                            continue
                        
                        # Add summary to list
                        interactions.append({
                            'interaction_id': data.get('interaction_id'),
                            'timestamp': data.get('timestamp'),
                            'project_name': data.get('project_name'),
                            'interaction_type': data.get('interaction_type'),
                            'input_length': data.get('input_prompt_length'),
                            'response_length': data.get('ai_response_length')
                        })
                except Exception as e:
                    print(f"Error parsing {filename}: {e}")
        except Exception as e:
            print(f"Error listing interactions: {e}")
        
        return interactions

def get_latest_interaction(project_name: Optional[str] = None) -> Dict[str, Any]:
    """
    Convenience function to get the latest AI interaction for a project.
    
    Args:
        project_name: Optional project name to filter by
        
    Returns:
        The most recent interaction record, or empty dict if none found
    """
    tracker = AITransparencyTracker()
    interactions = tracker.list_interactions(project_name=project_name, limit=1)
    
    if interactions:
        return tracker.get_interaction_log(interactions[0]['interaction_id'])
    else:
        return {}
