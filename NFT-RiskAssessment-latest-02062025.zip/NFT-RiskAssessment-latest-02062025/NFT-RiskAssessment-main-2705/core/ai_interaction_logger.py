"""
AI Interaction Logger for NFT Risk Assessment Tool
Logs and validates all AI interactions with timestamp, user context, prompts, and responses.
"""

import json
import os
import sqlite3
import hashlib
import time
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
import threading

class AIInteractionLogger:
    """
    Centralized logging system for all AI interactions in the Scope Assessment tool.
    
    Features:
    - Logs all AI prompts and responses
    - Tracks user context and session information
    - Provides validation and audit capabilities
    - Thread-safe database operations
    - User transparency features
    """
    def __init__(self, db_path: str = None):
        """Initialize the AI interaction logger with database setup."""
        if db_path is None:
            # Get the directory where this script is located
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # Go up one level to the project root and then to data directory
            project_root = os.path.dirname(current_dir)
            db_path = os.path.join(project_root, "data", "ai_interactions.db")
            
            # Print path for debugging
            print(f"AI Interactions DB Path: {db_path}")
        
        self.db_path = db_path
        self.lock = threading.Lock()
        self._setup_database()
    
    def _setup_database(self):
        """Create the database and tables if they don't exist."""
        with self.lock:
            # Ensure the directory exists
            db_dir = os.path.dirname(self.db_path)
            if not os.path.exists(db_dir):
                os.makedirs(db_dir, exist_ok=True)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create AI interactions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ai_interactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    user_identifier TEXT,
                    interaction_type TEXT NOT NULL,
                    timestamp_utc TEXT NOT NULL,
                    model_used TEXT,
                    prompt_text TEXT NOT NULL,
                    prompt_hash TEXT NOT NULL,
                    response_text TEXT,
                    response_hash TEXT,
                    context_data TEXT,
                    metadata TEXT,
                    token_usage INTEGER,
                    response_time_ms INTEGER,
                    success BOOLEAN NOT NULL,
                    error_message TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes for performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_session_id ON ai_interactions(session_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON ai_interactions(timestamp_utc)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_interaction_type ON ai_interactions(interaction_type)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_identifier ON ai_interactions(user_identifier)")
            
            conn.commit()
            conn.close()
    
    def log_interaction(self, 
                       session_id: str,
                       user_identifier: str,
                       interaction_type: str,
                       prompt: str,
                       response: Optional[str] = None,
                       model_used: Optional[str] = None,
                       context_data: Optional[Dict] = None,
                       metadata: Optional[Dict] = None,
                       token_usage: Optional[int] = None,
                       response_time_ms: Optional[int] = None,
                       success: bool = True,
                       error_message: Optional[str] = None) -> str:
        """
        Log an AI interaction with all relevant details.
        
        Args:
            session_id: Unique session identifier
            user_identifier: User login/identifier (can be anonymous ID)
            interaction_type: Type of interaction (question_generation, risk_assessment, etc.)
            prompt: The prompt text sent to AI
            response: The response received from AI
            model_used: AI model used (e.g., gpt-4o)
            context_data: Additional context information
            metadata: Extra metadata about the interaction
            token_usage: Number of tokens used
            response_time_ms: Response time in milliseconds
            success: Whether the interaction was successful
            error_message: Error message if interaction failed
            
        Returns:
            Interaction ID as string
        """
        timestamp_utc = datetime.now(timezone.utc).isoformat()
        prompt_hash = hashlib.md5(prompt.encode()).hexdigest()
        response_hash = hashlib.md5(response.encode()).hexdigest() if response else None
        
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO ai_interactions (
                    session_id, user_identifier, interaction_type, timestamp_utc,
                    model_used, prompt_text, prompt_hash, response_text, response_hash,
                    context_data, metadata, token_usage, response_time_ms,
                    success, error_message
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                session_id, user_identifier, interaction_type, timestamp_utc,
                model_used, prompt, prompt_hash, response, response_hash,
                json.dumps(context_data) if context_data else None,
                json.dumps(metadata) if metadata else None,
                token_usage, response_time_ms, success, error_message
            ))
            
            interaction_id = str(cursor.lastrowid)
            conn.commit()
            conn.close()
            
        return interaction_id
    
    def get_session_interactions(self, session_id: str) -> List[Dict]:
        """Get all interactions for a specific session."""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM ai_interactions 
                WHERE session_id = ? 
                ORDER BY timestamp_utc
            """, (session_id,))
            
            columns = [description[0] for description in cursor.description]
            results = []
            
            for row in cursor.fetchall():
                interaction = dict(zip(columns, row))
                # Parse JSON fields
                if interaction['context_data']:
                    interaction['context_data'] = json.loads(interaction['context_data'])
                if interaction['metadata']:
                    interaction['metadata'] = json.loads(interaction['metadata'])
                results.append(interaction)
            
            conn.close()
            return results
    
    def get_user_interactions(self, user_identifier: str, limit: int = 100) -> List[Dict]:
        """Get recent interactions for a specific user."""
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT * FROM ai_interactions 
                WHERE user_identifier = ? 
                ORDER BY timestamp_utc DESC 
                LIMIT ?
            """, (user_identifier, limit))
            
            columns = [description[0] for description in cursor.description]
            results = []
            
            for row in cursor.fetchall():
                interaction = dict(zip(columns, row))
                # Parse JSON fields
                if interaction['context_data']:
                    interaction['context_data'] = json.loads(interaction['context_data'])
                if interaction['metadata']:
                    interaction['metadata'] = json.loads(interaction['metadata'])
                results.append(interaction)
            
            conn.close()
            return results
    
    def get_interaction_summary(self, time_range_hours: int = 24) -> Dict[str, Any]:
        """Get summary statistics for interactions within a time range."""
        cutoff_time = datetime.now(timezone.utc) - timedelta(hours=time_range_hours)
        cutoff_timestamp = cutoff_time.isoformat()
        
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Total interactions
            cursor.execute("""
                SELECT COUNT(*) FROM ai_interactions 
                WHERE timestamp_utc >= ?
            """, (cutoff_timestamp,))
            total_interactions = cursor.fetchone()[0]
            
            # Successful interactions
            cursor.execute("""
                SELECT COUNT(*) FROM ai_interactions 
                WHERE timestamp_utc >= ? AND success = 1
            """, (cutoff_timestamp,))
            successful_interactions = cursor.fetchone()[0]
            
            # Interactions by type
            cursor.execute("""
                SELECT interaction_type, COUNT(*) 
                FROM ai_interactions 
                WHERE timestamp_utc >= ?
                GROUP BY interaction_type
            """, (cutoff_timestamp,))
            interactions_by_type = dict(cursor.fetchall())
            
            # Average response time
            cursor.execute("""
                SELECT AVG(response_time_ms) 
                FROM ai_interactions 
                WHERE timestamp_utc >= ? AND response_time_ms IS NOT NULL
            """, (cutoff_timestamp,))
            avg_response_time = cursor.fetchone()[0]
            
            # Unique users
            cursor.execute("""
                SELECT COUNT(DISTINCT user_identifier) 
                FROM ai_interactions 
                WHERE timestamp_utc >= ?
            """, (cutoff_timestamp,))
            unique_users = cursor.fetchone()[0]
            
            conn.close()
            
            return {
                'time_range_hours': time_range_hours,
                'total_interactions': total_interactions,
                'successful_interactions': successful_interactions,
                'success_rate': successful_interactions / total_interactions if total_interactions > 0 else 0,
                'interactions_by_type': interactions_by_type,
                'average_response_time_ms': avg_response_time,
                'unique_users': unique_users
            }
    
    def validate_interaction_transparency(self, session_id: str) -> Dict[str, Any]:
        """
        Validate that users can see what was sent to AI and received back.
        Returns transparency report for a session.
        """
        interactions = self.get_session_interactions(session_id)
        
        transparency_report = {
            'session_id': session_id,
            'total_interactions': len(interactions),
            'interactions': []
        }
        
        for interaction in interactions:
            transparency_report['interactions'].append({
                'id': interaction['id'],
                'type': interaction['interaction_type'],
                'timestamp': interaction['timestamp_utc'],
                'model_used': interaction['model_used'],
                'prompt_preview': interaction['prompt_text'][:200] + '...' if len(interaction['prompt_text']) > 200 else interaction['prompt_text'],
                'response_preview': interaction['response_text'][:200] + '...' if interaction['response_text'] and len(interaction['response_text']) > 200 else interaction['response_text'],
                'success': interaction['success'],
                'error': interaction['error_message']
            })
        
        return transparency_report
    
    def export_interactions(self, output_format: str = "json", filters: Optional[Dict] = None) -> str:
        """
        Export interaction logs in specified format.
        
        Args:
            output_format: 'json' or 'csv'
            filters: Optional filters for the export
            
        Returns:
            Exported data as string
        """
        with self.lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            query = "SELECT * FROM ai_interactions"
            params = []
            
            if filters:
                conditions = []
                if 'session_id' in filters:
                    conditions.append("session_id = ?")
                    params.append(filters['session_id'])
                if 'user_identifier' in filters:
                    conditions.append("user_identifier = ?")
                    params.append(filters['user_identifier'])
                if 'interaction_type' in filters:
                    conditions.append("interaction_type = ?")
                    params.append(filters['interaction_type'])
                if 'start_date' in filters:
                    conditions.append("timestamp_utc >= ?")
                    params.append(filters['start_date'])
                if 'end_date' in filters:
                    conditions.append("timestamp_utc <= ?")
                    params.append(filters['end_date'])
                
                if conditions:
                    query += " WHERE " + " AND ".join(conditions)
            
            query += " ORDER BY timestamp_utc"
            
            cursor.execute(query, params)
            columns = [description[0] for description in cursor.description]
            results = cursor.fetchall()
            conn.close()
            
            if output_format.lower() == "json":
                interactions = []
                for row in results:
                    interaction = dict(zip(columns, row))
                    # Parse JSON fields
                    if interaction['context_data']:
                        interaction['context_data'] = json.loads(interaction['context_data'])
                    if interaction['metadata']:
                        interaction['metadata'] = json.loads(interaction['metadata'])
                    interactions.append(interaction)
                return json.dumps(interactions, indent=2)
            
            elif output_format.lower() == "csv":
                import csv
                from io import StringIO
                
                output = StringIO()
                writer = csv.writer(output)
                writer.writerow(columns)
                writer.writerows(results)
                return output.getvalue()
            
            else:
                raise ValueError(f"Unsupported output format: {output_format}")

# Global logger instance
ai_logger = AIInteractionLogger()

def get_user_identifier() -> str:
    """
    Get user identifier for logging. In production, this would be from authentication.
    For now, we'll use a session-based anonymous ID.
    """
    import streamlit as st
    
    if 'user_session_id' not in st.session_state:
        # Generate anonymous user ID based on session
        st.session_state.user_session_id = f"user_{int(time.time())}_{hash(str(st.session_state)) % 10000}"
    
    return st.session_state.user_session_id

def get_session_identifier():
    """
    Gets a unique identifier for the current user session
    with improved session tracking
    """
    try:
        import streamlit as st
        import uuid
        
        # Use a consistent session identifier if already set in session state
        if 'session_uuid' in st.session_state:
            return st.session_state.session_uuid
        
        # Try to use Streamlit's session for a more reliable session identifier
        if hasattr(st, 'session_state') and '_session_id' in dir(st):
            # Use a hash of Streamlit's internal session ID if available
            import hashlib
            session_id = hashlib.md5(str(st._session_id).encode()).hexdigest()
        else:
            # Generate a UUID as fallback
            session_id = str(uuid.uuid4())
            
        # Store for future consistency
        st.session_state.session_uuid = session_id
        
        return session_id
    except Exception as e:
        # Fall back to a random UUID if there are any issues
        import uuid
        print(f"Error getting session ID: {e}, falling back to random UUID")
        return str(uuid.uuid4())

# Add missing import
from datetime import timedelta
