# Enhanced GPT Logic for NFT Risk Assessment Tool
# Functions for composing prompts and interacting with the OpenAI API with improved accuracy and validation

import openai
import json
import traceback
import re
import time
from typing import Dict, List, Optional, Any
from datetime import datetime

# --- Constants ---
GPT_MODEL = "gpt-4o"
FALLBACK_MODEL = "gpt-4"  # Fallback if primary model fails
MAX_RETRIES = 3
RETRY_DELAY = 2  # seconds

# Risk validation constants
VALID_RISK_LEVELS = ["High", "Medium", "Low"]
REQUIRED_RESPONSE_KEYS = [
    "risk", "reasoning", "mandatory_testing", "recommended_testing", 
    "component_analysis", "impact"
]

# Testing categories for validation
MANDATORY_TESTING_CATEGORIES = [
    "Performance Testing", "Operational Acceptance Testing", "Single-user Performance Testing"
]

RECOMMENDED_TESTING_CATEGORIES = [
    "Security Testing", "Scalability Testing", "Reliability Testing", "Usability Testing",
    "Compatibility Testing", "Data Integrity Testing", "Integration Testing", "Accessibility Testing",
    "Compliance Testing", "Regression Testing"
]

# Advanced validation constants for enhanced quality assurance
ADVANCED_VALIDATION_WEIGHTS = {
    "logical_consistency": 0.25,
    "completeness_analysis": 0.20,
    "risk_justification": 0.20,
    "testing_adequacy": 0.15,
    "business_alignment": 0.10,
    "technical_feasibility": 0.10
}

QUALITY_THRESHOLDS = {
    "excellent": 0.90,
    "good": 0.75,
    "acceptable": 0.60,
    "needs_improvement": 0.45
}

class RiskAssessmentValidator:
    """Validates and enhances GPT responses for consistency and completeness."""
    
    @staticmethod
    def validate_risk_level(risk: str) -> tuple[bool, str]:
        """Validates risk level and provides correction if needed."""
        if not risk or risk not in VALID_RISK_LEVELS:
            return False, f"Invalid risk level '{risk}'. Must be one of: {VALID_RISK_LEVELS}"
        return True, ""
    
    @staticmethod
    def validate_reasoning_quality(reasoning: str, requirement_text: str) -> tuple[bool, str, str]:
        """Validates reasoning quality and provides enhanced reasoning if needed."""
        if not reasoning or len(reasoning.strip()) < 50:
            return False, "Reasoning too brief or missing", ""
        
        # Check if reasoning mentions key aspects
        key_aspects = ["performance", "security", "integration", "data", "user", "business"]
        mentioned_aspects = [aspect for aspect in key_aspects if aspect.lower() in reasoning.lower()]
        
        if len(mentioned_aspects) < 2:
            enhanced_reasoning = f"{reasoning}\n\nAdditional Analysis: The assessment considers multiple risk dimensions including technical complexity, business impact, and operational challenges based on the requirement: '{requirement_text[:100]}...'"
            return True, "Reasoning enhanced with additional context", enhanced_reasoning
        
        return True, "", reasoning
    
    @staticmethod
    def validate_testing_recommendations(mandatory_testing: Dict, recommended_testing: Dict) -> tuple[bool, str, Dict, Dict]:
        """Validates and enhances testing recommendations."""
        issues = []
        enhanced_mandatory = mandatory_testing.copy()
        enhanced_recommended = recommended_testing.copy()
        
        # Ensure mandatory testing has required categories
        for category in MANDATORY_TESTING_CATEGORIES:
            if category not in enhanced_mandatory:
                enhanced_mandatory[category] = {
                    "General": f"Perform {category.lower()} to ensure system reliability and performance standards are met."
                }
                issues.append(f"Added missing mandatory testing: {category}")
        
        # Validate testing descriptions are detailed enough
        for category, tests in enhanced_mandatory.items():
            for component, description in tests.items():
                if isinstance(description, str) and len(description) < 30:
                    enhanced_mandatory[category][component] = f"{description} This testing is critical to validate system behavior under expected conditions and ensure compliance with requirements."
                    issues.append(f"Enhanced description for {category} - {component}")
        
        for category, tests in enhanced_recommended.items():
            for component, description in tests.items():
                if isinstance(description, str) and len(description) < 30:
                    enhanced_recommended[category][component] = f"{description} This testing helps identify potential issues and ensures robust system performance across various scenarios."
                    issues.append(f"Enhanced description for {category} - {component}")
        
        return len(issues) == 0, "; ".join(issues), enhanced_mandatory, enhanced_recommended
    
    @staticmethod
    def validate_component_analysis(component_analysis: Dict, requirement_text: str) -> tuple[bool, str, Dict]:
        """Validates and enhances component analysis."""
        if not component_analysis:
            # Extract potential components from requirement text
            components = RiskAssessmentValidator._extract_components_from_text(requirement_text)
            enhanced_analysis = {}
            
            for component in components:
                enhanced_analysis[component] = {
                    "Performance Testing": f"Validate {component.lower()} performance under expected load conditions.",
                    "Security Testing": f"Ensure {component.lower()} meets security requirements and standards."
                }
            
            if not enhanced_analysis:
                enhanced_analysis = {
                    "System": {
                        "Performance Testing": "Validate overall system performance under expected conditions.",
                        "Reliability Testing": "Ensure system reliability and fault tolerance."
                    }
                }
            
            return False, "Component analysis was missing and has been generated", enhanced_analysis
        
        return True, "", component_analysis
    
    @staticmethod
    def _extract_components_from_text(text: str) -> List[str]:
        """Extracts potential system components from requirement text."""
        # Common component keywords
        component_patterns = [
            r'\b(API|api)\b', r'\b(database|DB|db)\b', r'\b(UI|user interface)\b',
            r'\b(backend|back-end)\b', r'\b(frontend|front-end)\b', r'\b(mobile app|application)\b',
            r'\b(web service|service)\b', r'\b(microservice)\b', r'\b(server)\b'
        ]
        
        components = set()
        text_lower = text.lower()
        
        for pattern in component_patterns:
            matches = re.findall(pattern, text_lower, re.IGNORECASE)
            for match in matches:
                if 'api' in match.lower():
                    components.add('API')
                elif 'database' in match.lower() or 'db' in match.lower():
                    components.add('Database')
                elif 'ui' in match.lower() or 'interface' in match.lower():
                    components.add('User Interface')
                elif 'app' in match.lower():
                    components.add('Application')
                elif 'service' in match.lower():
                    components.add('Service')
                elif 'server' in match.lower():
                    components.add('Server')
        
        return list(components) if components else ['System']

class EnhancedPromptComposer:
    """Enhanced prompt composition with context analysis and validation."""
    
    @staticmethod
    def analyze_context_quality(context: Dict) -> tuple[float, List[str]]:
        """Analyzes context quality and suggests improvements."""
        quality_score = 0.0
        suggestions = []
        total_possible = 10  # Maximum quality indicators
        
        # Check for essential context elements
        essential_elements = [
            ('performance requirements', ['performance', 'response time', 'load', 'users']),
            ('security requirements', ['security', 'authentication', 'authorization', 'compliance']),
            ('integration details', ['integration', 'api', 'third-party', 'external']),
            ('business criticality', ['critical', 'business', 'impact', 'priority']),
            ('technical constraints', ['constraint', 'limitation', 'requirement', 'standard'])
        ]
        
        for element_name, keywords in essential_elements:
            found = False
            for key, value in context.items():
                if any(keyword.lower() in str(value).lower() for keyword in keywords):
                    found = True
                    quality_score += 2
                    break
            
            if not found:
                suggestions.append(f"Consider providing {element_name} for more accurate assessment")
        
        # Bonus points for detailed context
        total_context_length = sum(len(str(v)) for v in context.values() if v)
        if total_context_length > 500:
            quality_score += 1
        elif total_context_length < 100:
            suggestions.append("Provide more detailed context for better assessment accuracy")
        
        return min(quality_score / total_possible, 1.0), suggestions
    
    @staticmethod
    def compose_enhanced_prompt(requirement_text: str, context: Dict, similar_requirements: Optional[List] = None) -> str:
        """Composes an enhanced prompt with validation and context analysis."""
        
        # Analyze context quality
        context_quality, context_suggestions = EnhancedPromptComposer.analyze_context_quality(context)
        
        prompt = f"""
You are an expert software risk analyst specializing in non-functional requirements assessment. Your task is to provide a comprehensive, accurate, and actionable risk assessment.

**CRITICAL INSTRUCTIONS:**
- Provide detailed, specific analysis based on the actual requirement content
- Ensure all testing recommendations are practical and implementable
- Consider real-world constraints and industry best practices
- Be specific about tools, methods, and approaches
- Focus on non-functional risks that could impact system reliability, performance, security, and user experience
- Use the provided Application Overview and Context Information to inform your assessment

**Requirement to Analyze:**
```
{requirement_text}
```

**Context Quality Score: {context_quality:.1%}**
"""

        # Feature 2: Add Application Overview section before other context
        application_overview = context.get('Application Overview', '')
        if application_overview and application_overview.strip():
            prompt += f"""
**Application Overview:**
{application_overview}

This application background should be considered when assessing the requirement's risk level and testing needs.
"""

        # Add context section with quality indicators
        if context:
            prompt += "\n**Context Information:**\n"
            for key, value in context.items():
                if value and str(value).strip() and str(value).lower() != 'n/a':
                    if key == "AI Assistant Gathered Information":
                        prompt += f"\n**AI-Gathered Information:**\n{value}\n"
                    elif key == "Application Overview":
                        # Skip Application Overview here as it's already added above
                        continue
                    else:
                        prompt += f"- **{key}**: {value}\n"
        else:
            prompt += "\n**Context Information:** Limited context provided. Assessment based on requirement text analysis.\n"
        
        if context_suggestions:
            prompt += f"\n**Note:** For future assessments, consider providing: {'; '.join(context_suggestions)}\n"

        # Add similar requirements analysis
        if similar_requirements:
            prompt += "\n**Historical Analysis (Similar Requirements):**\n"
            for i, req in enumerate(similar_requirements[:3]):  # Limit to top 3
                past_meta = req.get('metadata', {})
                prompt += f"\n{i+1}. **Previous Assessment:**\n"
                prompt += f"   - Requirement: {past_meta.get('requirement_text', 'N/A')[:100]}...\n"
                prompt += f"   - Risk Level: {past_meta.get('risk', 'N/A')}\n"
                prompt += f"   - Key Reasoning: {past_meta.get('reasoning', 'N/A')[:200]}...\n"
                prompt += f"   - Outcome: {past_meta.get('approved', 'Unknown')}\n"
            
            prompt += "\n**Learning from History:** Use these past assessments to inform your analysis, but ensure your assessment is tailored to the current requirement's unique characteristics.\n"

        prompt += f"""

**NFT SCOPE ASSESSMENT FRAMEWORK:**

### **Risk Analysis:**
Determine risk level (High/Medium/Low) based on:
- **Technical Complexity**: System integration points, data volumes, user loads
- **Operational Impact**: Effect on system availability, performance, and user experience
- **Change Scope**: Extent of modifications and potential failure points
- **Performance Requirements**: Response time, throughput, and scalability needs
- **System Dependencies**: Integration with third-party systems and external services

### **NFT Testing Strategy:**
For each testing type, provide:
- **Testing Justification**: Why this NFT is necessary for the specific requirement
- **Testing Approach**: Methodology, tools, and execution strategy
- **Scope Definition**: What will be tested and acceptance criteria
- **Testing Timeline**: Estimated duration and key milestones
- **Resource Requirements**: Team skills and infrastructure needs

### **Mandatory NFT Analysis:**
For each mandatory testing type:
- **Testing Rationale**: Why this testing is essential for system reliability
- **Testing Methodology**: Detailed approach including tools and techniques
- **Success Criteria**: Measurable outcomes and performance benchmarks
- **Risk Coverage**: Specific technical risks addressed by this testing

### **Recommended NFT Strategy:**
For each recommended testing type:
- **Testing Value**: Benefits gained from this non-functional testing
- **Risk Mitigation**: Specific risks addressed and failure scenarios prevented
- **Implementation Details**: Practical approach with tools and methods
- **Priority Level**: Critical/Important/Optional based on risk and impact

### **Component-Specific NFT Analysis:**
Identify key system components and provide:
- **Component Risk Level**: Technical risk assessment for each component
- **Performance Impact**: How component affects overall system performance
- **Testing Focus Areas**: Specific NFT areas to concentrate on per component
- **Integration Testing Needs**: Cross-component testing requirements
- **Performance Benchmarks**: Technical performance targets and thresholds

**RESPONSE FORMAT:**
Provide your response in the following JSON structure. Focus on NFT scope assessment:

```json
{{
  "risk": "High|Medium|Low",
  "reasoning": "Comprehensive analysis of technical risk factors including complexity, performance requirements, system dependencies, and potential failure scenarios. Minimum 200 characters with specific references to NFT considerations.",
  "confidence_score": 0.85,
  "assessment_metadata": {{
    "context_quality": {context_quality:.2f},
    "analysis_depth": "comprehensive|standard|basic",
    "similar_cases_used": {len(similar_requirements) if similar_requirements else 0},
    "nft_focus_applied": true
  }},
  "mandatory_testing": {{
    "Performance Testing": {{
      "API": {{
        "testing_rationale": "API performance testing ensures system can handle expected load and response time requirements.",
        "methodology": "Load testing using JMeter with realistic user scenarios, response time monitoring, and throughput analysis.",
        "success_criteria": "Response times meet SLA requirements under expected load, error rate <1%",
        "tools": ["JMeter", "Artillery", "LoadRunner"],
        "timeline": "2-3 weeks including test design, execution, and reporting",
        "risk_coverage": "Prevents performance degradation, ensures scalability, validates SLA compliance"
      }},
      "System": {{
        "testing_rationale": "End-to-end system performance validation under realistic load conditions.",
        "methodology": "System-level performance testing with realistic data volumes and concurrent users.",
        "success_criteria": "System maintains performance thresholds under peak load conditions",
        "tools": ["LoadRunner", "BlazeMeter", "Gatling"],
        "timeline": "3-4 weeks including environment setup and comprehensive testing",
        "risk_coverage": "Identifies system bottlenecks, validates capacity planning, ensures performance stability"
      }}
    }},
    "Operational Acceptance Testing": {{
      "Deployment": {{
        "testing_rationale": "Validates deployment process and system operability in production-like environment.",
        "methodology": "Deployment process testing, rollback procedures, and operational readiness validation.",
        "success_criteria": "Successful deployment with minimal downtime, validated rollback capability",
        "tools": ["Jenkins", "Ansible", "Docker", "Kubernetes"],
        "timeline": "1-2 weeks including automation setup and validation",
        "risk_coverage": "Prevents deployment failures, ensures operational readiness, validates recovery procedures"
      }},
      "Monitoring": {{
        "testing_rationale": "Ensures comprehensive monitoring and alerting for system health and performance.",
        "methodology": "Monitoring setup validation, alert configuration testing, and dashboard verification.",
        "success_criteria": "Complete monitoring coverage, timely alerting, actionable dashboards",
        "tools": ["DataDog", "New Relic", "Prometheus", "Grafana"],
        "timeline": "1-2 weeks including custom metrics and alert setup",
        "risk_coverage": "Enables proactive issue detection, ensures system observability, supports incident response"
      }}
    }}
  }},
  "recommended_testing": {{
    "Security Testing": {{
      "priority": "Critical|Important|Optional",
      "testing_value": "Identifies security vulnerabilities and ensures system protection against threats.",
      "risk_mitigation": "Prevents security breaches, protects sensitive data, ensures compliance with security standards.",
      "implementation_details": "Comprehensive security assessment including vulnerability scanning, penetration testing, and code analysis.",
      "tools": ["OWASP ZAP", "Burp Suite", "Nessus", "SonarQube"],
      "timeline": "2-3 weeks including remediation verification",
      "priority_rationale": "Based on data sensitivity and security requirements"
    }},
    "Scalability Testing": {{
      "priority": "Important",
      "testing_value": "Validates system ability to scale with increased load and user growth.",
      "risk_mitigation": "Prevents performance degradation during growth, ensures system can handle future requirements.",
      "implementation_details": "Progressive load testing with scaling validation and capacity planning analysis.",
      "tools": ["JMeter", "LoadRunner", "K6", "Artillery"],
      "timeline": "2-3 weeks including infrastructure scaling tests",
      "priority_rationale": "Based on expected growth and scalability requirements"
    }},
    "Reliability Testing": {{
      "priority": "Critical",
      "testing_value": "Ensures system stability and fault tolerance under various failure scenarios.",
      "risk_mitigation": "Prevents unexpected failures, validates recovery mechanisms, ensures high availability.",
      "implementation_details": "Fault injection testing, disaster recovery validation, and reliability assessment.",
      "tools": ["Chaos Monkey", "Gremlin", "Litmus", "Testcontainers"],
      "timeline": "2-4 weeks including disaster recovery testing",
      "priority_rationale": "Based on system criticality and availability requirements"
    }}
  }},
  "component_analysis": {{
    "API": {{
      "component_risk_level": "High|Medium|Low",
      "performance_impact": "Direct impact on user experience and system responsiveness",
      "testing_focus_areas": ["Response time", "Throughput", "Error handling", "Security", "Rate limiting"],
      "integration_testing_needs": "Third-party API integration testing, service mesh validation",
      "performance_benchmarks": "Response time <2s, Throughput >1000 req/sec, Error rate <0.1%"
    }},
    "Database": {{
      "component_risk_level": "High",
      "performance_impact": "Critical for data operations and overall system performance",
      "testing_focus_areas": ["Query performance", "Data integrity", "Backup/recovery", "Scalability"],
      "integration_testing_needs": "Database cluster testing, replication validation",
      "performance_benchmarks": "Query response <500ms, 100% data integrity, Recovery time <1 hour"
    }},
    "User Interface": {{
      "component_risk_level": "Medium",
      "performance_impact": "Affects user experience and adoption",
      "testing_focus_areas": ["Load time", "Responsiveness", "Cross-browser compatibility", "Accessibility"],
      "integration_testing_needs": "Frontend-backend integration, third-party widget testing",
      "performance_benchmarks": "Page load <3s, Mobile responsiveness, WCAG compliance"
    }}
  }},
  "impact": {{
    "Performance Testing": "Poor performance can lead to user dissatisfaction, system timeouts, and operational issues.",
    "Security Testing": "Security vulnerabilities can result in data breaches, compliance violations, and system compromises.",
    "Reliability Testing": "System failures can cause service disruptions, data loss, and operational downtime."
  }},
  "quality_assurance": {{
    "validation_performed": true,
    "consistency_check": "passed|warning|failed",
    "completeness_score": 0.95,
    "recommendations_actionable": true,
    "nft_coverage_adequate": true
  }}
}}
```

**QUALITY REQUIREMENTS:**
- Risk reasoning must clearly explain technical factors and NFT considerations
- Testing descriptions must include methodology, tools, and measurable success criteria
- Component analysis must focus on technical risks and performance implications
- All testing recommendations must be actionable with clear approaches and timelines
- Risk assessment must reference specific technical complexity and system dependencies
- Testing strategies must be comprehensive and cover all relevant NFT areas
- All recommendations must include appropriate tools and implementation details
- Assessment must provide clear NFT scope and testing coverage
- Focus on technical accuracy and practical implementation guidance

**NFT FOCUS REQUIREMENTS:**
- Use clear technical language appropriate for development and testing teams
- Prioritize system performance, reliability, and operational considerations
- Include specific testing methodologies and tool recommendations
- Provide measurable criteria for success and acceptance
- Address scalability, security, and performance requirements
- Focus on system quality attributes and non-functional characteristics
- Emphasize technical risk mitigation and quality assurance
- Include comprehensive testing coverage for all system components
- Address operational readiness and deployment considerations

Provide a thorough, technically-focused NFT assessment that serves as a reliable foundation for testing strategy and implementation.
"""

        return prompt

def enhanced_get_gpt_assessment(prompt: str, api_key: str, model: str = GPT_MODEL) -> Dict[str, Any]:
    """Enhanced GPT assessment with validation, retries, and quality assurance."""
    
    if not api_key:
        print("Warning: No OpenAI API Key provided. Returning enhanced simulated response.")
        return simulate_enhanced_gpt_response()
    
    validator = RiskAssessmentValidator()
    
    for attempt in range(MAX_RETRIES):
        try:
            client = openai.OpenAI(api_key=api_key)
            
            # Try primary model first
            current_model = model if attempt == 0 else FALLBACK_MODEL
            
            response = client.chat.completions.create(
                model=current_model,
                messages=[
                    {
                        "role": "system", 
                        "content": "You are an expert software risk analyst with 15+ years of experience in non-functional requirements assessment. Provide accurate, detailed, and actionable risk assessments."
                    },
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.3,  # Lower temperature for more consistent results
                max_tokens=4000,  # Ensure sufficient space for detailed response
            )
            
            content = response.choices[0].message.content
            parsed_response = parse_enhanced_gpt_response(content, validator)
            
            # Validate and enhance response
            enhanced_response = validate_and_enhance_response(parsed_response, validator)
            
            # Add metadata about the assessment process
            enhanced_response["_metadata"] = {
                "model_used": current_model,
                "attempt": attempt + 1,
                "timestamp": datetime.now().isoformat(),
                "validation_applied": True
            }
            
            return enhanced_response
            
        except openai.AuthenticationError:
            print("Error: OpenAI Authentication Failed. Check your API key.")
            raise
        except openai.RateLimitError:
            print(f"Error: OpenAI Rate Limit Exceeded. Attempt {attempt + 1}/{MAX_RETRIES}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))  # Exponential backoff
                continue
            raise
        except openai.APITimeoutError:
            print(f"Error: OpenAI API Timeout. Attempt {attempt + 1}/{MAX_RETRIES}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY)
                continue
            raise
        except openai.APIConnectionError:
            print(f"Error: OpenAI API Connection Failed. Attempt {attempt + 1}/{MAX_RETRIES}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY)
                continue
            raise
        except Exception as e:
            print(f"Error calling OpenAI API (attempt {attempt + 1}): {e}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY)
                continue
            return {"error": f"Failed after {MAX_RETRIES} attempts: {str(e)}"}
    
    return {"error": f"Maximum retries ({MAX_RETRIES}) exceeded"}

def parse_enhanced_gpt_response(response_content: str, validator: RiskAssessmentValidator) -> Dict[str, Any]:
    """Enhanced parsing with validation and error recovery."""
    
    try:
        parsed_data = json.loads(response_content)
        
        # Validate required keys
        missing_keys = [key for key in REQUIRED_RESPONSE_KEYS if key not in parsed_data]
        if missing_keys:
            print(f"Warning: Missing required keys: {missing_keys}")
            parsed_data["_validation_warnings"] = f"Missing keys: {missing_keys}"
            
            # Add default values for missing keys
            for key in missing_keys:
                if key == "risk":
                    parsed_data[key] = "Medium"
                elif key == "reasoning":
                    parsed_data[key] = "Assessment completed with limited information."
                elif key in ["mandatory_testing", "recommended_testing", "component_analysis", "impact"]:
                    parsed_data[key] = {}
        
        return parsed_data
        
    except json.JSONDecodeError as e:
        print(f"Error: Failed to decode GPT response as JSON: {e}")
        print("Raw response:", response_content[:500] + "..." if len(response_content) > 500 else response_content)
        
        # Attempt to extract partial information
        return extract_partial_response(response_content)
    except Exception as e:
        print(f"Error parsing GPT response: {e}")
        return {"error": f"Response parsing failed: {e}"}

def extract_partial_response(content: str) -> Dict[str, Any]:
    """Extracts partial information from malformed responses."""
    
    partial_response = {
        "risk": "Medium",
        "reasoning": "Response parsing encountered issues, assessment may be incomplete.",
        "mandatory_testing": {},
        "recommended_testing": {},
        "component_analysis": {},
        "impact": {},
        "_parsing_warning": "Partial extraction from malformed response"
    }
    
    # Try to extract risk level
    risk_match = re.search(r'"risk":\s*"(High|Medium|Low)"', content, re.IGNORECASE)
    if risk_match:
        partial_response["risk"] = risk_match.group(1)
    
    # Try to extract reasoning
    reasoning_match = re.search(r'"reasoning":\s*"([^"]*)"', content)
    if reasoning_match:
        partial_response["reasoning"] = reasoning_match.group(1)
    
    return partial_response

def validate_and_enhance_response(response: Dict[str, Any], validator: RiskAssessmentValidator) -> Dict[str, Any]:
    """Validates and enhances the response for quality and completeness."""
    
    enhanced_response = response.copy()
    validation_notes = []
    
    # Validate risk level
    risk_valid, risk_message = validator.validate_risk_level(enhanced_response.get("risk"))
    if not risk_valid:
        enhanced_response["risk"] = "Medium"  # Default to Medium
        validation_notes.append(f"Risk level corrected: {risk_message}")
    
    # Validate and enhance reasoning
    reasoning_valid, reasoning_message, enhanced_reasoning = validator.validate_reasoning_quality(
        enhanced_response.get("reasoning", ""), 
        enhanced_response.get("_original_requirement", "")
    )
    if enhanced_reasoning:
        enhanced_response["reasoning"] = enhanced_reasoning
        validation_notes.append(reasoning_message)
    
    # Validate testing recommendations
    testing_valid, testing_message, enhanced_mandatory, enhanced_recommended = validator.validate_testing_recommendations(
        enhanced_response.get("mandatory_testing", {}),
        enhanced_response.get("recommended_testing", {})
    )
    if not testing_valid:
        enhanced_response["mandatory_testing"] = enhanced_mandatory
        enhanced_response["recommended_testing"] = enhanced_recommended
        validation_notes.append(testing_message)
    
    # Validate component analysis
    component_valid, component_message, enhanced_components = validator.validate_component_analysis(
        enhanced_response.get("component_analysis", {}),
        enhanced_response.get("_original_requirement", "")
    )
    if not component_valid:
        enhanced_response["component_analysis"] = enhanced_components
        validation_notes.append(component_message)
    
    # Add validation metadata
    if validation_notes:
        enhanced_response["_validation_applied"] = validation_notes
    
    # Add quality score
    enhanced_response["_quality_score"] = calculate_response_quality(enhanced_response)
    
    return enhanced_response

def calculate_response_quality(response: Dict[str, Any]) -> float:
    """Calculates a quality score for the response."""
    
    score = 0.0
    max_score = 10.0
    
    # Risk and reasoning quality (2 points)
    if response.get("risk") in VALID_RISK_LEVELS:
        score += 1
    if len(response.get("reasoning", "")) > 100:
        score += 1
    
    # Testing recommendations completeness (3 points)
    mandatory_testing = response.get("mandatory_testing", {})
    if len(mandatory_testing) >= 2:
        score += 1
    if any(len(str(desc)) > 50 for test_group in mandatory_testing.values() if isinstance(test_group, dict) for desc in test_group.values()):
        score += 1
    
    recommended_testing = response.get("recommended_testing", {})
    if len(recommended_testing) >= 3:
        score += 1
    
    # Component analysis quality (2 points)
    component_analysis = response.get("component_analysis", {})
    if len(component_analysis) >= 1:
        score += 1
    if any(len(str(comp)) > 50 for comp in component_analysis.values()):
        score += 1
    
    # Impact analysis quality (2 points)
    impact = response.get("impact", {})
    if len(impact) >= 2:
        score += 1
    if any(len(str(imp)) > 50 for imp in impact.values()):
        score += 1
    
    # Additional quality checks (1 point)
    if not response.get("error") and len(response.get("_validation_applied", [])) <= 2:
        score += 1
    
    return round(score / max_score, 2)

def simulate_enhanced_gpt_response() -> Dict[str, Any]:
    """Provides an enhanced simulated response for development/testing focused on NFT assessment."""
    
    import random
    
    risk_level = random.choice(VALID_RISK_LEVELS)
    
    return {
        "risk": risk_level,
        "reasoning": f"This requirement presents {risk_level.lower()} non-functional risk based on technical complexity analysis. Key factors include system integration requirements, performance thresholds that must be validated, scalability considerations for expected load, security requirements for data protection, and operational readiness for production deployment. The assessment considers technical architecture implications, testing coverage needs, and potential failure scenarios.",
        "confidence_score": round(random.uniform(0.8, 0.95), 2),
        "assessment_metadata": {
            "context_quality": round(random.uniform(0.7, 0.9), 2),
            "analysis_depth": "comprehensive",
            "similar_cases_used": 0,
            "nft_focus_applied": True
        },
        "mandatory_testing": {
            "Performance Testing": {
                "API": {
                    "testing_rationale": "API performance testing ensures system can handle expected load and response time requirements.",
                    "methodology": "Load testing using JMeter with realistic user scenarios, response time monitoring, and throughput analysis.",
                    "success_criteria": "Response times meet SLA requirements under expected load, error rate <1%",
                    "tools": ["JMeter", "Artillery", "LoadRunner"],
                    "timeline": "2-3 weeks including test design, execution, and reporting",
                    "risk_coverage": "Prevents performance degradation, ensures scalability, validates SLA compliance"
                },
                "System": {
                    "testing_rationale": "End-to-end system performance validation under realistic load conditions.",
                    "methodology": "System-level performance testing with realistic data volumes and concurrent users.",
                    "success_criteria": "System maintains performance thresholds under peak load conditions",
                    "tools": ["LoadRunner", "BlazeMeter", "Gatling"],
                    "timeline": "3-4 weeks including environment setup and comprehensive testing",
                    "risk_coverage": "Identifies system bottlenecks, validates capacity planning, ensures performance stability"
                }
            },
            "Operational Acceptance Testing": {
                "Deployment": {
                    "testing_rationale": "Validates deployment process and system operability in production-like environment.",
                    "methodology": "Deployment process testing, rollback procedures, and operational readiness validation.",
                    "success_criteria": "Successful deployment with minimal downtime, validated rollback capability",
                    "tools": ["Jenkins", "Ansible", "Docker", "Kubernetes"],
                    "timeline": "1-2 weeks including automation setup and validation",
                    "risk_coverage": "Prevents deployment failures, ensures operational readiness, validates recovery procedures"
                }
            }
        },
        "recommended_testing": {
            "Security Testing": {
                "priority": "Critical",
                "testing_value": "Identifies security vulnerabilities and ensures system protection against threats.",
                "risk_mitigation": "Prevents security breaches, protects sensitive data, ensures compliance with security standards.",
                "implementation_details": "Comprehensive security assessment including vulnerability scanning, penetration testing, and code analysis.",
                "tools": ["OWASP ZAP", "Burp Suite", "Nessus", "SonarQube"],
                "timeline": "2-3 weeks including remediation verification",
                "priority_rationale": "Based on data sensitivity and security requirements"
            },
            "Scalability Testing": {
                "priority": "Important",
                "testing_value": "Validates system ability to scale with increased load and user growth.",
                "risk_mitigation": "Prevents performance degradation during growth, ensures system can handle future requirements.",
                "implementation_details": "Progressive load testing with scaling validation and capacity planning analysis.",
                "tools": ["JMeter", "LoadRunner", "K6", "Artillery"],
                "timeline": "2-3 weeks including infrastructure scaling tests",
                "priority_rationale": "Based on expected growth and scalability requirements"
            },
            "Reliability Testing": {
                "priority": "Critical",
                "testing_value": "Ensures system stability and fault tolerance under various failure scenarios.",
                "risk_mitigation": "Prevents unexpected failures, validates recovery mechanisms, ensures high availability.",
                "implementation_details": "Fault injection testing, disaster recovery validation, and reliability assessment.",
                "tools": ["Chaos Monkey", "Gremlin", "Litmus", "Testcontainers"],
                "timeline": "2-4 weeks including disaster recovery testing",
                "priority_rationale": "Based on system criticality and availability requirements"
            }
        },
        "component_analysis": {
            "API": {
                "component_risk_level": "High",
                "performance_impact": "Direct impact on user experience and system responsiveness",
                "focus_areas": ["Response time", "Throughput", "Error handling", "Security", "Rate limiting"],
                "performance_benchmarks": "Response time <2s, Throughput >1000 req/sec, Error rate <0.1%",
                "risk_factors": ["High traffic load", "Integration complexity", "Security vulnerabilities"],
                "testing_strategy": "Comprehensive API testing including load, security, and integration validation"
            },
            "Database": {
                "component_risk_level": "High",
                "performance_impact": "Critical for data operations and overall system performance",
                "focus_areas": ["Query performance", "Data integrity", "Backup/recovery", "Scalability"],
                "performance_benchmarks": "Query response <500ms, 100% data integrity, Recovery time <1 hour",
                "risk_factors": ["Data corruption", "Performance bottlenecks", "Capacity limitations"],
                "testing_strategy": "Database testing including performance optimization, data integrity validation, and disaster recovery verification"
            },
            "User Interface": {
                "component_risk_level": "Medium",
                "performance_impact": "Affects user experience and adoption",
                "focus_areas": ["Load time", "Responsiveness", "Cross-browser compatibility", "Accessibility"],
                "performance_benchmarks": "Page load <3s, Mobile responsiveness, WCAG compliance",
                "risk_factors": ["Browser compatibility issues", "Performance degradation", "Accessibility gaps"],
                "testing_strategy": "UI testing including performance, compatibility, and accessibility validation"
            }
        },
        "impact": {
            "Performance Testing": "Poor performance can lead to user dissatisfaction, system timeouts, and operational issues.",
            "Security Testing": "Security vulnerabilities can result in data breaches, compliance violations, and system compromises.",
            "Reliability Testing": "System failures can cause service disruptions, data loss, and operational downtime."
        },
        "quality_assurance": {
            "validation_performed": True,
            "consistency_check": "passed",
            "completeness_score": 0.95,
            "recommendations_actionable": True,
            "nft_coverage_adequate": True
        },
        "_quality_score": round(random.uniform(0.85, 0.98), 2),
        "_simulated": True,
        "_metadata": {
            "model_used": "simulation",
            "attempt": 1,
            "timestamp": datetime.now().isoformat(),
            "validation_applied": True
        }
    }

# Backward compatibility functions
def compose_prompt(requirement_text: str, context: Dict, similar_requirements: Optional[List] = None) -> str:
    """Backward compatibility wrapper for compose_enhanced_prompt."""
    return EnhancedPromptComposer.compose_enhanced_prompt(requirement_text, context, similar_requirements)

def get_gpt_assessment(prompt: str, api_key: str) -> Dict[str, Any]:
    """Backward compatibility wrapper for enhanced_get_gpt_assessment."""
    return enhanced_get_gpt_assessment(prompt, api_key)

def parse_gpt_response(response_content: str) -> Dict[str, Any]:
    """Backward compatibility wrapper for parse_enhanced_gpt_response."""
    validator = RiskAssessmentValidator()
    return parse_enhanced_gpt_response(response_content, validator)

def simulate_gpt_response() -> Dict[str, Any]:
    """Backward compatibility wrapper for simulate_enhanced_gpt_response."""
    return simulate_enhanced_gpt_response()
