#!/usr/bin/env python3
"""
Test script to verify the intelligent assessment decision logic works correctly.
This script tests both scenarios: sufficient information (direct assessment) and 
insufficient information (AI interaction required).
"""

import sys
import os

# Add the parent directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    # Test import of the intelligent assessment logic
    from core.intelligent_assessment_logic import IntelligentAssessmentDecision
    print("✓ Successfully imported IntelligentAssessmentDecision")
    
    print("\n" + "="*80)
    print("TEST 1: INSUFFICIENT INFORMATION SCENARIO")
    print("="*80)
    
    # Test with insufficient requirement (short text)
    insufficient_requirement = "System should be fast"
    insufficient_context = {
        'project_name': 'Test Project',
        'change_type': 'Performance Enhancement'
        # Missing most required fields
    }
    insufficient_app_overview = ""  # No application overview
    
    print(f"📝 Requirement: '{insufficient_requirement}'")
    print(f"📊 Word count: {len(insufficient_requirement.split())} words")
    print(f"🏗️ Context fields: {len([k for k, v in insufficient_context.items() if v])}")
    print(f"📖 Application overview: {'No' if not insufficient_app_overview else 'Yes'}")
    
    # Analyze completeness
    analysis_1 = IntelligentAssessmentDecision.analyze_information_completeness(
        requirement_text=insufficient_requirement,
        context=insufficient_context,
        application_overview=insufficient_app_overview
    )
    
    print(f"\n🎯 RESULTS:")
    print(f"   Completeness Score: {analysis_1['completeness_percentage']}%")
    print(f"   Can Proceed Directly: {analysis_1['can_proceed_directly']}")
    print(f"   Decision: {'🟢 DIRECT ASSESSMENT' if analysis_1['can_proceed_directly'] else '🔴 NEEDS AI INTERACTION'}")
    print(f"   Reasoning: {analysis_1['decision_reason']}")
    
    if analysis_1['missing_areas']:
        print(f"\n❌ Missing Areas:")
        for area in analysis_1['missing_areas']:
            print(f"   - {area}")
    
    if analysis_1['available_information']:
        print(f"\n✅ Available Information:")
        for info in analysis_1['available_information']:
            print(f"   - {info}")
    
    print("\n" + "="*80)
    print("TEST 2: SUFFICIENT INFORMATION SCENARIO")
    print("="*80)
    
    # Test with sufficient requirement (detailed text and context)
    sufficient_requirement = """
    The e-commerce payment processing system must handle 1000 concurrent transactions 
    per second with a maximum response time of 500ms during peak shopping periods. 
    The system should maintain 99.9% uptime and ensure PCI DSS compliance for all 
    credit card transactions. Performance degradation should not exceed 2% when 
    scaling from normal to peak load conditions.
    """
    sufficient_context = {
        'project_name': 'E-commerce Payment System',
        'change_type': 'Performance Enhancement',
        'component_name': 'Payment Processing Service',
        'components_involved': 'Backend Change',
        'customization_level': 'High',
        'channel_impact': 'Critical to Business',
        'performance_issues': 'Yes – Severe impact on user experience.',
        'business_disruption': 'Yes – Completely stops the application.',
        'contingency_plans': 'Yes',
        'assessment_coverage': ['Performance Testing (Load, Stress, etc.)', 'Security'],
        'ui_response_time': '< 500ms',
        'backend_volume': '1000 transactions/second',
        'backend_response_time': '< 500ms'
    }
    sufficient_app_overview = """
    This is a critical e-commerce platform serving over 2 million customers worldwide. 
    The system processes millions of transactions daily using a microservices architecture 
    deployed on AWS cloud infrastructure. The payment processing component is the most 
    critical part of the system as it directly impacts revenue and customer satisfaction.
    """
    
    print(f"📝 Requirement: {len(sufficient_requirement.strip())} characters")
    print(f"📊 Word count: {len(sufficient_requirement.split())} words")
    print(f"🏗️ Context fields: {len([k for k, v in sufficient_context.items() if v])}")
    print(f"📖 Application overview: {'Yes' if sufficient_app_overview else 'No'} ({len(sufficient_app_overview)} chars)")
    
    # Analyze completeness
    analysis_2 = IntelligentAssessmentDecision.analyze_information_completeness(
        requirement_text=sufficient_requirement,
        context=sufficient_context,
        application_overview=sufficient_app_overview
    )
    
    print(f"\n🎯 RESULTS:")
    print(f"   Completeness Score: {analysis_2['completeness_percentage']}%")
    print(f"   Can Proceed Directly: {analysis_2['can_proceed_directly']}")
    print(f"   Decision: {'🟢 DIRECT ASSESSMENT' if analysis_2['can_proceed_directly'] else '🔴 NEEDS AI INTERACTION'}")
    print(f"   Reasoning: {analysis_2['decision_reason']}")
    
    if analysis_2['missing_areas']:
        print(f"\n❌ Missing Areas:")
        for area in analysis_2['missing_areas']:
            print(f"   - {area}")
    
    if analysis_2['available_information']:
        print(f"\n✅ Available Information:")
        for info in analysis_2['available_information']:
            print(f"   - {info}")
    
    print("\n" + "="*80)
    print("TEST 3: COMPREHENSIVE PROMPT CREATION")
    print("="*80)
    
    # Test comprehensive prompt creation for both scenarios
    print("Testing comprehensive prompt creation for sufficient information scenario...")
    
    comprehensive_prompt = IntelligentAssessmentDecision.create_comprehensive_prompt(
        requirement_text=sufficient_requirement,
        context=sufficient_context,
        application_overview=sufficient_app_overview,
        ai_gathered_info="Additional performance requirements gathered: System must handle Black Friday traffic spikes of 5x normal load.",
        similar_requirements=None
    )
    
    print(f"✓ Comprehensive prompt created successfully")
    print(f"✓ Prompt length: {len(comprehensive_prompt)} characters")
    
    # Verify all information sources are included
    checks = [
        ("Requirement text", sufficient_requirement.strip()[:50] in comprehensive_prompt),
        ("Application overview", sufficient_app_overview[:50] in comprehensive_prompt),
        ("Context information", "E-commerce Payment System" in comprehensive_prompt),
        ("AI gathered info", "Black Friday traffic spikes" in comprehensive_prompt),
        ("Assessment framework", "ASSESSMENT FRAMEWORK" in comprehensive_prompt),
        ("JSON response format", "json" in comprehensive_prompt.lower())
    ]
    
    all_passed = True
    for check_name, result in checks:
        if result:
            print(f"✓ {check_name} included in prompt")
        else:
            print(f"✗ {check_name} NOT included in prompt")
            all_passed = False
    
    print("\n" + "="*80)
    print("SUMMARY")
    print("="*80)
    
    if analysis_1['can_proceed_directly']:
        print("❌ TEST 1 FAILED: Insufficient information scenario should require AI interaction")
        all_passed = False
    else:
        print("✅ TEST 1 PASSED: Insufficient information correctly identified")
    
    if not analysis_2['can_proceed_directly']:
        print("❌ TEST 2 FAILED: Sufficient information scenario should allow direct assessment")
        all_passed = False
    else:
        print("✅ TEST 2 PASSED: Sufficient information correctly identified for direct assessment")
    
    if all_passed:
        print("✅ TEST 3 PASSED: Comprehensive prompt creation working correctly")
        print("\n🎉 ALL TESTS PASSED!")
        print("\n📋 SYSTEM BEHAVIOR:")
        print("   - ✅ Analyzes information completeness intelligently")
        print("   - ✅ Makes correct decisions about direct assessment vs AI interaction")
        print("   - ✅ Creates comprehensive prompts with ALL information sources")
        print("   - ✅ Provides clear feedback about missing information")
        print("\n🚀 The intelligent assessment system is working correctly!")
        print("   When requirements are insufficient, the AI will ask questions to gather more information.")
        print("   When requirements are sufficient, the AI will provide direct comprehensive assessment.")
    else:
        print("\n❌ Some tests failed. Please check the implementation.")
    
except ImportError as e:
    print(f"✗ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"✗ Test error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
