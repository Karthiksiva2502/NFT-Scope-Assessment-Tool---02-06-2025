"""
Requirement Quality Checker for NFT Risk Assessment Tool
Evaluates requirements based on key quality metrics including:
- Clarity
- Testability
- Completeness
- Consistency
- Traceability
"""

import openai
import json
import re

# Quality metrics with descriptions
QUALITY_METRICS = {
    "clarity": "Measures how clearly the requirement is stated and how easy it is to understand",
    "testability": "Measures how easily the requirement can be verified through testing",
    "completeness": "Measures whether the requirement contains all necessary information",
    "consistency": "Measures whether the requirement conflicts with other requirements",
    "traceability": "Measures how well the requirement can be traced to its source and related components"
}

def analyze_requirement_quality(requirement_text, context, api_key, model="gpt-4o"):
    """
    Analyzes the quality of a requirement based on several metrics and provides improvement suggestions.
    
    Args:
        requirement_text (str): The text of the requirement to analyze
        context (dict): Additional context information about the requirement
        api_key (str): OpenAI API key
        model (str): OpenAI model to use for analysis
        
    Returns:
        dict: Analysis results including scores and suggestions
    """
    if not requirement_text.strip():
        return {
            "error": "No requirement text provided for quality analysis."
        }
        
    try:
        client = openai.OpenAI(api_key=api_key)
        
        # Build context string
        context_string = ""
        if context:
            context_string = "\n\nAdditional Context:\n"
            for key, value in context.items():
                if value and str(value).strip() and str(value).lower() != 'n/a':
                    context_string += f"- {key}: {value}\n"
        
        # Create prompt for quality analysis
        prompt = f"""
        Analyze the following requirement for quality metrics. Evaluate on a scale of 1-10 (10 being best):

        Requirement Text:
        ```
        {requirement_text}
        ```
        {context_string}
        
        For each of these quality attributes, provide:
        1. A score from 1-10
        2. Specific reasons for the score
        3. Concrete suggestions for improvement
        
        Quality attributes to evaluate:
        - Clarity: Is the requirement clear, unambiguous, and easily understood?
        - Testability: Can the requirement be objectively tested or verified?
        - Completeness: Does the requirement contain all necessary information?
        - Consistency: Is the requirement free from contradictions with other requirements or itself?
        - Traceability: Can the requirement be traced to source needs and related components?
        
        Provide an overall quality score (average of all metrics).
        
        Format your response as a valid JSON object with the following structure:
        ```
        {{
            "scores": {{
                "clarity": <score>,
                "testability": <score>,
                "completeness": <score>,
                "consistency": <score>,
                "traceability": <score>,
                "overall": <average_score>
            }},
            "analysis": {{
                "clarity": "<reasons for clarity score>",
                "testability": "<reasons for testability score>",
                "completeness": "<reasons for completeness score>",
                "consistency": "<reasons for consistency score>",
                "traceability": "<reasons for traceability score>"
            }},
            "suggestions": {{
                "clarity": ["<suggestion 1>", "<suggestion 2>", ...],
                "testability": ["<suggestion 1>", "<suggestion 2>", ...],
                "completeness": ["<suggestion 1>", "<suggestion 2>", ...],
                "consistency": ["<suggestion 1>", "<suggestion 2>", ...],
                "traceability": ["<suggestion 1>", "<suggestion 2>", ...]
            }}
        }}
        ```
        """
        
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are an expert requirements engineer specializing in requirements quality analysis."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.3,
        )
        
        result = json.loads(response.choices[0].message.content)
        
        # Ensure all expected fields are present
        for metric in QUALITY_METRICS.keys():
            if metric not in result.get("scores", {}):
                result.setdefault("scores", {})[metric] = 0
            if metric not in result.get("analysis", {}):
                result.setdefault("analysis", {})[metric] = "Analysis not available."
            if metric not in result.get("suggestions", {}):
                result.setdefault("suggestions", {})[metric] = ["No suggestions available."]
        
        # Make sure overall score is present
        if "overall" not in result.get("scores", {}):
            scores = result.get("scores", {})
            result["scores"]["overall"] = round(sum(scores.get(m, 0) for m in QUALITY_METRICS.keys()) / len(QUALITY_METRICS), 1)
        
        return result
        
    except Exception as e:
        import traceback
        print(f"Error in quality analysis: {e}")
        print(traceback.format_exc())
        return {
            "error": f"An error occurred during quality analysis: {str(e)}"
        }

def perform_basic_quality_checks(requirement_text):
    """
    Performs basic quality checks on the requirement text without calling an AI model.
    
    Args:
        requirement_text (str): The requirement text to analyze
        
    Returns:
        dict: Basic analysis results
    """
    results = {
        "simple_checks": {},
        "warnings": []
    }
    
    # Check for minimum length
    word_count = len(requirement_text.split())
    results["simple_checks"]["word_count"] = word_count
    if word_count < 10:
        results["warnings"].append("Requirement text is very short. Consider adding more details.")
    
    # Check for ambiguous words
    ambiguous_words = ["good", "fast", "efficient", "reliable", "user-friendly", "easy to use", 
                      "flexible", "robust", "sufficient", "adequate", "appropriate", "etc.", "and/or"]
    found_ambiguous = []
    for word in ambiguous_words:
        if word in requirement_text.lower():
            found_ambiguous.append(word)
    
    if found_ambiguous:
        results["simple_checks"]["ambiguous_words"] = found_ambiguous
        results["warnings"].append(f"Contains ambiguous terms: {', '.join(found_ambiguous)}")
    
    # Check for measurable criteria
    has_measurable = bool(re.search(r'\d+\s*[%s]|\d+\s*ms|\d+\s*sec|\d+\s*min', requirement_text))
    results["simple_checks"]["has_measurable_criteria"] = has_measurable
    if not has_measurable:
        results["warnings"].append("No measurable criteria found. Consider adding specific, measurable targets.")
    
    # Check for imperative language
    imperative_words = ["shall", "must", "will", "should"]
    has_imperative = any(word in requirement_text.lower().split() for word in imperative_words)
    results["simple_checks"]["has_imperative_language"] = has_imperative
    if not has_imperative:
        results["warnings"].append("No imperative language (shall, must, will, should) detected.")
    
    return results
