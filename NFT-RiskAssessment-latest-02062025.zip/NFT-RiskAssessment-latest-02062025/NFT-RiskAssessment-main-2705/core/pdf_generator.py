# Function to generate PDF reports using FPDF2
from fpdf import FPDF
import time
import uuid
import re

class PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, 'Requirement Risk Assessment Report', 0, 1, 'C')
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    def chapter_title(self, title):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, title, 0, 1, 'L')
        self.ln(5)

    def chapter_body(self, body):
        self.set_font('Arial', '', 10)
        # Use multi_cell for automatic line breaks
        self.multi_cell(0, 5, body)
        self.ln()
    
    # Add missing methods
    def setup_document(self):
        """Initialize the document with basic settings"""
        self.add_page()
        self.set_auto_page_break(auto=True, margin=15)
        self.set_font("Arial", "B", 16)
    
    def add_heading(self, text, size=14):
        """Add a heading with specified font size"""
        self.set_font("Arial", "B", size)
        self.cell(0, 10, text, 0, 1)
        self.ln(2)
    
    def add_title(self, title):
        """Add main title to the document"""
        self.set_font("Arial", "B", 18)
        self.cell(0, 10, title, 0, 1, 'C')
        self.ln(10)
    
    def add_text(self, text):
        """Add regular text paragraph"""
        # Clean up text to handle potential encoding issues
        if text:
            text = re.sub(r'\n\s*\n', '\n\n', text)  # Normalize multiple newlines
            text = text.encode('latin-1', 'replace').decode('latin-1')  # Handle encoding
        else:
            text = "N/A"
            
        self.set_font("Arial", "", 10)
        self.multi_cell(0, 5, text)
        self.ln(5)
    
    def add_summary_item(self, label, value):
        """Add a summary item with label and value"""
        self.set_font("Arial", "B", 10)
        self.cell(40, 8, label, 0, 0)
        self.set_font("Arial", "", 10)
        self.cell(0, 8, str(value), 0, 1)
    
    def get_pdf_bytes(self):
        """Return the PDF as bytes"""
        # FPDF's output with dest='S' might return bytearray, convert to bytes explicitly
        output = self.output(dest='S')
        # Ensure we return bytes, not bytearray
        if isinstance(output, bytearray):
            return bytes(output)
        return output

    def add_assessment_section(self, title, content):
        """Add a section with title and content to the PDF."""
        self.add_heading(title, 14)
        
        # Handle content that might be a dictionary (for structured JSON responses)
        if isinstance(content, dict):
            # Convert dictionary to formatted string
            formatted_content = ""
            for key, value in content.items():
                if isinstance(value, dict):
                    # Handle nested dictionaries
                    formatted_content += f"{key}:\n"
                    for sub_key, sub_value in value.items():
                        formatted_content += f"  • {sub_key}: {sub_value}\n"
                    formatted_content += "\n"
                else:
                    formatted_content += f"{key}: {value}\n\n"
            content = formatted_content
    
        # Now that content is guaranteed to be a string, we can use string methods
        content = str(content)  # Ensure it's a string
        content_cleaned = content.replace('\u2022', '-').encode('latin-1', 'replace').decode('latin-1')
        
        self.set_font("Arial", "", 10)
        self.multi_cell(0, 5, content_cleaned)
        self.ln(5)

    def add_business_summary_section(self, title, content):
        """Add a business summary section with enhanced formatting."""
        self.set_font("Arial", "B", 11)
        self.cell(0, 8, title, 0, 1)
        
        # Handle different content types
        if isinstance(content, list):
            content_str = ', '.join(str(item) for item in content)
        else:
            content_str = str(content) if content else "N/A"
            
        content_cleaned = content_str.replace('\u2022', '-').encode('latin-1', 'replace').decode('latin-1')
        
        self.set_font("Arial", "", 10)
        self.multi_cell(0, 5, content_cleaned)
        self.ln(3)

    def add_financial_analysis_section(self, financial_data):
        """Add financial impact analysis with business focus."""
        if not financial_data:
            self.add_text("Financial analysis not available.")
            return
            
        if isinstance(financial_data, dict):
            for testing_category, analysis in financial_data.items():
                self.set_font("Arial", "B", 12)
                self.cell(0, 8, testing_category, 0, 1)
                self.ln(2)
                
                if isinstance(analysis, dict):
                    # Investment Required
                    if 'investment_required' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Investment Required:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['investment_required']))
                        self.ln(2)
                    
                    # Cost of Not Testing
                    if 'cost_of_not_testing' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Cost of Not Testing:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['cost_of_not_testing']))
                        self.ln(2)
                    
                    # Business Continuity Risk
                    if 'business_continuity_risk' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Business Continuity Risk:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['business_continuity_risk']))
                        self.ln(2)
                    
                    # Customer Experience Impact
                    if 'customer_experience_impact' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Customer Experience Impact:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['customer_experience_impact']))
                        self.ln(2)
                    
                    # Revenue Protection Value
                    if 'revenue_protection_value' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Revenue Protection Value:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['revenue_protection_value']))
                        self.ln(3)
                else:
                    self.set_font("Arial", "", 10)
                    self.multi_cell(0, 5, str(analysis))
                    self.ln(3)
        else:
            self.add_text(str(financial_data))

    def add_business_testing_section(self, testing_data):
        """Add testing section with business-focused formatting."""
        if not testing_data:
            self.add_text("Testing information not available.")
            return
            
        if isinstance(testing_data, dict):
            for test_type, details in testing_data.items():
                self.set_font("Arial", "B", 12)
                self.cell(0, 8, test_type, 0, 1)
                self.ln(2)
                
                if isinstance(details, dict):
                    for component, info in details.items():
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, f"{component}:", 0, 1)
                        
                        if isinstance(info, dict):
                            # Business rationale
                            if 'business_rationale' in info:
                                self.set_font("Arial", "I", 9)
                                self.cell(0, 5, "Business Rationale:", 0, 1)
                                self.set_font("Arial", "", 9)
                                self.multi_cell(0, 4, str(info['business_rationale']))
                                self.ln(1)
                            
                            # Methodology
                            if 'methodology' in info:
                                self.set_font("Arial", "I", 9)
                                self.cell(0, 5, "Methodology:", 0, 1)
                                self.set_font("Arial", "", 9)
                                self.multi_cell(0, 4, str(info['methodology']))
                                self.ln(1)
                            
                            # Success criteria
                            if 'success_criteria' in info:
                                self.set_font("Arial", "I", 9)
                                self.cell(0, 5, "Success Criteria:", 0, 1)
                                self.set_font("Arial", "", 9)
                                self.multi_cell(0, 4, str(info['success_criteria']))
                                self.ln(1)
                            
                            # Tools
                            if 'tools' in info:
                                tools_str = ', '.join(info['tools']) if isinstance(info['tools'], list) else str(info['tools'])
                                self.set_font("Arial", "I", 9)
                                self.cell(0, 5, "Tools:", 0, 1)
                                self.set_font("Arial", "", 9)
                                self.multi_cell(0, 4, tools_str)
                                self.ln(1)
                            
                            # Timeline
                            if 'timeline' in info:
                                self.set_font("Arial", "I", 9)
                                self.cell(0, 5, "Timeline:", 0, 1)
                                self.set_font("Arial", "", 9)
                                self.multi_cell(0, 4, str(info['timeline']))
                                self.ln(1)
                            
                            # Cost-Benefit
                            if 'cost_benefit' in info:
                                self.set_font("Arial", "I", 9)
                                self.cell(0, 5, "Cost-Benefit Analysis:", 0, 1)
                                self.set_font("Arial", "", 9)
                                self.multi_cell(0, 4, str(info['cost_benefit']))
                                self.ln(2)
                        else:
                            self.set_font("Arial", "", 9)
                            self.multi_cell(0, 4, str(info))
                            self.ln(2)
                else:
                    self.set_font("Arial", "", 10)
                    self.multi_cell(0, 5, str(details))
                    self.ln(3)
        else:
            self.add_text(str(testing_data))

    def add_component_business_analysis(self, component_data):
        """Add component analysis with business focus."""
        if not component_data:
            self.add_text("Component analysis not available.")
            return
            
        if isinstance(component_data, dict):
            for component, analysis in component_data.items():
                self.set_font("Arial", "B", 12)
                self.cell(0, 8, component, 0, 1)
                self.ln(2)
                
                if isinstance(analysis, dict):
                    # Business criticality
                    if 'business_criticality' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Business Criticality:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['business_criticality']))
                        self.ln(2)
                    
                    # Customer impact
                    if 'customer_impact' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Customer Impact:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['customer_impact']))
                        self.ln(2)
                    
                    # Revenue dependency
                    if 'revenue_dependency' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Revenue Dependency:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['revenue_dependency']))
                        self.ln(2)
                    
                    # Risks
                    if 'risks' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Key Risks:", 0, 1)
                        self.set_font("Arial", "", 10)
                        risks_str = ', '.join(analysis['risks']) if isinstance(analysis['risks'], list) else str(analysis['risks'])
                        self.multi_cell(0, 5, risks_str)
                        self.ln(2)
                    
                    # Testing strategy
                    if 'testing_strategy' in analysis:
                        self.set_font("Arial", "B", 10)
                        self.cell(0, 6, "Testing Strategy:", 0, 1)
                        self.set_font("Arial", "", 10)
                        self.multi_cell(0, 5, str(analysis['testing_strategy']))
                        self.ln(3)
                else:
                    self.set_font("Arial", "", 10)
                    self.multi_cell(0, 5, str(analysis))
                    self.ln(3)
        else:
            self.add_text(str(component_data))

    def add_action_plan_section(self, action_plan):
        """Add action plan with business execution focus."""
        if not action_plan:
            self.add_text("Action plan not available.")
            return
            
        if isinstance(action_plan, dict):
            # Immediate actions
            if 'immediate_actions' in action_plan:
                self.set_font("Arial", "B", 11)
                self.cell(0, 8, "Immediate Actions (1-2 weeks):", 0, 1)
                self.set_font("Arial", "", 10)
                actions = action_plan['immediate_actions']
                if isinstance(actions, list):
                    for action in actions:
                        self.multi_cell(0, 5, f"• {action}")
                else:
                    self.multi_cell(0, 5, str(actions))
                self.ln(3)
            
            # Short-term goals
            if 'short_term_goals' in action_plan:
                self.set_font("Arial", "B", 11)
                self.cell(0, 8, "Short-term Goals (1-3 months):", 0, 1)
                self.set_font("Arial", "", 10)
                goals = action_plan['short_term_goals']
                if isinstance(goals, list):
                    for goal in goals:
                        self.multi_cell(0, 5, f"• {goal}")
                else:
                    self.multi_cell(0, 5, str(goals))
                self.ln(3)
            
            # Long-term strategy
            if 'long_term_strategy' in action_plan:
                self.set_font("Arial", "B", 11)
                self.cell(0, 8, "Long-term Strategy (3-12 months):", 0, 1)
                self.set_font("Arial", "", 10)
                strategy = action_plan['long_term_strategy']
                if isinstance(strategy, list):
                    for item in strategy:
                        self.multi_cell(0, 5, f"• {item}")
                else:
                    self.multi_cell(0, 5, str(strategy))
                self.ln(3)
            
            # Success metrics
            if 'success_metrics' in action_plan:
                self.set_font("Arial", "B", 11)
                self.cell(0, 8, "Success Metrics:", 0, 1)
                self.set_font("Arial", "", 10)
                metrics = action_plan['success_metrics']
                if isinstance(metrics, list):
                    for metric in metrics:
                        self.multi_cell(0, 5, f"• {metric}")
                else:
                    self.multi_cell(0, 5, str(metrics))
                self.ln(3)
            
            # Review schedule
            if 'review_schedule' in action_plan:
                self.set_font("Arial", "B", 11)
                self.cell(0, 8, "Review Schedule:", 0, 1)
                self.set_font("Arial", "", 10)
                self.multi_cell(0, 5, str(action_plan['review_schedule']))
                self.ln(3)
        else:
            self.add_text(str(action_plan))


def generate_pdf_report(assessment_data):
    """Generate a PDF report from the assessment data."""
    pdf = PDF()
    pdf.setup_document()
    
    # Add title
    pdf.add_title("NFT Risk Assessment Report")
    
    # Add summary section
    pdf.add_heading("Assessment Summary", 16)
    pdf.add_summary_item("Assessment ID:", assessment_data.get('id', 'N/A'))
    pdf.add_summary_item("Project:", assessment_data.get('project_name', 'N/A'))
    pdf.add_summary_item("Risk Level:", assessment_data.get('risk', 'N/A'))
    pdf.add_summary_item("Status:", assessment_data.get('status', 'Pending'))
    
    # Add timestamp if available
    timestamp = assessment_data.get('timestamp')
    if timestamp:
        date_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
        pdf.add_summary_item("Assessment Date:", date_str)
    
    # Add requirement section
    pdf.add_heading("Requirement", 16)
    requirement_text = assessment_data.get('requirement_text', 'N/A')
    pdf.add_text(requirement_text)
    
    # Add detailed risk reasoning
    pdf.add_assessment_section("Risk Analysis & Reasoning:", assessment_data.get('reasoning', 'N/A'))
    
    # Handle testing sections with simplified NFT focus
    if 'mandatory_testing' in assessment_data:
        pdf.add_heading("Mandatory NFT Requirements", 16)
        pdf.add_assessment_section("", assessment_data.get('mandatory_testing', 'N/A'))
    
    if 'recommended_testing' in assessment_data:
        pdf.add_heading("Recommended NFT Strategy", 16)
        pdf.add_assessment_section("", assessment_data.get('recommended_testing', 'N/A'))
    elif 'recommendations' in assessment_data:
        pdf.add_assessment_section("Recommended Testing:", assessment_data.get('recommendations', 'N/A'))
    
    # Add Component Analysis with technical focus
    if 'component_analysis' in assessment_data:
        pdf.add_heading("Component-Specific NFT Analysis", 16)
        pdf.add_assessment_section("", assessment_data.get('component_analysis', 'N/A'))
    
    # NFT Impact Analysis section has been removed per user request
    
    # Add reviewer comments if available
    comments = assessment_data.get('comments')
    if comments and comments.strip():
        pdf.add_assessment_section("Reviewer Comments:", comments)
    
    # Get the PDF content as bytes
    pdf_bytes = pdf.get_pdf_bytes()
    
    # Ensure we're returning bytes, not bytearray for Streamlit compatibility
    if isinstance(pdf_bytes, bytearray):
        pdf_bytes = bytes(pdf_bytes)
    
    return pdf_bytes

# Example Usage (for testing)
if __name__ == '__main__':
    dummy_data = {
        'requirement_text': "The system must allow users to upload profile pictures.",
        'context': {
            'project_type': 'Enhancement', 'sensitive_data': 'Yes (PII)',
            'user_volume': 'Medium (1000 concurrent)', 'performance': 'High (sub-second uploads)',
            'accessibility': 'Yes (WCAG AA)', 'integrations': 'No', 'uptime': '99.9%'
        },
        'risk': 'Medium',
        'reasoning': 'Handles PII (profile pictures) and has performance requirements. Needs security and load testing.',
        'mandatory_testing': {
            'Security Testing': {
                'technical_rationale': 'File upload functionality handling PII requires vulnerability assessment',
                'methodology': 'OWASP security scanning and penetration testing',
                'success_criteria': 'No critical or high vulnerabilities found',
                'tools': ['OWASP ZAP', 'Burp Suite'],
                'timeline': '2-3 days'
            }
        },
        'recommended_testing': {
            'Performance Testing': {
                'technical_rationale': 'Sub-second upload requirement needs performance validation',
                'methodology': 'Load testing with concurrent users',
                'success_criteria': 'Upload completes within 1 second under load',
                'tools': ['JMeter', 'LoadRunner'],
                'timeline': '3-4 days'
            }
        },
        'component_analysis': {
            'File Upload Component': {
                'focus_areas': ['File validation', 'Size limits', 'Format restrictions'],
                'performance_benchmarks': 'Upload time < 1 second for files up to 5MB',
                'risk_factors': ['File type bypass', 'Size overflow', 'Malicious content'],
                'testing_strategy': 'Boundary value testing and security validation'
            }
        },
        'impact': {
            'security_risks': ['Data exposure', 'System compromise', 'PII breach'],
            'performance_impact': ['Poor user experience', 'System slowdown', 'Resource exhaustion']
        },
        'approved': True,
        'comments': 'Approved after verifying security scan results.',
        'timestamp': int(time.time()) - 86400, # Yesterday
        'id': str(uuid.uuid4())
    }
    pdf_bytes = generate_pdf_report(dummy_data)
    with open("sample_report.pdf", "wb") as f:
        f.write(pdf_bytes)
    print("Sample PDF report generated: sample_report.pdf")
