#!/usr/bin/env python3
"""
Test script to verify AI interaction logging integration
"""

import sys
import os
import time

# Add the parent directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_imports():
    """Test that all AI logging components can be imported"""
    print("Testing imports...")
    try:
        from core.ai_interaction_logger import AIInteractionLogger, ai_logger, get_session_identifier, get_user_identifier
        print("✅ AI interaction logger imported successfully")
    except Exception as e:
        print(f"❌ Failed to import AI interaction logger: {e}")
        return False
    
    try:
        from core.ai_interaction_wrapper import (
            wrapped_generate_ai_questions,
            wrapped_get_gpt_assessment,
            wrapped_analyze_requirement_quality,
            wrapped_generate_embedding,
            get_ai_transparency_report,
            get_current_session_interactions,
            export_ai_interaction_logs
        )
        print("✅ AI interaction wrapper imported successfully")
    except Exception as e:
        print(f"❌ Failed to import AI interaction wrapper: {e}")
        return False
    
    return True

def test_logger_functionality():
    """Test basic logger functionality"""
    print("\nTesting logger functionality...")
    
    try:
        from core.ai_interaction_logger import ai_logger, get_session_identifier
        
        # Test session ID generation
        session_id = get_session_identifier()
        print(f"✅ Session ID generated: {session_id}")
        
        # Test logging interaction
        interaction_id = ai_logger.log_interaction(
            session_id=session_id,
            user_identifier="test_user",
            interaction_type="test_interaction",
            prompt="Test prompt for AI logging",
            response="Test response from AI",
            model_used="test-model",
            context_data={"test": "data"},
            metadata={"test_run": True},
            response_time_ms=100,
            success=True
        )
        
        print(f"✅ Test interaction logged with ID: {interaction_id}")
        
        # Test retrieving interactions
        session_interactions = ai_logger.get_session_interactions(session_id)
        if session_interactions:
            print(f"✅ Retrieved {len(session_interactions)} session interactions")
        else:
            print("⚠️ No session interactions found")
        
        return True
        
    except Exception as e:
        print(f"❌ Logger functionality test failed: {e}")
        return False

def test_wrapper_structure():
    """Test that wrapper functions are properly structured"""
    print("\nTesting wrapper structure...")
    try:
        from core.ai_interaction_wrapper import AIInteractionWrapper
        
        # Check if the main wrapper class exists
        wrapper = AIInteractionWrapper()
        print("✅ AIInteractionWrapper class instantiated")
        
        # Check if log_and_call_openai method exists
        if hasattr(wrapper, 'log_and_call_openai'):
            print("✅ log_and_call_openai method exists")
        else:
            print("❌ log_and_call_openai method missing")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Wrapper structure test failed: {e}")
        return False

def test_transparency_functions():
    """Test transparency reporting functions"""
    print("\nTesting transparency functions...")
    try:
        from core.ai_interaction_wrapper import (
            get_ai_transparency_report,
            get_current_session_interactions
        )
        
        # Test transparency report
        report = get_ai_transparency_report()
        print(f"✅ Transparency report generated: {type(report)}")
        
        # Test current session interactions
        interactions = get_current_session_interactions()
        print(f"✅ Current session interactions retrieved: {type(interactions)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Transparency functions test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("AI INTERACTION LOGGING INTEGRATION TEST")
    print("=" * 60)
    
    tests = [
        test_imports,
        test_logger_functionality,
        test_wrapper_structure,
        test_transparency_functions
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ Test {test.__name__} crashed: {e}")
    
    print("\n" + "=" * 60)
    print(f"TEST RESULTS: {passed}/{total} tests passed")
    print("=" * 60)
    
    if passed == total:
        print("🎉 All tests passed! AI logging integration is working correctly.")
        return True
    else:
        print("⚠️ Some tests failed. Please check the output above.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
