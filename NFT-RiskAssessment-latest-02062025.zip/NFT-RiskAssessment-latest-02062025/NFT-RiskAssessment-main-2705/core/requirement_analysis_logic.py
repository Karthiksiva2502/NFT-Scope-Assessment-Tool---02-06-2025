"""
Requirement Analysis Logic for Missing Information Feature
Implements the structured prompt format as specified by user requirements.
"""

from typing import Dict, Any, Optional
import json


class RequirementAnalysisEngine:
    """
    Handles requirement analysis with structured prompt format:
    1. Application Overview
    2. Contextual Information (Q&A about Application Requirements)  
    3. Requirement text/file upload contents
    4. Action to AI model for Scope Assessment
    """
    
    @staticmethod
    def build_structured_prompt(
        requirement_text: str,
        application_overview: str = "",
        contextual_qa: Dict[str, Any] = None,
        additional_info: str = ""
    ) -> str:
        """
        Build the structured prompt exactly as specified by user requirements.
        
        Args:
            requirement_text: All requirement information (text/file content)
            application_overview: Application overview content
            contextual_qa: Q&A about the Application Requirements
            additional_info: Any additional information gathered
            
        Returns:
            Structured prompt for AI model
        """
        
        # Start with the structured format
        prompt = "Input Prompt to AI:\n\n"
        
        # 1. Application Overview Section
        prompt += f"Application Overview: {application_overview if application_overview.strip() else 'No application overview provided'}\n\n"
        
        # 2. Contextual Information Section (Q&A format)
        prompt += "Contextual Information: "
        if contextual_qa and any(v for v in contextual_qa.values() if v and str(v).strip()):
            prompt += "\n"
            
            # Structure as Q&A format
            qa_pairs = RequirementAnalysisEngine._format_as_qa(contextual_qa)
            for qa in qa_pairs:
                prompt += f"{qa}\n"
        else:
            prompt += "No contextual information provided\n"
        
        prompt += "\n"
        
        # 3. Requirement text/file upload contents
        prompt += f"Requirement text/file Upload contents: {requirement_text}\n\n"
        
        # 4. Action to AI model
        prompt += """Action to AI model: Hey, analyze all the information provided above and generate the proper Scope Assessment Result using it. If you have any additional questions that need to be answered, ask them in a single statement that includes all questions/information you want further.

Provide your response in the following JSON structure:

{
  "assessment_result": {
    "risk": "High|Medium|Low",
    "reasoning": "Comprehensive analysis based on all provided information",
    "confidence_score": 0.85,
    "can_proceed": true
  },
  "additional_questions_needed": "Single statement with all additional questions if any information is missing, or null if assessment can be completed",
  "information_analysis": {
    "application_overview_quality": "Good|Fair|Poor|Missing",
    "contextual_information_adequacy": "Sufficient|Partial|Insufficient", 
    "requirement_detail_level": "Detailed|Adequate|Basic|Vague"
  },
  "scope_assessment": {
    "mandatory_testing": {
      "Performance Testing": {
        "rationale": "Specific reasoning based on provided information",
        "approach": "Testing methodology and tools"
      }
    },
    "recommended_testing": {
      "Security Testing": {
        "rationale": "Why this testing is recommended",
        "approach": "Testing methodology"
      }
    }
  }
}"""
        
        return prompt
    
    @staticmethod
    def _format_as_qa(contextual_info: Dict[str, Any]) -> list:
        """
        Format contextual information as Q&A pairs.
        
        Args:
            contextual_info: Dictionary of contextual information
            
        Returns:
            List of formatted Q&A strings
        """
        qa_pairs = []
        
        # Define question templates for different context types
        question_templates = {
            'project_name': 'Q: What is the project name?',
            'change_type': 'Q: What type of change is being implemented?',
            'application_component_name': 'Q: What application or component is being modified?',
            'components_involved': 'Q: Which system components are involved in this change?',
            'business_critical_volume': 'Q: What is the expected volume of business-critical processes?',
            'response_time_sla': 'Q: What are the expected response time SLAs?',
            'growth_rate': 'Q: What is the expected growth rate over the next year?',
            'customization_level': 'Q: What level of customization or modification is required?',
            'channel_impact': 'Q: Which channels or components will be impacted?',
            'performance_issues': 'Q: Are there any known performance or scalability concerns?',
            'business_disruption': 'Q: What business disruption could occur due to change failure?',
            'contingency_plans': 'Q: What contingency plans are in place for business continuity?',
            'assessment_coverage': 'Q: What testing coverage areas are required?',
            'infrastructure_changes': 'Q: What infrastructure changes are needed?',
            'third_party_involvement': 'Q: Are there any third-party dependencies?',
            'security_requirements': 'Q: What are the security requirements?',
            'compliance_needs': 'Q: What compliance requirements must be met?',
            'integration_points': 'Q: What are the key integration points?'
        }
        
        for key, value in contextual_info.items():
            if value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...']:
                # Get question template or create generic one
                question = question_templates.get(key, f'Q: What is the {key.replace("_", " ")}?')
                answer = f'A: {value}'
                qa_pairs.append(f'{question}\n{answer}')
        
        return qa_pairs
    
    @staticmethod
    def analyze_information_completeness(
        requirement_text: str,
        application_overview: str = "",
        contextual_info: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Analyze if we have enough information to proceed with assessment
        or if we need to ask additional questions.
        
        Args:
            requirement_text: The requirement text
            application_overview: Application overview
            contextual_info: Contextual Q&A information
            
        Returns:
            Analysis result with recommendation
        """
        
        score = 0
        max_score = 100
        missing_areas = []
        
        # Analyze requirement text (40 points max)
        if requirement_text and len(requirement_text.strip()) > 10:
            word_count = len(requirement_text.split())
            if word_count >= 50:
                score += 40
            elif word_count >= 20:
                score += 30
            elif word_count >= 10:
                score += 20
            else:
                score += 10
                missing_areas.append("More detailed requirement description needed")
        else:
            missing_areas.append("Requirement text is too brief or missing")
        
        # Analyze application overview (25 points max)
        if application_overview and len(application_overview.strip()) > 20:
            word_count = len(application_overview.split())
            if word_count >= 30:
                score += 25
            elif word_count >= 15:
                score += 20
            else:
                score += 15
        else:
            score += 0
            missing_areas.append("Application overview is missing or too brief")
        
        # Analyze contextual information (35 points max)
        if contextual_info:
            valid_items = [v for v in contextual_info.values() 
                          if v and str(v).strip() and str(v).lower() not in ['n/a', 'none', 'select...']]
            
            if len(valid_items) >= 8:
                score += 35
            elif len(valid_items) >= 5:
                score += 25
            elif len(valid_items) >= 3:
                score += 15
            else:
                score += 5
                missing_areas.append("More contextual information needed")
        else:
            missing_areas.append("Contextual information is missing")
        
        # Calculate percentage and decision
        percentage = (score / max_score) * 100
        can_proceed = percentage >= 60  # Need at least 60% completeness
        
        return {
            'completeness_percentage': round(percentage, 1),
            'can_proceed_directly': can_proceed,
            'missing_areas': missing_areas,
            'recommendation': 'Proceed with assessment' if can_proceed else 'Gather additional information first',
            'score_breakdown': {
                'requirement_text': min(40, score if requirement_text else 0),
                'application_overview': min(25, score if application_overview else 0),
                'contextual_info': min(35, score if contextual_info else 0)
            }
        }
    
    @staticmethod
    def generate_missing_info_question(
        requirement_text: str,
        application_overview: str = "",
        contextual_info: Dict[str, Any] = None
    ) -> str:
        """
        Generate a single comprehensive question for missing information.
        
        Args:
            requirement_text: The requirement text
            application_overview: Application overview
            contextual_info: Current contextual information
            
        Returns:
            Single comprehensive question string
        """
        
        analysis = RequirementAnalysisEngine.analyze_information_completeness(
            requirement_text, application_overview, contextual_info
        )
        
        # If we can proceed, return None
        if analysis['can_proceed_directly']:
            return None
        
        # Build a comprehensive question based on missing areas
        missing_areas = analysis['missing_areas']
        question_parts = []
        
        if "More detailed requirement description needed" in missing_areas:
            question_parts.append(
                "Please provide more detailed information about the specific functionality, "
                "technical requirements, and expected behavior of this system change"
            )
        
        if "Application overview is missing or too brief" in missing_areas:
            question_parts.append(
                "Please describe the application architecture, user base, business criticality, "
                "and current performance characteristics"
            )
        
        if "More contextual information needed" in missing_areas:
            question_parts.append(
                "Please provide details about expected transaction volumes, response time requirements, "
                "security considerations, integration points, and potential business impact"
            )
        
        if question_parts:
            question = "To provide an accurate scope assessment, I need additional information. " + \
                      "Could you please provide: " + "; ".join(question_parts) + "?"
        else:
            question = "Please provide more comprehensive information about the performance requirements, " + \
                      "security considerations, and business impact to ensure accurate scope assessment."
        
        return question


# Helper function to maintain compatibility with existing code
def create_structured_assessment_prompt(
    requirement_text: str,
    application_overview: str = "",
    contextual_information: Dict[str, Any] = None,
    additional_info: str = ""
) -> str:
    """
    Create structured prompt for requirement analysis.
    This is the main function to use for building prompts.
    """
    return RequirementAnalysisEngine.build_structured_prompt(
        requirement_text=requirement_text,
        application_overview=application_overview,
        contextual_qa=contextual_information,
        additional_info=additional_info
    )
