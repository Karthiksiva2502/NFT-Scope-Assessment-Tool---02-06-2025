"""
AI Interaction Wrapper for NFT Risk Assessment Tool
Wraps existing AI functions to add comprehensive logging and transparency.
"""

import time
import json
from typing import Dict, List, Optional, Any
from core.ai_interaction_logger import ai_logger, get_user_identifier, get_session_identifier

class AIInteractionWrapper:
    """
    Wrapper class that adds logging to all AI interactions while maintaining 
    backward compatibility with existing functions.
    """
    
    @staticmethod
    def log_and_call_openai(
        interaction_type: str,
        prompt: str,
        api_function,
        model_used: str = None,
        context_data: Dict = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Generic wrapper for OpenAI API calls with comprehensive logging.
        
        Args:
            interaction_type: Type of AI interaction
            prompt: The prompt being sent to AI
            api_function: The actual API function to call
            model_used: AI model being used
            context_data: Additional context information
            **kwargs: Arguments to pass to the API function
            
        Returns:
            Response from AI with logging metadata
        """
        session_id = get_session_identifier()
        user_id = get_user_identifier()
        start_time = time.time()
        
        try:
            # Call the actual API function
            response = api_function(prompt, **kwargs)
            
            # Calculate response time
            response_time_ms = int((time.time() - start_time) * 1000)
            
            # Determine if successful
            success = response is not None and "error" not in response
            error_message = response.get("error") if isinstance(response, dict) else None
            
            # Extract response text for logging
            response_text = json.dumps(response) if isinstance(response, dict) else str(response)
            
            # Log the interaction
            interaction_id = ai_logger.log_interaction(
                session_id=session_id,
                user_identifier=user_id,
                interaction_type=interaction_type,
                prompt=prompt,
                response=response_text,
                model_used=model_used,
                context_data=context_data,
                metadata={
                    'function_name': api_function.__name__,
                    'kwargs': {k: str(v) for k, v in kwargs.items()},
                    'interaction_id': None  # Will be updated after logging
                },
                response_time_ms=response_time_ms,
                success=success,
                error_message=error_message
            )
            
            # Add logging metadata to response
            if isinstance(response, dict):
                response['_ai_interaction_id'] = interaction_id
                response['_logged_at'] = time.time()
            
            return response
            
        except Exception as e:
            # Log failed interaction
            response_time_ms = int((time.time() - start_time) * 1000)
            
            interaction_id = ai_logger.log_interaction(
                session_id=session_id,
                user_identifier=user_id,
                interaction_type=interaction_type,
                prompt=prompt,
                response=None,
                model_used=model_used,
                context_data=context_data,
                metadata={
                    'function_name': api_function.__name__,
                    'kwargs': {k: str(v) for k, v in kwargs.items()},
                    'exception_type': type(e).__name__
                },
                response_time_ms=response_time_ms,
                success=False,
                error_message=str(e)
            )
            
            # Re-raise the exception
            raise e

# Wrapper functions for specific AI interactions

def wrapped_requirement_analysis(requirement_text: str, context: Dict, api_key: str) -> Dict[str, Any]:
    """
    Wrapped version of requirement analysis with proper structured prompt following the format:
    - Application Overview: {Application overview content}
    - Contextual Information: {Q&A about the Application Requirement}  
    - Requirement text/file Upload contents: {All requirement information}
    - Action to AI model: Hey, analyze all the information provided above and generate the proper Scope Assessment Result using it. If you have any additional questions needs to be answered, Ask them in a single statement includes all questions/information to want further.
    """
    
    def _internal_analysis(prompt_text, **kwargs):
        # Implement AI analysis directly to avoid circular import
        import openai
        
        try:
            client = openai.OpenAI(api_key=api_key)
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are an expert requirement analyst specializing in scope assessment and risk analysis. Analyze the provided information and generate a comprehensive scope assessment result. If you need additional information, ask for it in a single comprehensive statement."},
                    {"role": "user", "content": prompt_text}
                ],
                temperature=0.3,
                max_tokens=2000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"Error in analysis: {str(e)}"
    
    # Build the structured prompt following the exact format specified
    structured_prompt = ""
    
    # 1. Application Overview section
    application_overview = context.get('Application Overview', '')
    if application_overview and application_overview.strip():
        structured_prompt += f"Application Overview: {application_overview}\n\n"
    else:
        structured_prompt += "Application Overview: No specific application overview provided.\n\n"
    
    # 2. Contextual Information section (Q&A format)
    structured_prompt += "Contextual Information: "
    
    if context:
        # Convert context to Q&A format
        qa_items = []
        
        # Define question mappings for better Q&A format
        question_mappings = {
            'project_name': 'What is the project name?',
            'change_type': 'What type of change is being implemented?',
            'component_name': 'Which component is being modified?',
            'components_involved': 'What components are involved in this change?',
            'customization_level': 'What is the level of customization required?',
            'channel_impact': 'Which channels will be impacted?',
            'performance_issues': 'Are there any known performance issues?',
            'business_disruption': 'What is the potential business disruption?',
            'contingency_plans': 'What contingency plans are in place?',
            'assessment_coverage': 'What areas should the assessment cover?',
            'ui_volume': 'What is the expected UI volume/load?',
            'ui_response_time': 'What are the UI response time requirements?',
            'backend_volume': 'What is the expected backend volume/load?',
            'backend_response_time': 'What are the backend response time requirements?',
            'batch_volume': 'What is the expected batch processing volume?',
            'batch_response_time': 'What are the batch processing time requirements?',
            'growth_rate': 'What is the expected growth rate?',
            'infrastructure_changes': 'Are there any infrastructure changes planned?',
            'third_party_involvement': 'Are there any third-party systems involved?'
        }
        
        for key, value in context.items():
            if key != 'Application Overview' and value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...', '']:
                # Get the question or create a generic one
                question = question_mappings.get(key, f"What is the {key.replace('_', ' ')}?")
                
                # Format the value
                if isinstance(value, list):
                    answer = ', '.join(str(v) for v in value if v)
                else:
                    answer = str(value)
                
                qa_items.append(f"Q: {question} A: {answer}")
        
        if qa_items:
            structured_prompt += " ".join(qa_items)
        else:
            structured_prompt += "Limited contextual information available."
    else:
        structured_prompt += "No specific contextual information provided."
    
    structured_prompt += "\n\n"
    
    # 3. Requirement text/file Upload contents section
    structured_prompt += f"Requirement text/file Upload contents: {requirement_text}\n\n"
    
    # 4. Action to AI model section
    structured_prompt += "Action to AI model: Hey, analyze all the information provided above and generate the proper Scope Assessment Result using it. If you have any additional questions needs to be answered, Ask them in a single statement includes all questions/information to want further."
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="requirement_analysis",
        prompt=structured_prompt,
        api_function=_internal_analysis,
        model_used="gpt-4o",
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()),
            'has_application_overview': bool(context.get('Application Overview', '').strip()),
            'context_items_count': len([k for k, v in context.items() if v and str(v).strip() and str(v).lower() != 'n/a']),
            'function': 'requirement_analysis',
            'structured_prompt_length': len(structured_prompt)
        }
    )

def wrapped_generate_nft_questions(requirement_text: str, context: Dict, api_key: str) -> Dict[str, Any]:
    """
    Generates targeted questions specifically for NFT assessment.
    This function carefully restricts the questions to only those essential for non-functional testing assessment,
    and only asks questions relevant to the selected testing coverage areas.
    
    Args:
        requirement_text: The requirement text provided by the user
        context: Contextual information from the sidebar
        api_key: OpenAI API key
        
    Returns:
        Dict with questions and metadata
    """
    
    def _internal_generate_nft_questions(prompt_text, **kwargs):
        import openai
        
        try:
            client = openai.OpenAI(api_key=api_key)
            # Use a specific system prompt to restrict questioning to NFT-relevant topics only
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": """You are an expert Non-Functional Testing (NFT) assessment assistant. 
                     Your role is STRICTLY LIMITED to gathering ONLY the essential missing information required for NFT assessment.
                     DO NOT ask general requirement clarifications or functional testing questions.
                     ONLY ask questions about the specific testing types the user has selected.
                     LIMIT yourself to a MAXIMUM of 5 TARGETED questions.
                     Format your questions in a numbered list with ONLY the specific questions.
                     If there's enough information to proceed with NFT assessment, respond with: "SUFFICIENT_INFO_FOR_NFT_ASSESSMENT"."""},
                    {"role": "user", "content": prompt_text}
                ],
                temperature=0.3,
                max_tokens=2000
            )
            
            return {
                "questions": response.choices[0].message.content,
                "model": "gpt-4o"
            }
            
        except Exception as e:
            return {"error": f"Error generating NFT questions: {str(e)}"}
    
    # Create a focused prompt specifically for NFT question generation
    nft_question_prompt = f"""
    Analyze the following requirement text and context to determine if any SPECIFIC and ESSENTIAL information is missing for Non-Functional Testing assessment.
    
    REQUIREMENT TEXT:
    ```
    {requirement_text}
    ```
    
    CONTEXT INFORMATION:
    """
    
    # Extract selected testing coverage from context
    selected_testing = context.get('assessment_coverage', [])
    
    # Add context information
    if context:
        important_keys = [
            'project_name', 'change_type', 'component_name', 'components_involved', 
            'business_critical_volume', 'response_time_sla', 'growth_rate',
            'customization_level', 'channel_impact', 'performance_issues', 
            'business_disruption', 'contingency_plans', 'assessment_coverage'
        ]
        
        for key in important_keys:
            value = context.get(key, '')
            if value and str(value).strip():
                # Format lists properly
                if isinstance(value, list):
                    value = ', '.join(str(v) for v in value if v)
                nft_question_prompt += f"- {key.replace('_', ' ').title()}: {value}\n"
    else:
        nft_question_prompt += "No additional context provided.\n"
    
    # Specifically highlight the selected testing types
    nft_question_prompt += f"\nSELECTED TESTING COVERAGE: {', '.join(selected_testing) if selected_testing else 'None specified'}\n"
    
    # Add special instructions and criteria to guide the AI in producing focused NFT questions
    nft_question_prompt += """
    INSTRUCTIONS:
    1. ONLY ask questions that are STRICTLY NECESSARY for Non-Functional Testing (NFT) assessment.
    2. DO NOT ask generic requirements clarifications or questions about functional aspects.
    3. Limit questions to a MAXIMUM of 5, focusing ONLY on critical missing NFT information.
    4. ONLY ask questions relevant to the selected testing coverage areas. DO NOT ask questions about testing types that weren't selected.
    """
    
    # Add specific instructions based on selected testing types
    if selected_testing:
        nft_question_prompt += "\nBased on the selected testing coverage, ONLY ask questions about:\n"
        
        if any("Performance" in test_type for test_type in selected_testing):
            nft_question_prompt += "- Performance requirements (response time, throughput, resource utilization)\n"
            nft_question_prompt += "- Scalability factors (user load, data volume, growth patterns)\n"
        
        if any("Security" in test_type for test_type in selected_testing):
            nft_question_prompt += "- Security requirements (authentication, authorization, data protection)\n"
        
        if any("Accessibility" in test_type for test_type in selected_testing):
            nft_question_prompt += "- Accessibility requirements (compliance standards, target audience)\n"
        
        if any("OAT" in test_type for test_type in selected_testing):
            nft_question_prompt += "- Operational acceptance requirements (monitoring, maintenance, backup/recovery)\n"
        
        if any("Device" in test_type for test_type in selected_testing):
            nft_question_prompt += "- Device compatibility requirements (supported devices, browsers, resolutions)\n"
        
        if any("All Non-Functional" in test_type for test_type in selected_testing):
            nft_question_prompt += "- All relevant non-functional aspects (performance, security, reliability, etc.)\n"
    else:
        # Fallback if no specific testing types are selected
        nft_question_prompt += """
        Ask about these NFT aspects if the information is missing AND essential:
        - Performance requirements (response time, throughput, resource utilization)
        - Scalability factors (user load, data volume, growth patterns)
        - Reliability requirements (availability, failover requirements)
        - Security requirements (if not already specified)
        - Compliance requirements (if applicable and not specified)
        - Technical architecture constraints affecting non-functional aspects
        """
    
    nft_question_prompt += """    
    If sufficient information already exists for NFT assessment, respond with: "SUFFICIENT_INFO_FOR_NFT_ASSESSMENT"
    
    OUTPUT FORMAT:
    Provide ONLY the numbered list of questions, or "SUFFICIENT_INFO_FOR_NFT_ASSESSMENT" if no questions are needed.
    """
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="nft_question_generation",
        prompt=nft_question_prompt,
        api_function=_internal_generate_nft_questions,
        model_used="gpt-4o",
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()) if context else [],
            'selected_testing_coverage': selected_testing,
            'function': 'wrapped_generate_nft_questions'
        }
    )

def wrapped_generate_ai_questions(requirement_text: str, context: Dict, api_key: str) -> str:
    """
    AI chat assistant features have been removed as requested.
    Returns a placeholder message instead of generating questions.
    """
    
    def _internal_generate_questions(prompt_text, **kwargs):
        # Return empty response to disable question generation
        # AI chat assistant features have been removed as requested
        return "AI chat assistant features have been removed."
    
    prompt_for_logging = "AI chat assistant features have been removed as requested."
    
    # Get empty list as default for selected coverage
    selected_coverage = []
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="question_generation",
        prompt=prompt_for_logging,
        api_function=_internal_generate_questions,
        model_used="gpt-4o",
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()),
            'has_application_overview': bool(context.get('Application Overview', '').strip()),
            'selected_testing_coverage': selected_coverage,
            'function': 'generate_ai_questions'
        }
    )

def wrapped_get_gpt_assessment(prompt: str, api_key: str, model: str = "gpt-4o", user_selected_testing_types: Optional[List] = None) -> Dict[str, Any]:
    """Wrapped version of get_gpt_assessment with logging."""
    
    def _internal_get_assessment(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from core import gpt_logic
        return gpt_logic.enhanced_get_gpt_assessment(prompt, api_key, model, user_selected_testing_types)
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="risk_assessment",
        prompt=prompt,
        api_function=_internal_get_assessment,
        model_used=model,
        context_data={
            'prompt_length': len(prompt),
            'function': 'get_gpt_assessment',
            'user_selected_testing_types': user_selected_testing_types
        }
    )

def wrapped_analyze_requirement_quality(requirement_text: str, context: Dict, api_key: str, model: str = "gpt-4o") -> Dict[str, Any]:
    """Wrapped version of analyze_requirement_quality with logging."""
    
    def _internal_analyze_quality(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from core import req_quality_checker
        return req_quality_checker.analyze_requirement_quality(requirement_text, context, api_key, model)
    
    prompt_for_logging = f"""
    Requirement Text: {requirement_text}
    Context: {json.dumps(context, default=str)}
    """
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="quality_analysis",
        prompt=prompt_for_logging,
        api_function=_internal_analyze_quality,
        model_used=model,
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()),
            'function': 'analyze_requirement_quality'
        }
    )

def wrapped_generate_embedding(text: str, api_key: str) -> List[float]:
    """Wrapped version of generate_embedding with logging."""
    
    def _internal_generate_embedding(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from core import chroma_logic
        return chroma_logic.generate_embedding(text, api_key)
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="embedding_generation",
        prompt=text,
        api_function=_internal_generate_embedding,
        model_used="text-embedding-3-small",
        context_data={
            'text_length': len(text),
            'function': 'generate_embedding'
        }
    )

def get_ai_transparency_report(session_id: str = None) -> Dict[str, Any]:
    """
    Generate a transparency report showing what was sent to AI and what was received.
    This helps users understand exactly what information was shared with AI.
    """
    if session_id is None:
        session_id = get_session_identifier()
    
    return ai_logger.validate_interaction_transparency(session_id)

def get_current_session_interactions() -> List[Dict]:
    """Get all AI interactions for the current session."""
    session_id = get_session_identifier()
    interactions = ai_logger.get_session_interactions(session_id)
    print(f"Current session ID: {session_id}")
    print(f"Retrieved {len(interactions)} interactions from the database")
    
    # Return only interactions for the current session
    # No fallback to recent interactions from other sessions
    return interactions

def export_ai_interaction_logs(output_format: str = "json", filters: Optional[Dict] = None) -> str:
    """Export AI interaction logs for audit purposes."""
    return ai_logger.export_interactions(output_format, filters)

def get_ai_interaction_summary(hours: int = 24) -> Dict[str, Any]:
    """Get summary statistics of AI interactions."""
    return ai_logger.get_interaction_summary(hours)
