"""
Intelligent Assessment Logic for NFT Risk Assessment Tool
Implements smart decision making for direct assessment vs question generation.
"""

import json
from typing import Dict, List, Optional, Any
from .ai_interaction_wrapper import wrapped_get_gpt_assessment

def categorize_testing_based_on_coverage(assessment_coverage: List[str]) -> tuple[List[str], List[str]]:
    """
    Categorizes testing types into mandatory and recommended based on user's Assessment Coverage selection.
    
    Args:
        assessment_coverage: List of selected assessment coverage options from the sidebar
        
    Returns:
        tuple: (mandatory_testing_types, recommended_testing_types)
    """
    # Define mapping from Assessment Coverage options to testing types
    coverage_to_testing_mapping = {
        'Performance Testing (Load, Stress, etc.)': 'Performance Testing',
        'Device Level Testing': 'Device Level Testing',
        'OAT': 'Operational Acceptance Testing',
        'Accessibility': 'Accessibility Testing',
        'Security': 'Security Testing',
        'All Non-Functional Testing': 'All Non-Functional Testing',
        # Add explicit mapping for Single-user Performance Testing 
        'Single-user Performance Testing': 'Single-user Performance Testing'
    }
    
    # Standard testing categories
    all_testing_categories = [
        'Performance Testing',
        'Operational Acceptance Testing', 
        'Single-user Performance Testing',
        'Security Testing',
        'Scalability Testing',
        'Reliability Testing',
        'Usability Testing',
        'Compatibility Testing',
        'Data Integrity Testing',
        'Integration Testing',
        'Accessibility Testing',
        'Compliance Testing',
        'Regression Testing',
        'Device Level Testing'
    ]
    # Convert selected coverage to testing types
    selected_testing_types = []
    for coverage in assessment_coverage:
        if coverage in coverage_to_testing_mapping:
            if coverage == 'All Non-Functional Testing':
                # If "All Non-Functional Testing" is selected, include all testing types as mandatory
                selected_testing_types = all_testing_categories.copy()
                break
            else:
                selected_testing_types.append(coverage_to_testing_mapping[coverage])
    
    # Never use default categories if assessment_coverage is provided, even if empty
    # This ensures only user-selected categories are mandatory
    if assessment_coverage is None or (len(assessment_coverage) == 0 and not selected_testing_types):
        mandatory_testing = ['Performance Testing', 'Operational Acceptance Testing']
        recommended_testing = [cat for cat in all_testing_categories if cat not in mandatory_testing]
    else:
        # User selections become mandatory
        mandatory_testing = selected_testing_types.copy()
        
        # All other testing types become recommended
        recommended_testing = [cat for cat in all_testing_categories if cat not in mandatory_testing]
    
    return mandatory_testing, recommended_testing

class IntelligentAssessmentDecision:
    """
    Intelligent system to decide whether AI can provide direct assessment 
    or needs to ask enhancement questions.
    """
    
    @staticmethod
    def analyze_information_completeness(requirement_text: str, context: Dict, application_overview: str = "") -> Dict[str, Any]:
        """
        Analyze the completeness of provided information to determine if direct assessment is possible.
        
        Args:
            requirement_text: The requirement text provided
            context: Contextual information from sidebar
            application_overview: Application overview text
            
        Returns:
            Dict containing analysis results and decision
        """
        
        # Initialize scoring system
        completeness_score = 0
        max_possible_score = 100
        missing_areas = []
        available_information = []
        
        # 1. Requirement Text Analysis (30 points max)
        req_analysis = IntelligentAssessmentDecision._analyze_requirement_text(requirement_text)
        completeness_score += req_analysis['score']
        if req_analysis['score'] < 20:
            missing_areas.extend(req_analysis['missing'])
        else:
            available_information.extend(req_analysis['available'])
        
        # 2. Application Overview Analysis (20 points max)
        app_analysis = IntelligentAssessmentDecision._analyze_application_overview(application_overview)
        completeness_score += app_analysis['score']
        if app_analysis['score'] < 15:
            missing_areas.extend(app_analysis['missing'])
        else:
            available_information.extend(app_analysis['available'])
        
        # 3. Contextual Information Analysis (50 points max)
        context_analysis = IntelligentAssessmentDecision._analyze_contextual_information(context)
        completeness_score += context_analysis['score']
        if context_analysis['score'] < 35:
            missing_areas.extend(context_analysis['missing'])
        else:
            available_information.extend(context_analysis['available'])        # Calculate final percentage
        completeness_percentage = (completeness_score / max_possible_score) * 100
        # Decision Logic
        can_proceed_directly = completeness_percentage >= 90  # Updated from 85% to 90% to be even more strict
        
        return {
            'completeness_score': completeness_score,
            'completeness_percentage': round(completeness_percentage, 1),
            'can_proceed_directly': can_proceed_directly,
            'missing_areas': missing_areas,
            'available_information': available_information,
            'decision_reason': IntelligentAssessmentDecision._get_decision_reason(
                completeness_percentage, missing_areas, can_proceed_directly
            ),
            'analysis_details': {
                'requirement_analysis': req_analysis,
                'application_analysis': app_analysis,
                'context_analysis': context_analysis
            }
        }
    
    @staticmethod
    def _analyze_requirement_text(requirement_text: str) -> Dict[str, Any]:
        """Analyze requirement text for completeness."""
        score = 0
        missing = []
        available = []
        
        if not requirement_text or len(requirement_text.strip()) < 10:
            missing.append("Detailed requirement description")
            return {'score': 0, 'missing': missing, 'available': available}
        
        # Word count analysis - even more strict requirements
        word_count = len(requirement_text.split())
        if word_count >= 75:  # Significantly increased minimum for comprehensive
            score += 10
            available.append("Comprehensive requirement description")
        elif word_count >= 50:  # Increased minimum for adequate
            score += 7
            available.append("Adequate requirement description")
        elif word_count >= 30:  # Increased minimum for basic
            score += 3
            available.append("Basic requirement description")
        else:
            missing.append("More detailed requirement description (minimum 15-20 words needed)")
        
        # NFR keyword analysis
        nfr_keywords = {
            'performance': ['performance', 'speed', 'response time', 'fast', 'slow', 'latency', 'throughput', 'load'],
            'security': ['security', 'authentication', 'authorization', 'encryption', 'secure', 'privacy'],
            'scalability': ['scalability', 'scale', 'users', 'concurrent', 'volume', 'capacity'],
            'availability': ['availability', 'uptime', 'downtime', '24/7', 'reliable', 'fault'],
            'integration': ['integration', 'api', 'interface', 'third-party', 'external', 'service'],
            'compliance': ['compliance', 'regulation', 'standard', 'audit', 'governance']
        }
        
        req_lower = requirement_text.lower()
        found_categories = 0
        
        for category, keywords in nfr_keywords.items():
            if any(keyword in req_lower for keyword in keywords):
                found_categories += 1
                available.append(f"{category.title()} requirements mentioned")
        
        # Score based on NFR coverage - more strict requirements
        if found_categories >= 4:  # Require more NFR categories
            score += 15
        elif found_categories >= 3:
            score += 10
        elif found_categories >= 2:
            score += 5
        else:
            missing.append("Non-functional requirement categories (performance, security, etc.)")
        
        # Technical detail analysis
        technical_terms = ['system', 'application', 'database', 'server', 'network', 'infrastructure', 
                         'architecture', 'component', 'module', 'service', 'platform']
        
        if any(term in req_lower for term in technical_terms):
            score += 5
            available.append("Technical implementation details")
        else:
            missing.append("Technical implementation details")
        
        return {'score': min(score, 30), 'missing': missing, 'available': available}
    
    @staticmethod
    def _analyze_application_overview(application_overview: str) -> Dict[str, Any]:
        """Analyze application overview for completeness."""
        score = 0
        missing = []
        available = []
        
        if not application_overview or len(application_overview.strip()) < 20:
            missing.extend([
                "Application purpose and business context",
                "System architecture information", 
                "User base and usage patterns"
            ])
            return {'score': 0, 'missing': missing, 'available': available}
        
        overview_lower = application_overview.lower()
        
        # Business context
        business_keywords = ['business', 'customer', 'user', 'client', 'market', 'revenue', 'sales']
        if any(keyword in overview_lower for keyword in business_keywords):
            score += 7
            available.append("Business context and purpose")
        else:
            missing.append("Business context and purpose")
        
        # Technical architecture
        arch_keywords = ['architecture', 'microservice', 'database', 'server', 'cloud', 'platform', 'framework']
        if any(keyword in overview_lower for keyword in arch_keywords):
            score += 6
            available.append("System architecture information")
        else:
            missing.append("System architecture information")
        
        # User base/scale
        scale_keywords = ['users', 'daily', 'monthly', 'concurrent', 'volume', 'traffic', 'load']
        if any(keyword in overview_lower for keyword in scale_keywords):
            score += 7
            available.append("User base and scale information")
        else:
            missing.append("User base and scale information")
        
        return {'score': min(score, 20), 'missing': missing, 'available': available}
    
    @staticmethod
    def _analyze_contextual_information(context: Dict) -> Dict[str, Any]:
        """Analyze contextual information from sidebar for completeness."""
        score = 0
        missing = []
        available = []
        
        # Essential context fields with their importance weights
        essential_fields = {
            'project_name': {'weight': 5, 'label': 'Project identification'},
            'change_type': {'weight': 5, 'label': 'Change type classification'},
            'component_name': {'weight': 5, 'label': 'Component/application name'},
            'components_involved': {'weight': 8, 'label': 'Components involved details'},
            'customization_level': {'weight': 6, 'label': 'Customization complexity level'},
            'channel_impact': {'weight': 6, 'label': 'Channel/component impact assessment'},
            'performance_issues': {'weight': 8, 'label': 'Performance/scalability considerations'},
            'business_disruption': {'weight': 7, 'label': 'Business disruption impact'},
            'contingency_plans': {'weight': 5, 'label': 'Contingency planning details'},
            'assessment_coverage': {'weight': 5, 'label': 'Testing coverage requirements'}
        }
        for field, config in essential_fields.items():
            value = context.get(field, '')
            if value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...']:
                score += config['weight']
                available.append(config['label'])
            else:
                missing.append(config['label'])
        return {'score': min(score, 50), 'missing': missing, 'available': available}
    
    @staticmethod
    def _get_decision_reason(completeness_percentage: float, missing_areas: List[str], can_proceed: bool) -> str:
        """Generate human-readable decision reasoning."""
        if can_proceed:
            if completeness_percentage >= 95:
                return "Assessment can proceed directly with high confidence. Information completeness is excellent."
            else:  # Between 90% and 95%
                return "Assessment can proceed directly with acceptable confidence. Information meets minimum requirements."
        else:
            if completeness_percentage < 50:
                return f"Critical NFT-related information is missing: {', '.join(missing_areas[:3])}. Further information gathering is required."
            elif completeness_percentage < 70:
                return f"Assessment requires additional NFT-related information. Key missing areas: {', '.join(missing_areas[:3])}."
            else:  # Between 70% and 90%
                return "Information is incomplete. Additional NFT-specific details are required before proceeding with assessment."
    
    @staticmethod
    def create_comprehensive_prompt(requirement_text: str, context: Dict, application_overview: str = "", 
                                  ai_gathered_info: str = "", similar_requirements: Optional[List] = None) -> str:
        """
        Create a comprehensive prompt that includes ALL available information.
        
        Args:
            requirement_text: The requirement text
            context: Contextual information from sidebar
            application_overview: Application overview text
            ai_gathered_info: Information gathered through AI assistant
            similar_requirements: Similar historical requirements
            
        Returns:
            Comprehensive prompt string
        """
        
        # Get assessment coverage from context and categorize testing types
        assessment_coverage = context.get('assessment_coverage', [])
        mandatory_testing_types, recommended_testing_types = categorize_testing_based_on_coverage(assessment_coverage)
        
        prompt = """
You are an expert software risk analyst specializing in non-functional requirements assessment. Your task is to provide a comprehensive, accurate, and actionable risk assessment based on ALL the provided information.

**CRITICAL INSTRUCTIONS:**
- Analyze ALL provided information sources comprehensively
- Provide detailed, specific analysis based on the actual requirement content and context
- Ensure all testing recommendations are practical and implementable
- Consider real-world constraints and industry best practices
- Be specific about tools, methods, and approaches
- Focus on non-functional risks that could impact system reliability, performance, security, and user experience

"""

        # Add requirement text
        prompt += f"""
**REQUIREMENT TO ANALYZE:**
```
{requirement_text}
```

"""

        # Add application overview if available
        if application_overview and application_overview.strip():
            prompt += f"""
**APPLICATION OVERVIEW:**
{application_overview}

This application background provides critical context for assessing the requirement's risk level and testing needs.

"""

        # Add contextual information from sidebar
        if context:
            prompt += "\n**CONTEXTUAL INFORMATION:**\n"
            
            # Organize context into logical groups
            context_groups = {
                'Project Information': ['project_name', 'change_type', 'application_component_name'],
                'Technical Details': ['components_involved', 'customization_level', 'channel_impact'],
                'Risk Assessment': ['performance_issues', 'business_disruption', 'contingency_plans'],
                'Testing Requirements': ['assessment_coverage'],
                'Performance Specifications': ['business_critical_volume', 'response_time_sla', 'growth_rate'],
                'Growth and Dependencies': ['infrastructure_changes', 'third_party_involvement']
            }
            
            for group_name, fields in context_groups.items():
                group_content = []
                for field in fields:
                    value = context.get(field, '')
                    if value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...']:
                        # Convert field names to readable labels
                        readable_field = field.replace('_', ' ').title()
                        if isinstance(value, list):
                            value = ', '.join(str(v) for v in value if v)
                        group_content.append(f"- **{readable_field}**: {value}")
                
                if group_content:
                    prompt += f"\n**{group_name}:**\n" + "\n".join(group_content) + "\n"
            
            # Add any other context not in predefined groups
            other_context = {k: v for k, v in context.items() 
                           if k not in [field for fields in context_groups.values() for field in fields]}
            
            if other_context:
                prompt += "\n**Additional Context:**\n"
                for key, value in other_context.items():
                    if value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...']:
                        readable_key = key.replace('_', ' ').title()
                        prompt += f"- **{readable_key}**: {value}\n"

        # Add AI gathered information if available
        if ai_gathered_info and ai_gathered_info.strip():
            prompt += f"""
**AI ASSISTANT GATHERED INFORMATION:**
{ai_gathered_info}

This information was collected through targeted questioning to fill knowledge gaps for comprehensive assessment.

"""

        # Add similar requirements analysis if available
        if similar_requirements:
            prompt += "\n**HISTORICAL ANALYSIS (Similar Requirements):**\n"
            for i, req in enumerate(similar_requirements[:3], 1):  # Limit to top 3
                past_meta = req.get('metadata', {})
                prompt += f"\n{i}. **Previous Assessment:**\n"
                prompt += f"   - Requirement: {past_meta.get('requirement_text', 'N/A')[:100]}...\n"
                prompt += f"   - Risk Level: {past_meta.get('risk', 'N/A')}\n"
                prompt += f"   - Key Reasoning: {past_meta.get('reasoning', 'N/A')[:200]}...\n"
                prompt += f"   - Outcome: {past_meta.get('approved', 'Unknown')}\n"
            
            prompt += "\n**Learning from History:** Use these past assessments to inform your analysis, but ensure your assessment is tailored to the current requirement's unique characteristics.\n"

        # Add assessment framework with dynamic testing categorization
        prompt += f"""

**ASSESSMENT FRAMEWORK:**

### **Risk Classification:**
Determine risk level (High/Medium/Low) based on:
- **Technical Complexity**: Integration points, performance requirements, scalability needs
- **Business Impact**: Criticality to operations, user experience implications, financial impact  
- **Implementation Challenges**: Resource requirements, timeline constraints, dependencies
- **Operational Risk**: Monitoring needs, maintenance complexity, failure scenarios

### **Assessment Coverage Selection:**
Based on the user's assessment coverage selection: {assessment_coverage if assessment_coverage else 'Default scope'}

**MANDATORY TESTING TYPES (Selected by User):**
{', '.join(mandatory_testing_types)}

**RECOMMENDED TESTING TYPES (Additional Coverage):**
{', '.join(recommended_testing_types[:8])}  {'...' if len(recommended_testing_types) > 8 else ''}

### **Mandatory Testing Analysis:**
For each mandatory testing type listed above, provide:
- **Specific rationale** tied to the requirement and available context
- **Detailed methodology** including tools and approaches
- **Success criteria** and measurable outcomes
- **Risk mitigation** achieved through the testing

### **Component-Specific Analysis:**
Identify key system components and provide:
- **Component-specific risks** and vulnerabilities
- **Targeted testing strategies** for each component
- **Integration testing** requirements between components
- **Performance benchmarks** and acceptance criteria



**RESPONSE FORMAT:**
Provide your response in the following JSON structure. Ensure all sections are comprehensive and actionable:

```json
{{
  "risk": "High|Medium|Low",
  "reasoning": "Comprehensive analysis of why this risk level was assigned, including technical, business, and operational factors. Minimum 200 characters with specific references to the requirement and provided context.",
  "confidence_score": 0.85,
  "assessment_metadata": {{
    "context_quality": "high|medium|low",
    "analysis_depth": "comprehensive|standard|basic",
    "information_sources_used": ["requirement_text", "application_overview", "contextual_information", "ai_gathered_info"],
    "user_selected_coverage": {json.dumps(assessment_coverage) if assessment_coverage else "[]"},
    "mandatory_testing_count": {len(mandatory_testing_types)},
    "recommended_testing_count": {len(recommended_testing_types)}
  }},
  "mandatory_testing": {{
"""

        # Dynamically generate mandatory testing structure
        for i, testing_type in enumerate(mandatory_testing_types):
            test_type_lower = testing_type.lower()
            prompt += f"""    "{testing_type}": {{
      "rationale": "Specific rationale for {testing_type} based on requirement and context",
      "methodology": "Detailed {test_type_lower} approach with tools and techniques",
      "success_criteria": "Measurable acceptance criteria for {test_type_lower}",
      "tools": ["Tool1", "Tool2", "Tool3"],
      "timeline": "Estimated duration for {test_type_lower}",
      "risk_coverage": "Specific technical risks addressed by {test_type_lower}"
    }}"""
            if i < len(mandatory_testing_types) - 1:
                prompt += ","
            prompt += "\n"

        prompt += """  }},
  "recommended_testing": {{
"""

        # Dynamically generate recommended testing structure (limit to first 5 for prompt brevity)
        for i, testing_type in enumerate(recommended_testing_types[:5]):
            test_type_lower = testing_type.lower()
            prompt += f"""    "{testing_type}": {{
      "priority": "Critical|Important|Nice-to-have",
      "approach": "Specific {test_type_lower} methodology",
      "tools": ["Tool1", "Tool2"],
      "deliverables": "Expected outputs and reports",
      "risk_mitigation": "Specific risks addressed by {test_type_lower}"
    }}"""
            if i < min(len(recommended_testing_types), 5) - 1:
                prompt += ","
            prompt += "\n"

        prompt += """  }},
  "component_analysis": {{
    "ComponentName": {{
      "risks": ["Specific risk 1", "Specific risk 2"],
      "testing_strategy": "Component-specific testing approach",
      "success_criteria": "Measurable acceptance criteria"
    }}
  }},
  "recommendations": [
    "Specific, actionable recommendation 1",
    "Specific, actionable recommendation 2"
  ]
}}
```

**QUALITY REQUIREMENTS:**
- All testing descriptions must be at least 50 characters and include specific tools/methods
- Risk reasoning must reference specific aspects of the requirement and provided context
- Component analysis must include at least 2 components unless requirement is very simple
- All recommendations must be actionable and measurable
- Leverage ALL provided information sources for comprehensive analysis
- MANDATORY TESTING must focus ONLY on the user-selected assessment coverage areas
- RECOMMENDED TESTING should include additional valuable testing beyond user selection

**CRITICAL INSTRUCTION:**
The user has specifically selected these assessment coverage areas: {assessment_coverage}
These selections should be treated as MANDATORY TESTING in your assessment. All other testing types should be categorized as RECOMMENDED TESTING.

Provide a thorough, accurate assessment that serves as a reliable foundation for decision-making based on ALL available information.
"""

        # Detect technology components in requirement text
        detected_components = IntelligentAssessmentDecision.detect_technology_components(requirement_text)
        
        # Add detected technology components if found
        if detected_components:
            prompt += "\n**DETECTED TECHNOLOGY COMPONENTS:**\n"
            for category, technologies in detected_components.items():
                prompt += f"- **{category}**: {', '.join(technologies)}\n"
            
            prompt += "\nThese technology components were automatically detected in the requirement and should be specifically addressed in your assessment.\n"

        return prompt
    
    @staticmethod
    def detect_technology_components(text: str) -> Dict[str, List[str]]:
        """
        Detects specific technology components mentioned in the requirement text.
        
        Args:
            text: The requirement text to analyze
            
        Returns:
            Dictionary with component categories and detected technologies
        """
        text_lower = text.lower()
        
        # Define technology components to detect
        component_categories = {
            'Cloud Platforms': {
                'Azure': ['azure', 'microsoft azure', 'azure cloud', 'azure ad', 'azure active directory'],
                'AWS': ['aws', 'amazon web services', 'amazon cloud', 'ec2', 's3', 'lambda'],
                'Google Cloud': ['google cloud', 'gcp', 'google cloud platform']
            },
            'API Management': {
                'Azure API Management': ['azure api management', 'apim', 'api gateway', 'api management'],
                'AWS API Gateway': ['aws api gateway', 'amazon api gateway'],
                'Kong': ['kong', 'kong gateway']
            },
            'CRM Systems': {
                'Dynamics 365': ['dynamics', 'dynamics 365', 'dynamics crm', 'microsoft dynamics'],
                'Salesforce': ['salesforce', 'salesforce crm'],
                'SAP': ['sap', 'sap crm', 'sap db']
            },
            'Databases': {
                'SQL Server': ['sql server', 'mssql', 'microsoft sql'],
                'Oracle': ['oracle', 'oracle db', 'oracle database'],
                'MongoDB': ['mongodb', 'mongo'],
                'CosmosDB': ['cosmosdb', 'cosmos db', 'azure cosmos']
            },
            'Mobile Technologies': {
                'Android': ['android'],
                'iOS': ['ios', 'iphone', 'ipad'],
                'React Native': ['react native'],
                'Flutter': ['flutter']
            },
            'Integration Services': {
                'Azure Logic Apps': ['logic apps', 'azure logic'],
                'Azure Service Bus': ['service bus'],
                'MuleSoft': ['mulesoft'],
                'Azure Event Hub': ['event hub', 'eventhub']
            }
        }
        
        # Detect components
        detected_components = {}
        
        for category, technologies in component_categories.items():
            category_matches = []
            
            for tech_name, keywords in technologies.items():
                if any(keyword in text_lower for keyword in keywords):
                    category_matches.append(tech_name)
            
            if category_matches:
                detected_components[category] = category_matches
        
        return detected_components
