"""
AI Interaction Wrapper for NFT Risk Assessment Tool
Wraps existing AI functions to add comprehensive logging and transparency.
"""

import time
import json
from typing import Dict, List, Optional, Any
from .ai_interaction_logger import ai_logger, get_user_identifier, get_session_identifier

class AIInteractionWrapper:
    """
    Wrapper class that adds logging to all AI interactions while maintaining 
    backward compatibility with existing functions.
    """
    
    @staticmethod
    def log_and_call_openai(
        interaction_type: str,
        prompt: str,
        api_function,
        model_used: str = None,
        context_data: Dict = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Generic wrapper for OpenAI API calls with comprehensive logging.
        
        Args:
            interaction_type: Type of AI interaction
            prompt: The prompt being sent to AI
            api_function: The actual API function to call
            model_used: AI model being used
            context_data: Additional context information
            **kwargs: Arguments to pass to the API function
            
        Returns:
            Response from AI with logging metadata
        """
        session_id = get_session_identifier()
        user_id = get_user_identifier()
        start_time = time.time()
        
        try:
            # Call the actual API function
            response = api_function(prompt, **kwargs)
            
            # Calculate response time
            response_time_ms = int((time.time() - start_time) * 1000)
            
            # Determine if successful
            success = response is not None and "error" not in response
            error_message = response.get("error") if isinstance(response, dict) else None
            
            # Extract response text for logging
            response_text = json.dumps(response) if isinstance(response, dict) else str(response)
            
            # Log the interaction
            interaction_id = ai_logger.log_interaction(
                session_id=session_id,
                user_identifier=user_id,
                interaction_type=interaction_type,
                prompt=prompt,
                response=response_text,
                model_used=model_used,
                context_data=context_data,
                metadata={
                    'function_name': api_function.__name__,
                    'kwargs': {k: str(v) for k, v in kwargs.items()},
                    'interaction_id': None  # Will be updated after logging
                },
                response_time_ms=response_time_ms,
                success=success,
                error_message=error_message
            )
            
            # Add logging metadata to response
            if isinstance(response, dict):
                response['_ai_interaction_id'] = interaction_id
                response['_logged_at'] = time.time()
            
            return response
            
        except Exception as e:
            # Log failed interaction
            response_time_ms = int((time.time() - start_time) * 1000)
            
            interaction_id = ai_logger.log_interaction(
                session_id=session_id,
                user_identifier=user_id,
                interaction_type=interaction_type,
                prompt=prompt,
                response=None,
                model_used=model_used,
                context_data=context_data,
                metadata={
                    'function_name': api_function.__name__,
                    'kwargs': {k: str(v) for k, v in kwargs.items()},
                    'exception_type': type(e).__name__
                },
                response_time_ms=response_time_ms,
                success=False,
                error_message=str(e)
            )
            
            # Re-raise the exception
            raise e

# Wrapper functions for specific AI interactions

def wrapped_requirement_analysis(requirement_text: str, context: Dict, api_key: str) -> Dict[str, Any]:
    """
    Wrapped version of requirement analysis with proper structured prompt following the format:
    - Application Overview: {Application overview content}
    - Contextual Information: {Q&A about the Application Requirement}  
    - Requirement text/file Upload contents: {All requirement information}
    - Action to AI model: Hey, analyze all the information provided above and generate the proper Scope Assessment Result using it. If you have any additional questions needs to be answered, Ask them in a single statement includes all questions/information to want further.
    """
    
    def _internal_analysis(prompt_text, **kwargs):
        # Implement AI analysis directly to avoid circular import
        import openai
        
        try:
            client = openai.OpenAI(api_key=api_key)
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You are an expert requirement analyst specializing in scope assessment and risk analysis for Non-Functional Testing (NFT). Focus on performance testing, security testing, and other NFT aspects. Analyze the provided information and generate a comprehensive scope assessment result that specifically addresses NFT requirements and risks. Your response should be formatted in a clean, professional manner without any code formatting artifacts like quotes, backticks, or markdown syntax that might interfere with display. Structure your response with these exact sections:\n\n1. Risk Level: (High/Medium/Low)\n2. Reasoning: (clear explanation)\n3. Mandatory NFT Requirements: (organized by testing type with technical details)\n4. Recommended NFT Strategy: (strategic recommendations)\n5. Component-Specific Analysis: (per-component testing needs)"},
                    {"role": "user", "content": prompt_text}
                ],
                temperature=0.2,  # Lower temperature for more focused and deterministic responses
                max_tokens=3000   # Increased token limit for more detailed responses
            )
            
            # Clean the response text to remove any markdown or formatting artifacts
            response_text = response.choices[0].message.content
            
            # Enhanced cleaning to ensure proper UI integration
            # Remove markdown artifacts
            response_text = response_text.replace("```", "").replace("`", "").replace("**", "").replace("*", "")
            
            # Fix inconsistent quotes
            response_text = response_text.replace('"', '"').replace('"', '"')
            response_text = response_text.replace("'", "'").replace("'", "'")
            
            # Ensure proper section formatting for UI display
            # This helps the app.py parse and structure the content correctly
            if "Risk Level:" in response_text and not response_text.startswith("Risk Level:"):
                # Extract the risk level to ensure it's one of the expected values
                import re
                risk_match = re.search(r"Risk Level:\s*(High|Medium|Low)", response_text, re.IGNORECASE)
                reasoning_match = re.search(r"Reasoning:(.*?)(?:Mandatory NFT Requirements:|$)", response_text, re.DOTALL)
                mandatory_match = re.search(r"Mandatory NFT Requirements:(.*?)(?:Recommended NFT Strategy:|$)", response_text, re.DOTALL)
                recommended_match = re.search(r"Recommended NFT Strategy:(.*?)(?:Component-Specific Analysis:|$)", response_text, re.DOTALL)
                component_match = re.search(r"Component-Specific Analysis:(.*?)$", response_text, re.DOTALL)
                
                # Construct a structured response that can be easily parsed
                structured_response = {
                    "risk": risk_match.group(1) if risk_match else "Medium",
                    "reasoning": reasoning_match.group(1).strip() if reasoning_match else "Analysis incomplete",
                    "mandatory_testing": mandatory_match.group(1).strip() if mandatory_match else "No mandatory testing identified",
                    "recommended_testing": recommended_match.group(1).strip() if recommended_match else "No recommendations provided",
                    "component_analysis": component_match.group(1).strip() if component_match else "No component analysis provided"
                }
                
                # Return the structured dictionary for easier UI integration
                return structured_response
            
            # If we can't parse properly, return the cleaned text
            return response_text
            
        except Exception as e:
            return {"error": f"Error in analysis: {str(e)}"}
    
    # Build the structured prompt following the exact format specified
    structured_prompt = create_comprehensive_prompt(requirement_text, context)
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="requirement_analysis",
        prompt=structured_prompt,
        api_function=_internal_analysis,
        model_used="gpt-4o",
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()),
            'has_application_overview': bool(context.get('Application Overview', '').strip()),
            'context_items_count': len([k for k, v in context.items() if v and str(v).strip() and str(v).lower() != 'n/a']),
            'function': 'requirement_analysis',
            'structured_prompt_length': len(structured_prompt)
        }
    )

# Create a common function to consistently build comprehensive prompts across all functions
def create_comprehensive_prompt(requirement_text: str, context: Dict) -> str:
    """
    Create a consistently structured comprehensive prompt that includes:
    1. Application Overview
    2. Contextual Information (Q&A format)
    3. Requirement Text
    4. Action to AI model
    5. Assessment Coverage guidance
    
    This function can be reused across different wrapper functions to ensure consistency.
    """
    structured_prompt = ""
    
    # 1. Application Overview section
    application_overview = context.get('Application Overview', '')
    if application_overview and application_overview.strip():
        structured_prompt += f"APPLICATION OVERVIEW:\n{application_overview}\n\n"
    else:
        structured_prompt += "APPLICATION OVERVIEW: No specific application overview provided.\n\n"
    
    # 2. Contextual Information section (Q&A format)
    structured_prompt += "CONTEXTUAL INFORMATION:\n"
    
    if context:
        # Define question mappings for better Q&A format
        question_mappings = {
            'project_name': 'What is the project name?',
            'change_type': 'What type of change is being implemented?',
            'application_component_name': 'What is the name of the application or component?',
            'components_involved': 'What components are involved in this change?',
            'business_critical_volume': 'What is the expected volume of business-critical processes?',
            'response_time_sla': 'What is the expected response time SLA?',
            'growth_rate': 'What is the expected growth rate over the next year?',
            'customization_level': 'What is the level of customization required?',
            'channel_impact': 'Which channels will be impacted?',
            'performance_issues': 'Are there any known performance issues?',
            'business_disruption': 'What is the potential business disruption impact?',
            'contingency_plans': 'Are contingency plans in place for business continuity?',
            'assessment_coverage': 'What areas should the assessment cover?',
            'infrastructure_changes': 'What infrastructure changes are planned?',
            'third_party_involvement': 'What third-party systems are involved?'
        }
        
        # Process the context items in a specific order to ensure logical flow
        priority_keys = [
            'project_name', 'change_type', 'application_component_name', 'components_involved',
            'business_critical_volume', 'response_time_sla', 'growth_rate', 'customization_level',
            'channel_impact', 'performance_issues', 'business_disruption', 'contingency_plans',
            'assessment_coverage', 'infrastructure_changes', 'third_party_involvement'
        ]
        
        # First process the priority keys in order
        qa_items = []
        for key in priority_keys:
            if key in context and context[key] and str(context[key]).strip() and str(context[key]).lower() not in ['n/a', 'none', 'select...', '']:
                question = question_mappings.get(key, f"What is the {key.replace('_', ' ')}?")
                
                # Format the value
                if isinstance(context[key], list):
                    answer = ', '.join(str(v) for v in context[key] if v)
                else:
                    answer = str(context[key])
                
                qa_items.append(f"Q: {question}\nA: {answer}")
        
        # Then process any remaining keys not in the priority list
        for key, value in context.items():
            if key not in priority_keys and key != 'Application Overview' and value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...', '']:
                question = question_mappings.get(key, f"What is the {key.replace('_', ' ')}?")
                
                if isinstance(value, list):
                    answer = ', '.join(str(v) for v in value if v)
                else:
                    answer = str(value)
                
                qa_items.append(f"Q: {question}\nA: {answer}")
        
        if qa_items:
            structured_prompt += "\n".join(qa_items)
        else:
            structured_prompt += "Limited contextual information available."
    else:
        structured_prompt += "No specific contextual information provided."
    
    structured_prompt += "\n\n"
    
    # 3. Requirement text/file Upload contents section
    structured_prompt += f"REQUIREMENT TEXT:\n{requirement_text}\n\n"
    
    # 4. Assessment Coverage Guidance - Focus on selected testing types
    if 'assessment_coverage' in context and context['assessment_coverage']:
        selected_testing = context['assessment_coverage']
        if isinstance(selected_testing, list) and selected_testing:
            structured_prompt += "ASSESSMENT SCOPE FOCUS:\n"
            structured_prompt += f"The user has specifically requested focus on these testing types: {', '.join(selected_testing)}.\n"
            structured_prompt += "IMPORTANT: Only include mandatory and recommended testing for these specific testing types in your assessment.\n\n"
    
    # 5. Action to AI model section - Improved formatting instructions
    structured_prompt += "ACTION REQUIRED:\n"
    structured_prompt += "Please analyze all the information provided above and generate a comprehensive NFT Scope Assessment with the following sections:\n\n"
    structured_prompt += "1. Risk Level: Determine if the risk is High, Medium, or Low\n"
    structured_prompt += "2. Reasoning: Provide detailed rationale for the risk assessment\n"
    structured_prompt += "3. Mandatory NFT Requirements: List specific testing requirements organized by testing type\n"
    structured_prompt += "4. Recommended NFT Strategy: Provide strategic testing recommendations\n"
    structured_prompt += "5. Component-Specific Analysis: Analyze each component's specific testing needs\n\n"
    structured_prompt += "FORMATTING INSTRUCTIONS:\n"
    structured_prompt += "- Present information in a clean, professional format without markdown syntax\n"
    structured_prompt += "- Do not use quotes, backticks, or other code formatting elements\n"
    structured_prompt += "- Ensure consistent indentation and readable formatting\n"
    structured_prompt += "- Use straightforward headings and subheadings\n"
    structured_prompt += "- Format testing details with proper spacing and organization\n\n"
    structured_prompt += "If you require additional information, please identify all missing critical details in a single comprehensive statement."
    
    return structured_prompt

def wrapped_get_gpt_assessment(prompt: str, api_key: str, model: str = "gpt-4o") -> Dict[str, Any]:
    """Wrapped version of get_gpt_assessment with logging."""
    
    def _internal_get_assessment(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from . import gpt_logic
        
        # Add formatting instructions if they don't already exist in the prompt
        if "FORMATTING INSTRUCTIONS:" not in prompt_text:
            prompt_text += "\n\nFORMATTING INSTRUCTIONS:\n"
            prompt_text += "- Present information in a clean, professional format without markdown syntax\n"
            prompt_text += "- Do not use quotes, backticks, or other code formatting elements\n"
            prompt_text += "- Ensure consistent indentation and readable formatting\n"
            prompt_text += "- Use straightforward headings and subheadings\n"
            prompt_text += "- Format testing details with proper spacing and organization"
        
        result = gpt_logic.get_gpt_assessment(prompt_text, api_key)
        
        # If result is a dictionary with response content, clean any formatting artifacts
        if isinstance(result, dict) and 'risk' in result:
            for key in result:
                if isinstance(result[key], str):
                    # Remove markdown artifacts
                    result[key] = result[key].replace('`', '').replace('*', '')
                    # Fix inconsistent quotes
                    result[key] = result[key].replace('"', '"').replace('"', '"')
                    result[key] = result[key].replace("'", "'").replace("'", "'")
        
        return result
    
    # Check if the prompt is already properly structured
    if not prompt.startswith("APPLICATION OVERVIEW:") and "CONTEXTUAL INFORMATION:" not in prompt:
        # This might be a prompt from the older format, let's add a note for logging
        prompt_for_logging = "Note: Using custom prompt format that doesn't follow the standard structure.\n\n" + prompt
    else:
        prompt_for_logging = prompt
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="risk_assessment",
        prompt=prompt_for_logging,
        api_function=_internal_get_assessment,
        model_used=model,
        context_data={
            'prompt_length': len(prompt),
            'function': 'get_gpt_assessment',
            'is_structured_prompt': prompt.startswith("APPLICATION OVERVIEW:") or "CONTEXTUAL INFORMATION:" in prompt
        }
    )

def wrapped_analyze_requirement_quality(requirement_text: str, context: Dict, api_key: str, model: str = "gpt-4o") -> Dict[str, Any]:
    """Wrapped version of analyze_requirement_quality with logging."""
    
    def _internal_analyze_quality(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from . import req_quality_checker
        return req_quality_checker.analyze_requirement_quality(requirement_text, context, api_key, model)
    
    # Create a structured prompt for quality analysis using the common function
    prompt_for_logging = create_comprehensive_prompt(requirement_text, context)
    
    # Add quality-specific instructions
    prompt_for_logging += "\n\nFOCUS ON REQUIREMENT QUALITY ANALYSIS:\n"
    prompt_for_logging += "Please analyze the quality of this requirement with respect to clarity, testability, completeness, consistency, and traceability."
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="quality_analysis",
        prompt=prompt_for_logging,
        api_function=_internal_analyze_quality,
        model_used=model,
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()),
            'function': 'analyze_requirement_quality',
            'is_structured_prompt': True
        }
    )

def wrapped_generate_embedding(text: str, api_key: str) -> List[float]:
    """Wrapped version of generate_embedding with logging."""
    
    def _internal_generate_embedding(prompt_text, **kwargs):
        # Import here to avoid circular imports
        from . import chroma_logic
        return chroma_logic.generate_embedding(text, api_key)
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="embedding_generation",
        prompt=text,
        api_function=_internal_generate_embedding,
        model_used="text-embedding-3-small",
        context_data={
            'text_length': len(text),
            'function': 'generate_embedding'
        }
    )

def get_ai_transparency_report(session_id: str = None) -> Dict[str, Any]:
    """
    Generate a transparency report showing what was sent to AI and what was received.
    This helps users understand exactly what information was shared with AI.
    """
    if session_id is None:
        session_id = get_session_identifier()
    
    return ai_logger.validate_interaction_transparency(session_id)

def get_current_session_interactions() -> List[Dict]:
    """
    Get interactions from the current session, with improved session tracking
    """
    try:
        from core.ai_interaction_logger import ai_logger
        import streamlit as st
        
        # Use the consistent session UUID from session state
        if 'session_uuid' in st.session_state:
            session_id = st.session_state.session_uuid
        else:
            # Fallback to standard method if session UUID isn't set
            from core.ai_interaction_logger import get_session_identifier
            session_id = get_session_identifier()
            
        # Get interactions for this specific session
        interactions = ai_logger.get_session_interactions(session_id)
        
        # Cache the result in session state to prevent redundant database queries
        if interactions:
            return interactions
        else:
            # If no interactions for current session, return empty list instead of falling back
            # This is clearer than showing interactions from other sessions
            return []
    except Exception as e:
        print(f"Error getting session interactions: {e}")
        return []

def export_ai_interaction_logs(output_format: str = "json", filters: Optional[Dict] = None) -> str:
    """Export AI interaction logs for audit purposes."""
    return ai_logger.export_interactions(output_format, filters)

def get_ai_interaction_summary(hours: int = 24) -> Dict[str, Any]:
    """Get summary statistics of AI interactions."""
    return ai_logger.get_interaction_summary(hours)

def wrapped_generate_ai_questions(requirement_text: str, context: Dict, api_key: str) -> str:
    """
    Wrapped version of AI question generation.
    Despite the AI chat assistant features being removed, this function remains
    to maintain compatibility with existing imports.
    
    Returns a simple message or empty JSON to ensure the application continues to work.
    """
    
    def _internal_generate_questions(prompt_text, **kwargs):
        # Return placeholder response to maintain compatibility
        return {
            "questions": [],
            "message": "AI chat assistant features have been removed as requested."
        }
    
    prompt_for_logging = "AI chat assistant features have been removed as requested."
    
    # Get empty list as default for selected coverage
    selected_coverage = context.get('assessment_coverage', [])
    
    return AIInteractionWrapper.log_and_call_openai(
        interaction_type="question_generation",
        prompt=prompt_for_logging,
        api_function=_internal_generate_questions,
        model_used="gpt-4o",
        context_data={
            'requirement_text_length': len(requirement_text),
            'context_keys': list(context.keys()),
            'has_application_overview': bool(context.get('Application Overview', '').strip()),
            'selected_testing_coverage': selected_coverage,
            'function': 'generate_ai_questions'
        }
    )
