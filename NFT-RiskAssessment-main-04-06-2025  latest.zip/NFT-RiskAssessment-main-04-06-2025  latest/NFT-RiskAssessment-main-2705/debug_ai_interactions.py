"""
Debug utility for AI interactions database in the NFT Risk Assessment tool.
This script helps diagnose issues with AI interaction logging and retrieval.
"""

import os
import sqlite3
import json
import argparse
from datetime import datetime

def main():
    parser = argparse.ArgumentParser(description="Debug AI interactions database")
    parser.add_argument("--db_path", default=None, help="Path to the AI interactions database")
    parser.add_argument("--session", action="store_true", help="Show unique session IDs")
    parser.add_argument("--recent", action="store_true", help="Show most recent interactions")
    parser.add_argument("--count", action="store_true", help="Show interaction counts")
    parser.add_argument("--all", action="store_true", help="Show all interactions")
    args = parser.parse_args()
    
    # Find the database
    if args.db_path:
        db_path = args.db_path
    else:
        # Try to find the database in the standard location
        current_dir = os.path.dirname(os.path.abspath(__file__))
        db_path = os.path.join(current_dir, "data", "ai_interactions.db")
        
        # Check if the database exists
        if not os.path.exists(db_path):
            print(f"Database not found at: {db_path}")
            # Try parent directory data folder
            parent_dir = os.path.dirname(current_dir)
            parent_db_path = os.path.join(parent_dir, "data", "ai_interactions.db")
            if os.path.exists(parent_db_path):
                db_path = parent_db_path
                print(f"Found database at: {db_path}")
            else:
                print(f"Database not found at: {parent_db_path}")
                return
    
    # Connect to the database
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if the table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ai_interactions'")
        if not cursor.fetchone():
            print("AI interactions table does not exist in the database.")
            conn.close()
            return
        
        # Get total count
        cursor.execute("SELECT COUNT(*) FROM ai_interactions")
        total_count = cursor.fetchone()[0]
        print(f"Total interactions in database: {total_count}")
        
        if args.count or args.all:
            # Count by interaction type
            cursor.execute("SELECT interaction_type, COUNT(*) FROM ai_interactions GROUP BY interaction_type")
            counts_by_type = cursor.fetchall()
            print("\nCounts by interaction type:")
            for interaction_type, count in counts_by_type:
                print(f"  {interaction_type}: {count}")
            
            # Count by success
            cursor.execute("SELECT success, COUNT(*) FROM ai_interactions GROUP BY success")
            counts_by_success = cursor.fetchall()
            print("\nCounts by success:")
            for success, count in counts_by_success:
                print(f"  {'Success' if success else 'Failure'}: {count}")
        
        if args.session or args.all:
            # Get unique session IDs
            cursor.execute("SELECT DISTINCT session_id FROM ai_interactions")
            session_ids = [row[0] for row in cursor.fetchall()]
            print(f"\nUnique session IDs ({len(session_ids)}):")
            for session_id in session_ids:
                # Get count for this session
                cursor.execute("SELECT COUNT(*) FROM ai_interactions WHERE session_id = ?", (session_id,))
                session_count = cursor.fetchone()[0]
                # Get first and last timestamp for this session
                cursor.execute("SELECT MIN(timestamp_utc), MAX(timestamp_utc) FROM ai_interactions WHERE session_id = ?", (session_id,))
                min_time, max_time = cursor.fetchone()
                print(f"  {session_id}: {session_count} interactions, from {min_time} to {max_time}")
        
        if args.recent or args.all:
            # Get most recent interactions
            cursor.execute("SELECT session_id, timestamp_utc, interaction_type, success FROM ai_interactions ORDER BY timestamp_utc DESC LIMIT 10")
            recent_interactions = cursor.fetchall()
            print("\nMost recent interactions:")
            for session_id, timestamp, interaction_type, success in recent_interactions:
                print(f"  {timestamp} - {interaction_type} - {'✓' if success else '✗'} - {session_id}")
        
        conn.close()
        
    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
