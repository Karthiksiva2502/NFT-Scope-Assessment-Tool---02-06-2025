# Main Streamlit application file
import streamlit as st
import time
import pandas as pd
import json
import openai # Import the openai library
# streamlit_chat import removed - AI chat feature has been removed
from plotly.graph_objects import Figure as go  # Import plotly.graph_objects as go

# Import core application modules
from core import file_parser
from core import chroma_logic
from core import gpt_logic
from core import pdf_generator
from core import req_quality_checker
from core import risk_visualization
from core import historical_learning  # Import the new historical learning module
from core.intelligent_assessment_logic import IntelligentAssessmentDecision  # Import intelligent assessment logic

# Import AI interaction logging wrapper
from core.ai_interaction_wrapper import (
    wrapped_generate_ai_questions,
    wrapped_requirement_analysis,
    wrapped_get_gpt_assessment,
    wrapped_analyze_requirement_quality,
    wrapped_generate_embedding,
    get_ai_transparency_report,
    get_current_session_interactions,
    export_ai_interaction_logs
)
from core.ai_interaction_logger import get_session_identifier

# Apply custom styling to the app - this must be the first Streamlit command
st.set_page_config(layout="wide", page_title="NFT Requirement Risk Assessor", page_icon="🛡️")

# Custom CSS for better look and feel
st.markdown("""
<style>
    /* Main background gradient */
    .stApp {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }
    
    /* Header styling */
    h1, h2, h3 {
        color: #2c3e50;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    h1 {
        text-align: center;
        padding: 20px 0;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        border-bottom: 2px solid #3498db;
        margin-bottom: 30px;
        background-color: rgba(255, 255, 255, 0.7);
        border-radius: 10px;
    }
    
    /* Card-like styling for containers */
    .stTabs [data-baseweb="tab-panel"] {
        background-color: rgba(255, 255, 255, 0.8);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    /* Make sidebar more distinct */
    [data-testid="stSidebar"] {
        background-color: rgba(236, 240, 243, 0.9);
        border-right: 1px solid #ddd;
        padding: 10px;
    }
    
    /* Buttons styling */
    .stButton > button {
        background-color: #3498db;
        color: white;
        border-radius: 5px;
        border: none;
        padding: 5px 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        transition: all 0.3s;
    }
    .stButton > button:hover {
        background-color: #2980b9;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    /* Success and error messages */
    .stSuccess, .stInfo {
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    /* Tables and dataframes */
    [data-testid="stTable"] {
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    
    /* Assessment results */
    .element-container:has(h3:contains("Assessment Results")) {
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        margin: 15px 0;
    }
    
    /* AI Assistant styling */
    .element-container:has(h3:contains("AI Assistant")) {
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 10px;
        padding: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        margin: 15px 0;
    }
    
    /* Chat container */
    .chat-container {
        background-color: rgba(255, 255, 255, 0.9) !important;
        border: none !important;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05) !important;
    }
    
    /* Text areas */
    .stTextArea textarea {
        border-radius: 8px;
        border: 1px solid #ddd;
    }
    
    /* Expandable sections */
    .streamlit-expanderHeader {
        background-color: rgba(236, 240, 243, 0.9);
        border-radius: 5px;
    }
    
    /* Status indicators */
    .element-container:has(p:contains("Approved")) {
        color: #27ae60;
    }
    .element-container:has(p:contains("Rejected")) {
        color: #e74c3c;
    }
    .element-container:has(p:contains("Pending")) {
        color: #f39c12;
    }
</style>
""", unsafe_allow_html=True)

# --- Initialize session state ---
# Initialize API key in session state first since check_mandatory_fields() depends on it
if 'api_key_input_global' not in st.session_state:
    st.session_state.api_key_input_global = ""

if 'assessment_result' not in st.session_state:
    st.session_state.assessment_result = None
if 'similar_requirements' not in st.session_state:
    st.session_state.similar_requirements = None
if 'current_requirement_text' not in st.session_state:
    st.session_state.current_requirement_text = ""
if 'current_context' not in st.session_state:
    st.session_state.current_context = {} # Will be populated by sidebar
if 'assessment_id' not in st.session_state:
    st.session_state.assessment_id = None
if 'all_fields_filled' not in st.session_state:
    st.session_state.all_fields_filled = False
if 'project_type_selection' not in st.session_state: # To store the project type
    st.session_state.project_type_selection = 'New Project' # Default
if 'quality_check_result' not in st.session_state:
    st.session_state.quality_check_result = None
# Ensure the radio button's state key is initialized
if 'ctx_change_type_sidebar_global' not in st.session_state:
    st.session_state.ctx_change_type_sidebar_global = 'New Change (New Feature/Application)'
if 'batch_assessment_results' not in st.session_state:
    st.session_state.batch_assessment_results = [] # For storing results of batch processing
if 'initial_assessment' not in st.session_state:
    st.session_state.initial_assessment = {} # For storing the initial assessment before showing question
# Note: Search parameters are now configured in backend (chroma_logic.py) with DEFAULT values
# Add session state for API key validation
if 'api_key_valid' not in st.session_state:
    st.session_state.api_key_valid = False
# Add session state for Phase 1 features
if 'dashboard_tab_selected' not in st.session_state:
    st.session_state.dashboard_tab_selected = False
if 'component_map_tab_selected' not in st.session_state:
    st.session_state.component_map_tab_selected = False

# Function that always returns True to bypass the insufficient information detection
def is_input_sufficient(requirement_text, context):
    """
    Always returns True to ensure direct assessment without triggering AI questions.
    AI chat assistant features have been removed as requested.
    """
    return True

# Removed function - generate_ai_questions
def generate_ai_questions(requirement_text, context, api_key):
    """
    This function has been removed as requested.
    Returns None to avoid triggering any question generation.
    AI chat assistant features have been removed as requested.
    """
    return None

# Removed function - handle_ai_chat
def handle_ai_chat(question, api_key):
    """
    This function has been removed as requested.
    Now returns immediately without displaying any chat interface.
    """
    return None
    # AI chat assistant features have been removed as requested
    
    # Auto-proceed with analysis when user has responded and auto_proceed_analysis flag is set
    if has_user_response and st.session_state.get('auto_proceed_analysis', False) and len(st.session_state.chat_history) >= 2:
        st.success("🎉 Processing your comprehensive requirement analysis...")
        
        # Compile all user answers into context
        user_answers = []
        for message in st.session_state.chat_history:
            if message["role"] == "user":
                user_answers.append(message["content"])
        
        combined_user_answer = "\n\n".join(user_answers)
        
        # Add to current context with a clearer key name
        st.session_state.current_context['AI Assistant Gathered Information'] = combined_user_answer
        
        # Update requirement text with gathered info in a more structured format
        enhanced_requirement = f"""Original Requirement:
{st.session_state.current_requirement_text}

Additional Information Gathered Through AI Assistant:
{combined_user_answer}"""
        
        st.session_state.current_requirement_text = enhanced_requirement
        
        # Reset chat active state but preserve chat history
        st.session_state.chat_active = False
        
        # Proceed with comprehensive analysis
        with st.spinner("Performing comprehensive analysis with all gathered information..."):
            try:
                current_api_key = st.session_state.api_key_input_global
                collection = chroma_logic.get_or_create_collection(current_api_key)
                embedding = wrapped_generate_embedding(enhanced_requirement, current_api_key)
                st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                    collection,
                    embedding,
                    n_results=chroma_logic.DEFAULT_N_RESULTS,
                    custom_threshold=chroma_logic.DEFAULT_SIMILARITY_THRESHOLD
                )
                
                # Prepare comprehensive context
                context_for_prompt = {}
                
                # Add Application Overview from session state
                if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                    context_for_prompt["Application Overview"] = st.session_state.application_overview
                
                project_name_val = st.session_state.current_context.get('project_name')
                if project_name_val: context_for_prompt["Project Name"] = project_name_val
                
                # Add all contextual information from the form structure
                contextual_mappings = {
                    'project_name': "Project Name",
                    'change_type': "Type of Change", 
                    'application_component_name': "Application/Component Name",
                    'components_involved': "Components Involved",
                    'business_critical_volume': "Expected Volume of Business-Critical Process/Flow",
                    'response_time_sla': "Expected Response Time SLA",
                    'growth_rate': "Expected Growth Rate Over the Next Year",
                    'customization_level': "Level of Customization/Modification",
                    'channel_impact': "Channel/Component Impacted",
                    'performance_issues': "Performance/Scalability Issues",
                    'business_disruption': "Business Disruption Due to Change Failure",
                    'contingency_plans': "Contingency Plans for Business Continuity",
                    'assessment_coverage': "Assessment Coverage",
                    'infrastructure_changes': "Infrastructure Changes Details",
                    'third_party_involvement': "Third-Party Dependencies Details"
                }
                
                # Add context from session state
                for field_key, desc_label in contextual_mappings.items():
                    if field_key in ['project_name', 'change_type', 'component_name', 'components_involved', 
                                  'customization_level', 'channel_impact', 'performance_issues', 
                                  'business_disruption', 'contingency_plans', 'assessment_coverage']:
                        # These are stored directly in current_context
                        value = st.session_state.current_context.get(field_key)
                    else:
                        # These are stored as sidebar globals
                        session_key = f"ctx_{field_key}_sidebar_global"
                        value = st.session_state.get(session_key)
                    
                    if value: 
                        context_for_prompt[desc_label] = value
                
                # Add AI gathered information
                if st.session_state.current_context.get('AI Assistant Gathered Information'):
                    context_for_prompt["AI Assistant Gathered Information"] = st.session_state.current_context['AI Assistant Gathered Information']
                
                # Create comprehensive prompt with all inputs
                prompt = IntelligentAssessmentDecision.create_comprehensive_prompt(
                    requirement_text=enhanced_requirement,
                    context=context_for_prompt,
                    application_overview=st.session_state.get('application_overview', ''),
                    ai_gathered_info=st.session_state.current_context.get('AI Assistant Gathered Information', ''),
                    similar_requirements=st.session_state.similar_requirements
                )
                
                # Explicitly add selected assessment coverage to guide GPT in generating relevant testing types only
                testing_selections = st.session_state.current_context.get('assessment_coverage', [])
                if testing_selections:
                    # Modify the prompt to include specific instructions about test coverage
                    prompt += f"\n\nIMPORTANT: Only include mandatory and recommended testing for these specific testing types selected by the user: {', '.join(testing_selections)}. Do not include any testing types not explicitly selected."
                else:
                    # If nothing selected, make it clear no specific testing should be recommended
                    prompt += "\n\nIMPORTANT: User has not selected any specific testing coverage. Provide general analysis without specific testing recommendations."
                
                # Get final assessment - combining previously gathered assessment and new information
                # Use the initial_assessment from backend if it exists
                initial_assessment = st.session_state.get('initial_assessment', {})
                
                # Combine with freshly gathered information to generate the final assessment
                gpt_response = wrapped_get_gpt_assessment(prompt, current_api_key)

                if gpt_response and "error" in gpt_response:
                    st.error(f"Analysis failed: {gpt_response['error']}")
                    st.session_state.assessment_result = None
                    st.session_state.assessment_id = None
                elif gpt_response:
                    st.session_state.assessment_result = gpt_response
                    doc_id = chroma_logic.add_assessment(
                        collection, enhanced_requirement, embedding,
                        gpt_response.get('risk'), gpt_response.get('reasoning'),
                        gpt_response.get('recommendations'), gpt_response.get('impact'),
                        st.session_state.current_context.get('project_name', 'N/A')
                    )
                    st.session_state.assessment_id = doc_id
                    if doc_id: 
                        st.success("Final analysis complete!")
                        st.rerun()
                    else: 
                        st.error("Failed to save to database.")
                else:
                    st.error("Analysis failed. No response.")
                    st.session_state.assessment_result = None
                    st.session_state.assessment_id = None
            except Exception as e:
                st.error(f"Analysis error: {e}")
                st.session_state.assessment_result = None
                st.session_state.assessment_id = None

st.title("NFT Requirement Risk Assessment Tool")

# AI chat feature variables have been removed as requested

# Define lists of widget keys for the new contextual questions
mandatory_widget_keys = [
    'ctx_project_name_sidebar_global',
    'ctx_change_type_sidebar_global',
    'ctx_application_component_name_sidebar_global',
    'ctx_components_involved_sidebar_global',
    'ctx_business_critical_volume_sidebar_global',
    'ctx_response_time_sla_sidebar_global',
    'ctx_expected_growth_rate_sidebar_global',
    'ctx_customization_level_sidebar_global',
    'ctx_channel_impact_sidebar_global',
    'ctx_performance_issues_sidebar_global',
    'ctx_business_disruption_sidebar_global',
    'ctx_contingency_plans_sidebar_global',
    'ctx_assessment_coverage_sidebar_global'
]

# Follow-up question widget keys
followup_widget_keys = [
    'ctx_infrastructure_changes_sidebar_global',
    'ctx_third_party_involvement_sidebar_global'
]

# Function to check if all mandatory fields are filled
def check_mandatory_fields():
    # Check if API key is provided
    if not st.session_state.api_key_input_global:
        return False
    
    # Check all mandatory fields
    for field in mandatory_widget_keys:
        # Special handling for assessment_coverage which is now a list from checkboxes
        if field == 'ctx_assessment_coverage_sidebar_global':
            # Check if at least one assessment option is selected
            assessment_coverage = st.session_state.current_context.get('assessment_coverage', [])
            if not assessment_coverage or len(assessment_coverage) == 0:
                return False
        # Special handling for components_involved which is now a list from checkboxes
        elif field == 'ctx_components_involved_sidebar_global':
            # Check if at least one component is selected
            components_involved = st.session_state.current_context.get('components_involved', [])
            if not components_involved or len(components_involved) == 0:
                return False
        # Conditional validation for fields that depend on change type
        elif field in ['ctx_customization_level_sidebar_global', 'ctx_performance_issues_sidebar_global']:
            change_type = st.session_state.current_context.get('change_type', '')
            # Only validate these fields if change type is NOT "New Change (New Feature/Application)"
            if change_type != 'New Change (New Feature/Application)':
                if field not in st.session_state or not st.session_state[field]:
                    return False
            # If change type is "New Change", these fields are optional/hidden, so skip validation
        else:
            if field not in st.session_state or not st.session_state[field]:
                return False
    
    # Check follow-up questions based on component selection
    components_involved = st.session_state.current_context.get('components_involved', [])
    
    if 'Infrastructure' in components_involved:
        if not st.session_state.get('ctx_infrastructure_changes_sidebar_global', ''):
            return False
    if 'Third-Party' in components_involved:
        if not st.session_state.get('ctx_third_party_involvement_sidebar_global', ''):
            return False
            
    return True

# Function to clear follow-up question states when component selection changes
def components_changed_callback():
    # Clear all follow-up question states
    for key in followup_widget_keys:
        if key in st.session_state:
            st.session_state.pop(key, None)
    
    # Clear follow-up questions from context
    if 'infrastructure_changes' in st.session_state.current_context:
        del st.session_state.current_context['infrastructure_changes']
    if 'third_party_involvement' in st.session_state.current_context:
        del st.session_state.current_context['third_party_involvement']
    
    # Reset assessment details as context has changed
    st.session_state.assessment_result = None
    st.session_state.assessment_id = None
    st.session_state.current_requirement_text = ""
    st.session_state.similar_requirements = []

# Function to clear conditional fields when change type changes
def change_type_changed_callback():
    # Clear conditional fields that depend on change type
    conditional_fields = ['ctx_customization_level_sidebar_global', 'ctx_performance_issues_sidebar_global']
    for key in conditional_fields:
        if key in st.session_state:
            st.session_state.pop(key, None)
    
    # Clear from context as well
    if 'customization_level' in st.session_state.current_context:
        del st.session_state.current_context['customization_level']
    if 'performance_issues' in st.session_state.current_context:
        del st.session_state.current_context['performance_issues']
    
    # Reset assessment details as context has changed
    st.session_state.assessment_result = None
    st.session_state.assessment_id = None
    st.session_state.current_requirement_text = ""
    st.session_state.similar_requirements = []

# --- Sidebar (Contextual Info always visible, API key always visible) ---
st.sidebar.header("Configuration")
# api_key variable is local to this scope, session state holds the persistent value
st.sidebar.text_input("Enter OpenAI API Key: *", type="password", key="api_key_input_global", help="Your OpenAI API key is required for analysis.")
st.sidebar.header("Contextual Information (for New Assessment)")
st.sidebar.markdown("##### All fields are mandatory *")

# 1. Project Name
st.session_state.current_context['project_name'] = st.sidebar.text_input(
    "1. Project Name: *", 
    help="Enter the name of the project",
    key='ctx_project_name_sidebar_global'
)

# 2. Describe the Type of Change
st.session_state.current_context['change_type'] = st.sidebar.radio(
    "2. Describe the Type of Change: *",
    ('New Change (New Feature/Application)', 
     'Enhancement (Upgrade Existing Feature)', 
     'Modification (Defect Fixes... etc.)'),
    key='ctx_change_type_sidebar_global',
    on_change=change_type_changed_callback,
    help="Select the type of change being implemented"
)

# 3. Name of the Application/Component
st.session_state.current_context['application_component_name'] = st.sidebar.text_input(
    "3. Name of the Application/Component: *", 
    help="Enter the name of the application or component involved",
    key='ctx_application_component_name_sidebar_global'
)

# 4. Components Involved in the Change
st.sidebar.markdown("4. Components Involved in the Change: * (Select all that apply)")
component_options = ['User Interface', 'Backend Change', 'Batch Jobs', 'Infrastructure', 'Third-Party']
selected_components = []
for option in component_options:
    if st.sidebar.checkbox(
        option, 
        key=f'ctx_component_{option.replace(" ", "_").replace("-", "_").lower()}_sidebar_global',
        on_change=components_changed_callback,
        help=("Select if there is any change in:\n"
              "- User Interface: Web/Application Interface, Public Site, mobile UI\n"
              "- Backend Change: Code-level change (Cross Layer, SOA, API, Database)\n"
              "- Batch Jobs: Daily, weekly, or monthly jobs\n"
              "- Infrastructure: Host servers, Database, Network, Architecture\n"
              "- Third-Party: Systems like Fiserv, Experian, Vocalink, etc.")
    ):
        selected_components.append(option)
st.session_state.current_context['components_involved'] = selected_components

# Follow-up questions based on component selection
components_involved = st.session_state.current_context.get('components_involved', [])

if 'Infrastructure' in components_involved:
    st.sidebar.markdown("**Follow-up for Infrastructure:**")
    st.session_state.current_context['infrastructure_changes'] = st.sidebar.text_area(
        "Brief about the infra changes (Database migration, Cloud platform changes, subscription changes, etc.): *",
        height=100,
        key='ctx_infrastructure_changes_sidebar_global'
    )

if 'Third-Party' in components_involved:
    st.sidebar.markdown("**Follow-up for Third-Party:**")
    st.session_state.current_context['third_party_involvement'] = st.sidebar.text_area(
        "Brief about third-party involvement (Fiserv, Experian, Vocalink etc.): *",
        height=100,
        key='ctx_third_party_involvement_sidebar_global'
    )

# 5. Expected Volume of Business-Critical Process/Flow
st.session_state.current_context['business_critical_volume'] = st.sidebar.radio(
    "5. Expected Volume of Business-Critical Process/Flow: *",
    ('<1K (Transactions Daily)', '1K to 5K (Transactions Daily)', '>5K (Transactions Daily)', 'Nil'),
    key='ctx_business_critical_volume_sidebar_global',
    help="Select the expected daily transaction volume for your process/flow"
)

# 6. Expected Response Time SLA
st.session_state.current_context['response_time_sla'] = st.sidebar.radio(
    "6. Expected Response Time SLA: *",
    ('<1 second', '1 to 3 seconds', '>3 seconds', 'NA'),
    key='ctx_response_time_sla_sidebar_global',
    help="Select the expected response time Service Level Agreement"
)

# 7. Expected Growth Rate Over the Next Year
st.session_state.current_context['growth_rate'] = st.sidebar.radio(
    "7. Expected Growth Rate Over the Next Year: *",
    ('<=5%', '5% to 15%', '15% to 25%', '>25%', 'Nil'),
    key='ctx_expected_growth_rate_sidebar_global',
    help="Select the expected growth rate over the next year"
)

# 8. Level of Customization/Modification (only for non-new changes)
change_type = st.session_state.current_context.get('change_type', '')
if change_type != 'New Change (New Feature/Application)':
    st.session_state.current_context['customization_level'] = st.sidebar.radio(
        "8. Level of Customization/Modification Done as Part of the Change: *",
        ('Minimal', 'Moderate', 'Significant'),
        key='ctx_customization_level_sidebar_global',
        help="Select the level of customization or modification required"
    )
else:
    # Clear the field if it exists and change type is "New Change"
    if 'customization_level' in st.session_state.current_context:
        del st.session_state.current_context['customization_level']
    # Also clear from session state
    if 'ctx_customization_level_sidebar_global' in st.session_state:
        del st.session_state['ctx_customization_level_sidebar_global']

# 9. Channel/Component Impacted
st.session_state.current_context['channel_impact'] = st.sidebar.text_input(
    "9. Channel/Component Impacted by the Change: *",
    key='ctx_channel_impact_sidebar_global',
    help="Specify the channel or component impacted by this change"
)

# 10. Performance/Scalability Issues (only for non-new changes)
if change_type != 'New Change (New Feature/Application)':
    st.session_state.current_context['performance_issues'] = st.sidebar.radio(
        "10. Performance/Scalability Issues in Current Production Environment: *",
        ('Yes', 'No'),
        key='ctx_performance_issues_sidebar_global',
        help="Indicate if there are any current performance or scalability issues"
    )
else:
    # Clear the field if it exists and change type is "New Change"
    if 'performance_issues' in st.session_state.current_context:
        del st.session_state.current_context['performance_issues']
    # Also clear from session state
    if 'ctx_performance_issues_sidebar_global' in st.session_state:
        del st.session_state['ctx_performance_issues_sidebar_global']

# 11. Business Disruption Impact
st.session_state.current_context['business_disruption'] = st.sidebar.radio(
    "11. Potential Business Disruption Due to Change Failure: *",
    ('Yes – Slows down the application', 'Yes – Completely stops the application', 'No'),
    key='ctx_business_disruption_sidebar_global',
    help="Select the potential impact of a change failure on business operations"
)

# 12. Contingency Plans
st.session_state.current_context['contingency_plans'] = st.sidebar.radio(
    "12. Contingency Plans for Business Continuity: *",
    ('Yes', 'No'),
    key='ctx_contingency_plans_sidebar_global',
    help="Indicate if contingency plans are in place"
)

# 13. Assessment Coverage
st.sidebar.markdown("13. Assessment Coverage: * (Select all that apply)")
assessment_options = ['Performance Testing (Load, Stress, etc.)', 'Device Level Testing', 'OAT', 'Accessibility', 'Security', 'All Non-Functional Testing']
selected_assessments = []
for option in assessment_options:
    if st.sidebar.checkbox(option, key=f'ctx_assessment_{option.replace(" ", "_").replace("(", "").replace(")", "").replace(",", "").lower()}_sidebar_global'):
        selected_assessments.append(option)
st.session_state.current_context['assessment_coverage'] = selected_assessments

# Check if all fields are filled after any change
st.session_state.all_fields_filled = check_mandatory_fields()

# Display a message about mandatory fields if not all filled
if not st.session_state.all_fields_filled:
    st.sidebar.warning("⚠️ All fields marked with * are mandatory. Please fill them all to proceed.")

# --- AI Transparency Section ---
st.sidebar.markdown("---")
st.sidebar.header("🔍 AI Interaction Transparency")

with st.sidebar.expander("View AI Interactions", expanded=True):
    st.markdown("**AI Interactions:**")
    
    # Get current session interactions
    try:
        # Import necessary modules
        from core.ai_interaction_logger import ai_logger, get_session_identifier
        from core.ai_interaction_wrapper import get_current_session_interactions
        import sqlite3
        import time
        
        # Generate or retrieve a consistent session identifier for this Streamlit session
        if 'session_uuid' not in st.session_state:
            st.session_state.session_uuid = get_session_identifier()
        
        session_id = st.session_state.session_uuid
        
        # Check if database exists
        import os
        if not os.path.exists(ai_logger.db_path):
            st.warning(f"Database not found at: {ai_logger.db_path}")
        else:
            try:
                # Connect to database to get counts
                conn = sqlite3.connect(ai_logger.db_path)
                cursor = conn.cursor()
                cursor.execute('SELECT COUNT(*) FROM ai_interactions')
                total_count = cursor.fetchone()[0]
                cursor.execute('SELECT COUNT(*) FROM ai_interactions WHERE session_id = ?', (session_id,))
                session_count = cursor.fetchone()[0]
                
                # Get most recent timestamp to check for recent activity
                cursor.execute('SELECT timestamp_utc FROM ai_interactions ORDER BY timestamp_utc DESC LIMIT 1')
                most_recent = cursor.fetchone()
                
                # Get most recent interactions for this session specifically
                cursor.execute('''
                    SELECT interaction_type, timestamp_utc, model_used, success 
                    FROM ai_interactions 
                    WHERE session_id = ? 
                    ORDER BY timestamp_utc DESC LIMIT 5
                ''', (session_id,))
                recent_session_interactions = cursor.fetchall()
                
                conn.close()
                
                if most_recent:
                    st.info(f"Total interactions in DB: {total_count}, Current session interactions: {session_count}")
                    
                    if session_count == 0:
                        st.warning(f"Current session has no interactions yet. Start an analysis to see data.")
                    else:
                        st.success(f"Showing {min(5, session_count)} most recent interactions for this session")
                        
                        # Display the session-specific interactions
                        for i, (interaction_type, timestamp_utc, model_used, success) in enumerate(recent_session_interactions, 1):
                            status_icon = "✅" if success else "❌"
                            st.markdown(f"**{i}. {status_icon} {interaction_type}**")
                            st.text(f"   Time: {timestamp_utc}")
                            st.text(f"   Model: {model_used}")
                            st.markdown("---")
                else:
                    st.warning("No interactions found in the database.")
            except Exception as e:
                st.warning(f"Database error: {str(e)}")
        
        # Add a refresh button to manually update the interactions display
        if st.button("🔄 Refresh Interactions"):
            # Force clear cache for interaction data
            st.session_state.pop("_interactions_cache", None)
            st.success("Refreshing interaction data...")
            time.sleep(0.5)  # Brief pause for UX
            st.experimental_rerun()
            
        # Export functionality
        if st.button("📊 Export AI Interaction Report"):
            try:
                # Pass the specific session ID to ensure we get the right data
                report_data = get_ai_transparency_report(session_id)
                if report_data and len(report_data) > 0:
                    st.download_button(
                        label="💾 Download Report (JSON)",
                        data=json.dumps(report_data, indent=2),
                        file_name=f"ai_interactions_report_{int(time.time())}.json",
                        mime="application/json"
                    )
                else:
                    st.info("No interactions to export for this session")
            except Exception as e:
                st.error(f"Export failed: {str(e)}")
                
    except Exception as e:
        st.error(f"Error loading AI interactions: {str(e)}")
        import traceback
        st.error(f"Details: {traceback.format_exc()}")

# Logging configuration
with st.sidebar.expander("AI Logging Settings", expanded=False):
    st.markdown("**Logging Configuration:**")
    
    # Add toggle for logging (future enhancement)
    logging_enabled = st.checkbox("Enable AI Interaction Logging", value=True, disabled=True)
    st.info("AI interaction logging is currently always enabled for transparency")
    
    # Show database info
    try:
        from core.ai_interaction_logger import ai_logger
        total_interactions = len(ai_logger.get_session_interactions(get_session_identifier()))
        st.metric("Current Session Interactions", total_interactions)
    except Exception as e:
        st.text("Logging system status: Unknown")

# --- Main App Area with Tabs ---
tab1, tab2, tab3, tab4 = st.tabs(["New Assessment", "Previous Results", "Risk Dashboard", "Learning Analytics"])

# Handle tab selection state from other tabs
if st.session_state.get("dashboard_tab_selected", False):
    tab3.selectbox = True
    st.session_state.dashboard_tab_selected = False

with tab1:
    st.header("Submit New Requirement")
    
    # Display a notice at the top if fields aren't filled
    if not st.session_state.all_fields_filled:
        st.warning("⚠️ Please fill all mandatory fields in the sidebar before proceeding.")
    
    # Feature 1: Add Application Overview Text Box
    st.subheader("📝 Application Overview")
    st.markdown("*Provide a brief background of the application under scope assessment to improve AI analysis accuracy.*")
    
    # Initialize application overview in session state if not exists
    if 'application_overview' not in st.session_state:
        st.session_state.application_overview = ""
    
    application_overview = st.text_area(
        "Application Overview:",
        height=120,
        placeholder="Example: This is a customer-facing e-commerce platform built on microservices architecture, handling payment processing, user authentication, and order management. The system serves 10,000+ daily users and requires high availability...",
        key='application_overview_input',
        help="Describe the application's purpose, architecture, key functionalities, user base, performance requirements, and any critical business aspects. This context helps the AI provide more accurate scope assessments."
    )
    
    # Store in session state
    st.session_state.application_overview = application_overview
    
    st.markdown("---")
    
    input_method = st.radio("Choose input method:", ("Upload File", "Enter Text Manually", "Bulk Upload (CSV)"), horizontal=True, key="input_method_choice_tab1")
    uploaded_file = None
    manual_text = ""

    if input_method == "Upload File":
        uploaded_file = st.file_uploader("Upload Requirement Document (.txt or .docx)", type=['txt', 'docx'], key='file_uploader_tab1_single')
        if uploaded_file: 
            st.session_state.manual_text_tab1 = ""
            st.session_state.batch_assessment_results = [] # Clear batch results
    elif input_method == "Enter Text Manually":
        # Show the requirement text area
        manual_text = st.text_area("Enter Requirement Text:", height=200, key='manual_text_tab1')
        st.session_state.batch_assessment_results = [] # Clear batch results
    elif input_method == "Bulk Upload (CSV)":
        uploaded_file = st.file_uploader("Upload CSV file with a 'requirement_text' column", type=['csv'], key='file_uploader_tab1_bulk')
        st.info("Ensure your CSV has a column named 'requirement_text' (or similar like 'Requirement Text', 'requirement'). Context from the sidebar will be applied to all requirements in the file.")
        if uploaded_file:
            st.session_state.manual_text_tab1 = "" # Clear manual text
            st.session_state.assessment_result = None # Clear single assessment result
            st.session_state.assessment_id = None

    # Determine if analysis button should be enabled
    button_disabled = not st.session_state.all_fields_filled
    if input_method == "Enter Text Manually":
        button_disabled = not st.session_state.all_fields_filled or not manual_text.strip()
    elif input_method == "Bulk Upload (CSV)":
        if not uploaded_file: # Disable if no file is uploaded for bulk
            button_disabled = True
    elif input_method == "Upload File":
        if not uploaded_file: # Disable if no file is uploaded for single
            button_disabled = True

    # Disable the analyze button if mandatory fields aren't filled
    analyze_button = st.button("Analyze Requirement(s)", key="analyze_button_tab1", disabled=button_disabled)

    if analyze_button:
        st.session_state.batch_assessment_results = [] # Clear previous batch results
        st.session_state.assessment_result = None # Clear single result
        st.session_state.assessment_id = None

        if input_method == "Bulk Upload (CSV)" and uploaded_file is not None:
            requirements_list, error_msg = file_parser.parse_file(uploaded_file)
            if error_msg:
                st.error(error_msg)
            elif not requirements_list:
                st.warning("No requirements found in the CSV file or the 'requirement_text' column is empty.")
            else:
                st.info(f"Found {len(requirements_list)} requirements in the CSV. Starting batch analysis...")
                
                # Prepare context once for the whole batch
                current_api_key = st.session_state.api_key_input_global
                
                # Verify API key before starting the batch process
                try:
                    # Quick API key validation
                    if not current_api_key or len(current_api_key.strip()) < 10:
                        st.error("Invalid API key. Please enter a valid OpenAI API key.")
                        st.stop()
                        
                    # Test API connectivity
                    chroma_logic.check_openai_connectivity(current_api_key)
                except openai.AuthenticationError:
                    st.error("OpenAI authentication failed. Please check your API key and try again.")
                    st.stop()
                except Exception as e:
                    st.error(f"Error connecting to OpenAI: {str(e)}")
                    st.stop()
                    
                context_for_prompt = {}
                
                # Add Application Overview from session state
                if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                    context_for_prompt["Application Overview"] = st.session_state.application_overview
                
                project_name_val = st.session_state.current_context.get('project_name')
                if project_name_val: context_for_prompt["Project Name"] = project_name_val
                
                # Add all contextual information from the new 10-question structure
                contextual_mappings = {
                    'project_name': "Project Name",
                    'change_type': "Type of Change", 
                    'component_name': "Application/Component Name",
                    'components_involved': "Components Involved",
                    'customization_level': "Customization Level",
                    'channel_impact': "Channel/Component Impact",
                    'performance_issues': "Performance/Scalability Issues",
                    'business_disruption': "Business Disruption",
                    'contingency_plans': "Contingency Plans",
                    'assessment_coverage': "Assessment Coverage",
                    'ui_volume': "Expected Daily Volume (UI)",
                    'ui_response_time': "Expected Response Time (UI)",
                    'backend_volume': "Expected Transaction Volume (Backend)",
                    'backend_response_time': "Expected Response Time (Backend)",
                    'batch_volume': "Expected Data Volume (Batch)",
                    'batch_response_time': "Expected Processing Time (Batch)",
                    'growth_rate': "Expected Growth Rate",
                    'infrastructure_changes': "Infrastructure Changes Details",
                    'third_party_involvement': "Third-Party Dependencies Details"
                }
                
                # Add context from session state
                for field_key, desc_label in contextual_mappings.items():
                    if field_key in ['project_name', 'change_type', 'component_name', 'components_involved', 
                                   'customization_level', 'channel_impact', 'performance_issues', 
                                   'business_disruption', 'contingency_plans', 'assessment_coverage']:
                        # These are stored directly in current_context
                        value = st.session_state.current_context.get(field_key)
                    else:
                        # These are stored as sidebar globals
                        session_key = f"ctx_{field_key}_sidebar_global"
                        value = st.session_state.get(session_key)
                    
                    if value: 
                        context_for_prompt[desc_label] = value

                batch_progress = st.progress(0)
                temp_status = st.empty()
                processed_count = 0

                for i, req_text in enumerate(requirements_list):
                    temp_status.info(f"Processing requirement {i+1}/{len(requirements_list)}: '{req_text[:50]}...'")
                    if not req_text or len(req_text.strip()) < 5: # Basic validation for each requirement
                        st.session_state.batch_assessment_results.append({
                            "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                            "risk": "Error", "reasoning": "Requirement text too short or empty.", 
                            "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                            "comments": "Skipped due to insufficient text.", "timestamp": int(time.time())
                        })
                        processed_count +=1
                        batch_progress.progress(processed_count / len(requirements_list))
                        continue
                    try:
                        # Attempt to get or create the collection with proper error handling
                        try:
                            collection = chroma_logic.get_or_create_collection(current_api_key)
                        except Exception as collection_error:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": f"Database connection error: {str(collection_error)}", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Failed to connect to the database. Please check your network and credentials.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                            
                        # Generate embedding with error handling
                        try:
                            embedding = wrapped_generate_embedding(req_text, current_api_key)
                        except openai.AuthenticationError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI Authentication Failed", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Please check your OpenAI API key.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except Exception as embedding_error:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": f"Embedding generation error: {str(embedding_error)}", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Failed to create embeddings for similarity search.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        
                        # Compose prompt and get GPT assessment with error handling
                        # Use comprehensive prompt creation for bulk upload flow
                        prompt = IntelligentAssessmentDecision.create_comprehensive_prompt(
                            requirement_text=req_text,
                            context=context_for_prompt,
                            application_overview=st.session_state.get('application_overview', ''),
                            ai_gathered_info="",  # No AI gathered info in bulk processing
                            similar_requirements=None  # Skip similar requirements for performance in bulk
                        )
                        
                        # Explicitly add selected assessment coverage to guide GPT in generating relevant testing types only
                        testing_selections = st.session_state.current_context.get('assessment_coverage', [])
                        if testing_selections:
                            # Modify the prompt to include specific instructions about test coverage
                            prompt += f"\n\nIMPORTANT: Only include mandatory and recommended testing for these specific testing types selected by the user: {', '.join(testing_selections)}. Do not include any testing types not explicitly selected."
                        else:
                            # If nothing selected, make it clear no specific testing should be recommended
                            prompt += "\n\nIMPORTANT: User has not selected any specific testing coverage. Provide general analysis without specific testing recommendations."
                        
                        try:
                            gpt_response = wrapped_get_gpt_assessment(prompt, current_api_key)
                        except openai.AuthenticationError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI Authentication Failed", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Please check your OpenAI API key.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except openai.RateLimitError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI Rate Limit Exceeded", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "API rate limit reached. Please try again later or use a different API key.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except openai.APITimeoutError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI API Timeout", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "The request to OpenAI API timed out. Try again later.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except openai.APIConnectionError:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": "OpenAI API Connection Error", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Failed to connect to OpenAI API. Check your network connection.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue
                        except Exception as gpt_error:
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": f"GPT assessment error: {str(gpt_error)}", 
                                "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                                "comments": "Failed during AI assessment.", 
                                "timestamp": int(time.time())
                            })
                            processed_count += 1
                            batch_progress.progress(processed_count / len(requirements_list))
                            continue

                        # Process the response
                        if gpt_response and "error" not in gpt_response:
                            try:
                                doc_id = chroma_logic.add_assessment(
                                    collection, req_text, embedding,
                                    gpt_response.get('risk'), gpt_response.get('reasoning'),
                                    gpt_response.get('recommendations'), gpt_response.get('impact'),
                                    project_name_val or "N/A"
                                )
                                st.session_state.batch_assessment_results.append({
                                    "id": doc_id, "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                    **gpt_response, "status": "Pending", "comments": "", "timestamp": int(time.time())
                                })
                            except Exception as db_error:
                                st.session_state.batch_assessment_results.append({
                                    "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                    "risk": gpt_response.get('risk', 'N/A'), 
                                    "reasoning": gpt_response.get('reasoning', 'N/A'),
                                    "recommendations": gpt_response.get('recommendations', 'N/A'), 
                                    "impact": gpt_response.get('impact', 'N/A'), 
                                    "status": "Error-DB", 
                                    "comments": f"Assessment successful but database storage failed: {str(db_error)}", 
                                    "timestamp": int(time.time())
                                })
                        else:
                            error_detail = gpt_response.get('error', 'Unknown GPT error') if gpt_response else "No GPT response"
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": error_detail, "recommendations": "N/A", 
                                "impact": "N/A", "status": "Error", "comments": "Failed during GPT assessment.", "timestamp": int(time.time())
                            })
                    except Exception as e:
                        # Catch-all for any other unexpected errors
                        import traceback
                        error_traceback = traceback.format_exc()
                        error_type = type(e).__name__
                        
                        # Log detailed error info to console/log file
                        print(f"ERROR in batch processing item {i+1}: {error_type}: {str(e)}")
                        print(f"Traceback: {error_traceback}")
                        
                        # Add to results with more detailed error info
                        st.session_state.batch_assessment_results.append({
                            "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                            "risk": "Error", "reasoning": f"Unexpected error ({error_type}): {str(e)}", "recommendations": "N/A", 
                            "impact": "N/A", "status": "Error", "comments": "Failed during processing. Check logs for details.", 
                            "timestamp": int(time.time())
                        })
                    processed_count += 1
                    batch_progress.progress(processed_count / len(requirements_list))
                
                temp_status.success(f"Batch analysis complete for {len(requirements_list)} requirements.")
                batch_progress.empty()

        elif input_method == "Upload File" and uploaded_file is not None:
            try:
                requirement_text, error_msg = file_parser.parse_file(uploaded_file)
                if error_msg:
                    st.error(error_msg)
                    requirement_text = None
                if requirement_text is None and not error_msg: 
                    st.error("Unsupported file type or empty file.")
            except Exception as e: 
                st.error(f"Error reading file: {e}")
                requirement_text = None
                
            st.session_state.current_requirement_text = requirement_text
            # --- Standard single requirement processing logic ---
            if requirement_text:
                with st.spinner("Analyzing..."):
                    try:
                        current_api_key = st.session_state.api_key_input_global
                        # Use the wrapped function with automatic reconnection logic
                        collection = chroma_logic.get_or_create_collection_with_retry(current_api_key)
                        embedding = wrapped_generate_embedding(requirement_text, current_api_key)
                        st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                            collection,
                            embedding,
                            n_results=chroma_logic.DEFAULT_N_RESULTS,
                            custom_threshold=chroma_logic.DEFAULT_SIMILARITY_THRESHOLD
                        )
                        
                        context_for_prompt = {}
                        
                        # Add Application Overview from session state
                        if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                            context_for_prompt["Application Overview"] = st.session_state.application_overview
                        
                        project_name_val = st.session_state.current_context.get('project_name')
                        if project_name_val: context_for_prompt["Project Name"] = project_name_val
                        
                        # Add all contextual information from the new 10-question structure
                        contextual_mappings = {
                            'project_name': "Project Name",
                            'change_type': "Type of Change", 
                            'component_name': "Application/Component Name",
                            'components_involved': "Components Involved",
                            'customization_level': "Customization Level",
                            'channel_impact': "Channel/Component Impact",
                            'performance_issues': "Performance/Scalability Issues",
                            'business_disruption': "Business Disruption",
                            'contingency_plans': "Contingency Plans",
                            'assessment_coverage': "Assessment Coverage",
                            'ui_volume': "Expected Daily Volume (UI)",
                            'ui_response_time': "Expected Response Time (UI)",
                            'backend_volume': "Expected Transaction Volume (Backend)",
                            'backend_response_time': "Expected Response Time (Backend)",
                            'batch_volume': "Expected Data Volume (Batch)",
                            'batch_response_time': "Expected Processing Time (Batch)",
                            'growth_rate': "Expected Growth Rate",
                            'infrastructure_changes': "Infrastructure Changes Details",
                            'third_party_involvement': "Third-Party Dependencies Details"
                        }
                        
                        # Add context from session state
                        for field_key, desc_label in contextual_mappings.items():
                            if field_key in ['project_name', 'change_type', 'component_name', 'components_involved', 
                                           'customization_level', 'channel_impact', 'performance_issues', 
                                           'business_disruption', 'contingency_plans', 'assessment_coverage']:
                                # These are stored directly in current_context
                                value = st.session_state.current_context.get(field_key)
                            else:
                                # These are stored as sidebar globals
                                session_key = f"ctx_{field_key}_sidebar_global"
                                value = st.session_state.get(session_key)
                            
                            if value: 
                                context_for_prompt[desc_label] = value
                        
                        # Directly proceed with the analysis
                        try:
                            with st.spinner("Analyzing requirement..."):
                                # Create prompt for analysis
                                prompt = IntelligentAssessmentDecision.create_comprehensive_prompt(
                                    requirement_text=requirement_text,
                                    context=context_for_prompt,
                                    application_overview=st.session_state.get('application_overview', ''),
                                    similar_requirements=st.session_state.similar_requirements
                                )
                                
                                # Explicitly add selected assessment coverage to guide GPT in generating relevant testing types only
                                testing_selections = st.session_state.current_context.get('assessment_coverage', [])
                                if testing_selections:
                                    # Modify the prompt to include specific instructions about test coverage
                                    prompt += f"\n\nIMPORTANT: Only include mandatory and recommended testing for these specific testing types selected by the user: {', '.join(testing_selections)}. Do not include any testing types not explicitly selected."
                                else:
                                    # If nothing selected, make it clear no specific testing should be recommended
                                    prompt += "\n\nIMPORTANT: User has not selected any specific testing coverage. Provide general analysis without specific testing recommendations."
                                
                                # Get assessment
                                gpt_response = wrapped_get_gpt_assessment(prompt, current_api_key)
                        except Exception as e:
                            # If error occurs, show error message
                            st.error(f"Error during assessment: {str(e)}")
                            st.session_state.assessment_result = None
                            st.session_state.assessment_id = None
                            st.stop()

                        if gpt_response and "error" in gpt_response:
                            st.error(f"Analysis failed: {gpt_response['error']}")
                            st.session_state.assessment_result = None
                            st.session_state.assessment_id = None
                        elif gpt_response:
                            st.session_state.assessment_result = gpt_response
                            # Use original requirement text and embedding
                            doc_id = chroma_logic.add_assessment(
                                collection, requirement_text, embedding,
                                gpt_response.get('risk'), gpt_response.get('reasoning'),
                                gpt_response.get('recommendations'), gpt_response.get('impact'),
                                st.session_state.current_context.get('project_name', 'N/A')
                            )
                            st.session_state.assessment_id = doc_id
                            if doc_id: 
                                st.success("Analysis complete!")
                            else: 
                                st.error("Failed to save to database.")
                        else:
                            st.error("Analysis failed. No response.")
                            st.session_state.assessment_result = None
                            st.session_state.assessment_id = None
                    except Exception as e:
                        st.error(f"Analysis error: {e}")
                        st.session_state.assessment_result = None
                        st.session_state.assessment_id = None

        elif input_method == "Enter Text Manually":
            requirement_text = st.session_state.manual_text_tab1
            st.session_state.current_requirement_text = requirement_text

            if not requirement_text: 
                st.warning("Please provide requirement text.")
            else:
                # Directly proceed with analysis without gathering additional information
                with st.spinner("Analyzing requirement..."):
                    try:
                        current_api_key = st.session_state.api_key_input_global
                        collection = chroma_logic.get_or_create_collection(current_api_key)
                        embedding = wrapped_generate_embedding(requirement_text, current_api_key)
                        st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                            collection,
                            embedding,
                            n_results=chroma_logic.DEFAULT_N_RESULTS,
                            custom_threshold=chroma_logic.DEFAULT_SIMILARITY_THRESHOLD
                        )
                        
                        # Prepare context with application overview
                        context_for_prompt = {}
                        
                        # Add Application Overview from session state
                        if st.session_state.get('application_overview') and st.session_state.application_overview.strip():
                            context_for_prompt["Application Overview"] = st.session_state.application_overview
                        
                        project_name_val = st.session_state.current_context.get('project_name')
                        if project_name_val: context_for_prompt["Project Name"] = project_name_val
                        
                        # Add all contextual information from the sidebar
                        contextual_mappings = {
                            'project_name': "Project Name",
                            'change_type': "Type of Change", 
                            'component_name': "Application/Component Name",
                            'components_involved': "Components Involved",
                            'customization_level': "Customization Level",
                            'channel_impact': "Channel/Component Impact",
                            'performance_issues': "Performance/Scalability Issues",
                            'business_disruption': "Business Disruption",
                            'contingency_plans': "Contingency Plans",
                            'assessment_coverage': "Assessment Coverage",
                            'ui_volume': "Expected Daily Volume (UI)",
                            'ui_response_time': "Expected Response Time (UI)",
                            'backend_volume': "Expected Transaction Volume (Backend)",
                            'backend_response_time': "Expected Response Time (Backend)",
                            'batch_volume': "Expected Data Volume (Batch)",
                            'batch_response_time': "Expected Processing Time (Batch)",
                            'growth_rate': "Expected Growth Rate",
                            'infrastructure_changes': "Infrastructure Changes Details",
                            'third_party_involvement': "Third-Party Dependencies Details"
                        }
                        
                        # Add context from session state
                        for field_key, desc_label in contextual_mappings.items():
                            if field_key in ['project_name', 'change_type', 'component_name', 'components_involved', 
                                           'customization_level', 'channel_impact', 'performance_issues', 
                                           'business_disruption', 'contingency_plans', 'assessment_coverage']:
                                # These are stored directly in current_context
                                value = st.session_state.current_context.get(field_key)
                            else:
                                # These are stored as sidebar globals
                                session_key = f"ctx_{field_key}_sidebar_global"
                                value = st.session_state.get(session_key)
                            
                            if value: 
                                context_for_prompt[desc_label] = value
                        
                        # Create prompt and get assessment
                        prompt = IntelligentAssessmentDecision.create_comprehensive_prompt(
                            requirement_text=requirement_text,
                            context=context_for_prompt,
                            application_overview=st.session_state.get('application_overview', ''),
                            similar_requirements=st.session_state.similar_requirements
                        )
                        
                        # Explicitly add selected assessment coverage to guide GPT in generating relevant testing types only
                        testing_selections = st.session_state.current_context.get('assessment_coverage', [])
                        if testing_selections:
                            # Modify the prompt to include specific instructions about test coverage
                            prompt += f"\n\nIMPORTANT: Only include mandatory and recommended testing for these specific testing types selected by the user: {', '.join(testing_selections)}. Do not include any testing types not explicitly selected."
                        else:
                            # If nothing selected, make it clear no specific testing should be recommended
                            prompt += "\n\nIMPORTANT: User has not selected any specific testing coverage. Provide general analysis without specific testing recommendations."
                        
                        # Get final assessment
                        gpt_response = wrapped_get_gpt_assessment(prompt, current_api_key)
                        
                        if gpt_response and "error" in gpt_response:
                            st.error(f"Analysis failed: {gpt_response['error']}")
                            st.session_state.assessment_result = None
                            st.session_state.assessment_id = None
                        elif gpt_response:
                            st.session_state.assessment_result = gpt_response
                            doc_id = chroma_logic.add_assessment(
                                collection, requirement_text, embedding,
                                gpt_response.get('risk'), gpt_response.get('reasoning'),
                                gpt_response.get('recommendations'), gpt_response.get('impact'),
                                st.session_state.current_context.get('project_name', 'N/A')
                            )
                            st.session_state.assessment_id = doc_id
                            if doc_id: 
                                st.success("Analysis complete!")
                            else: 
                                st.error("Failed to save to database.")
                        else:
                            st.error("Analysis failed. No response.")
                            st.session_state.assessment_result = None
                            st.session_state.assessment_id = None
                    except Exception as e:
                        st.error(f"Analysis error: {str(e)}")
                        st.session_state.assessment_result = None
                        st.session_state.assessment_id = None
    
    # No longer need to handle AI chat display

    # Display assessment results if available
    if st.session_state.assessment_result and "error" not in st.session_state.assessment_result and input_method != "Bulk Upload (CSV)":
        st.markdown("---")
        
        # Add requirement quality check section
        st.header("Requirement Quality Analysis")
        
        # Get requirement text from session state
        req_text = st.session_state.current_requirement_text
        
        # Perform basic quality check first (this doesn't require API call)
        basic_quality = req_quality_checker.perform_basic_quality_checks(req_text)
        
        # Display basic checks in an expander
        with st.expander("Basic Quality Checks", expanded=True):
            if basic_quality["warnings"]:
                for warning in basic_quality["warnings"]:
                    st.warning(warning)
            else:
                st.success("No basic quality issues detected.")
            
            # Show word count
            st.info(f"Word count: {basic_quality['simple_checks'].get('word_count', 0)}")
        
        # Comprehensive quality analysis with AI
        with st.spinner("Analyzing requirement quality..."):
            quality_results = wrapped_analyze_requirement_quality(
                req_text, 
                st.session_state.current_context,
                st.session_state.api_key_input_global
            )
        
        if "error" in quality_results:
            st.error(f"Quality analysis error: {quality_results['error']}")
        else:
            # Create columns for the quality scores
            st.subheader("Quality Scores")
            
            # Get scores
            scores = quality_results.get("scores", {})
            
            # Create a progress bar for the overall score
            overall = scores.get("overall", 0)
            overall_color = "#ff5252" if overall < 4 else "#FFC107" if overall < 7 else "#4CAF50"
            
            st.markdown(f"### Overall Quality: {overall}/10")
            st.progress(overall/10, text=f"{overall}/10")
            
            # Create columns for individual metrics
            cols = st.columns(5)
            
            # Define the metrics to display
            metrics = ["clarity", "testability", "completeness", "consistency", "traceability"]
            
            # Display each metric in a column
            for i, metric in enumerate(metrics):
                score = scores.get(metric, 0)
                cols[i].metric(
                    metric.capitalize(), 
                    f"{score}/10",
                    delta=None
                )
            
            # Display analysis and suggestions
            st.subheader("Analysis & Improvement Suggestions")
            
            # Create tabs for each quality aspect
            quality_tabs = st.tabs(["Clarity", "Testability", "Completeness", "Consistency", "Traceability"])
            
            for i, metric in enumerate(metrics):
                with quality_tabs[i]:
                    # Display analysis
                    st.markdown(f"**Analysis:**")
                    st.info(quality_results.get("analysis", {}).get(metric, "No analysis available."))
                    
                    # Display suggestions
                    st.markdown(f"**Improvement Suggestions:**")
                    suggestions = quality_results.get("suggestions", {}).get(metric, [])
                    if suggestions:
                        for j, suggestion in enumerate(suggestions):
                            st.markdown(f"- {suggestion}")
                    else:
                        st.markdown("No specific suggestions available.")
        
        st.markdown("---")
        st.header("Risk Assessment Results")
        if st.session_state.similar_requirements:
            with st.expander("Similar Past Assessments Found"):
                for sim_req in st.session_state.similar_requirements:
                    meta = sim_req.get('metadata', {})
                    st.markdown(f"**ID:** `{meta.get('id')}` (Similarity: {1-sim_req.get('distance', 1):.2f})")
                    st.markdown(f"**Risk:** {meta.get('risk', 'N/A')}")
                    st.text_area(f"Requirement (similar):", value=meta.get('requirement_text', 'N/A'), height=70, disabled=True, key=f"sim_req_text_disp_{meta.get('id')}")
                    st.markdown("---")

        res = st.session_state.assessment_result
        st.subheader(f"Risk Level: {res.get('risk', 'N/A')}")
        st.markdown(f"**Reasoning:** {res.get('reasoning', 'N/A')}")
        
        # Get selected assessment coverage
        selected_assessments = st.session_state.current_context.get('assessment_coverage', [])
        
        # Helper function to check if a test type matches any selected assessment
        def test_type_is_selected(test_type):
            # Map test types to their corresponding assessment options
            test_type_mapping = {
                'Performance Testing': 'Performance Testing (Load, Stress, etc.)',
                'Load Testing': 'Performance Testing (Load, Stress, etc.)',
                'Stress Testing': 'Performance Testing (Load, Stress, etc.)',
                'Scalability Testing': 'Performance Testing (Load, Stress, etc.)',
                'Endurance Testing': 'Performance Testing (Load, Stress, etc.)',
                'Single User Performance': 'Single-user Performance Testing',
                'Single-user Performance': 'Single-user Performance Testing',
                'Device Testing': 'Device Level Testing',
                'Mobile Testing': 'Device Level Testing',
                'Browser Testing': 'Device Level Testing',
                'Accessibility': 'Accessibility',
                'Accessibility Testing': 'Accessibility',
                'Security': 'Security',
                'Security Testing': 'Security',
                'Penetration Testing': 'Security',
                'OAT': 'OAT',
                'Operational Acceptance Testing': 'OAT',
            }
            
            # If "All Non-Functional Testing" is selected, all test types are allowed
            if 'All Non-Functional Testing' in selected_assessments:
                return True
            
            # Direct match
            if test_type in selected_assessments:
                return True
            
            # Check for match using the mapping
            mapped_option = test_type_mapping.get(test_type)
            if mapped_option and mapped_option in selected_assessments:
                return True
            
            # Check for partial matches (for flexibility)
            for assessment in selected_assessments:
                if test_type.lower() in assessment.lower() or assessment.lower() in test_type.lower():
                    return True
            
            return False
            
        # Display mandatory testing requirements (filtered by selection)
        if 'mandatory_testing' in res:
            st.markdown("### 🔴 Mandatory NFT Requirements")
            mandatory_testing = res.get('mandatory_testing', {})
            
            if isinstance(mandatory_testing, dict):
                # First, check if there are any selected test types present
                has_selected_tests = False
                for test_type in mandatory_testing.keys():
                    if test_type_is_selected(test_type):
                        has_selected_tests = True
                        break
                
                if has_selected_tests:
                    for test_type, details in mandatory_testing.items():
                        # Only display test types that match the selected assessment options
                        if test_type_is_selected(test_type):
                            st.markdown(f"#### {test_type}")
                            if isinstance(details, dict):
                                for key, value in details.items():
                                    if key == 'technical_rationale':
                                        st.info(f"**Technical Rationale:** {value}")
                                    elif key == 'methodology':
                                        st.markdown(f"**Methodology:** {value}")
                                    elif key == 'success_criteria':
                                        st.markdown(f"**Success Criteria:** {value}")
                                    elif key == 'tools':
                                        tools_list = ', '.join(value) if isinstance(value, list) else value
                                        st.markdown(f"**Tools:** {tools_list}")
                                    elif key == 'timeline':
                                        st.markdown(f"**Timeline:** {value}")
                                    else:
                                        st.markdown(f"**{key.replace('_', ' ').title()}:** {value}")
                            else:
                                st.markdown(details)
                else:
                    st.info("No mandatory testing requirements for the selected assessment types.")
            else:
                # If it's not a dictionary, display the content only if there's any selection
                if selected_assessments:
                    st.markdown(mandatory_testing)
                else:
                    st.info("Please select assessment coverage options to view requirements.")
        
        # Display recommended testing strategy (filtered by selection)
        if 'recommended_testing' in res:
            st.markdown("### 🟡 Recommended NFT Strategy")
            recommended_testing = res.get('recommended_testing', {})
            
            if isinstance(recommended_testing, dict):
                # First, check if there are any selected test types present
                has_selected_tests = False
                for test_type in recommended_testing.keys():
                    if test_type_is_selected(test_type):
                        has_selected_tests = True
                        break
                
                if has_selected_tests:
                    for test_type, details in recommended_testing.items():
                        # Only display test types that match the selected assessment options
                        if test_type_is_selected(test_type):
                            st.markdown(f"#### {test_type}")
                            if isinstance(details, dict):
                                for key, value in details.items():
                                    if key == 'technical_rationale':
                                        st.info(f"**Technical Rationale:** {value}")
                                    elif key == 'methodology':
                                        st.markdown(f"**Methodology:** {value}")
                                    elif key == 'success_criteria':
                                        st.markdown(f"**Success Criteria:** {value}")
                                    elif key == 'tools':
                                        tools_list = ', '.join(value) if isinstance(value, list) else value
                                        st.markdown(f"**Tools:** {tools_list}")
                                    elif key == 'timeline':
                                        st.markdown(f"**Timeline:** {value}")
                                    else:
                                        st.markdown(f"**{key.replace('_', ' ').title()}:** {value}")
                            else:
                                st.markdown(details)
                else:
                    st.info("No recommended testing strategies for the selected assessment types.")
            else:
                # If it's not a dictionary, display the content only if there's any selection
                if selected_assessments:
                    st.markdown(recommended_testing)
                else:
                    st.info("Please select assessment coverage options to view recommendations.")
        elif 'recommendations' in res:  # Backward compatibility
            st.markdown(f"**Recommended Testing:** {res.get('recommendations', 'N/A')}")
        
        # Display component analysis with technical focus (filtered by selection)
        if 'component_analysis' in res:
            st.markdown("### 🔧 Component-Specific NFT Analysis")
            component_analysis = res.get('component_analysis', {})
            
            if isinstance(component_analysis, dict):
                # Get selected components
                selected_components = st.session_state.current_context.get('components_involved', [])
                
                # Filter components analysis to only show selected components
                has_selected_components = False
                for component in component_analysis.keys():
                    # Check if the component matches any of the selected components
                    component_match = False
                    for sel_comp in selected_components:
                        if sel_comp.lower() in component.lower() or component.lower() in sel_comp.lower():
                            component_match = True
                            break
                    
                    if component_match:
                        has_selected_components = True
                        break
                
                if has_selected_components:
                    for component, analysis in component_analysis.items():
                        # Only display components that match the selected options
                        component_match = False
                        for sel_comp in selected_components:
                            if sel_comp.lower() in component.lower() or component.lower() in sel_comp.lower():
                                component_match = True
                                break
                        
                        if component_match:
                            st.markdown(f"#### {component}")
                            if isinstance(analysis, dict):
                                # Technical focus areas
                                if 'focus_areas' in analysis:
                                    focus_areas = analysis['focus_areas']
                                    if isinstance(focus_areas, list):
                                        st.markdown("**Technical Focus Areas:**")
                                        for area in focus_areas:
                                            st.markdown(f"• {area}")
                                    else:
                                        st.markdown(f"**Technical Focus Areas:** {focus_areas}")
                                
                                # Performance benchmarks
                                if 'performance_benchmarks' in analysis:
                                    st.markdown(f"**Performance Benchmarks:** {analysis['performance_benchmarks']}")
                                
                                # Risk factors
                                if 'risk_factors' in analysis:
                                    risk_factors = analysis['risk_factors']
                                    if isinstance(risk_factors, list):
                                        st.markdown("**Risk Factors:**")
                                        for risk in risk_factors:
                                            st.markdown(f"• {risk}")
                                    else:
                                        st.markdown(f"**Risk Factors:** {risk_factors}")
                                
                                # Testing strategy
                                if 'testing_strategy' in analysis:
                                    st.markdown(f"**Testing Strategy:** {analysis['testing_strategy']}")
                                
                                # Any other fields
                                for key, value in analysis.items():
                                    if key not in ['focus_areas', 'performance_benchmarks', 'risk_factors', 'testing_strategy']:
                                        st.markdown(f"**{key.replace('_', ' ').title()}:** {value}")
                            else:
                                st.markdown(analysis)
                else:
                    st.info("No component-specific analysis for the selected components.")
            else:
                st.markdown(component_analysis)
        
        st.markdown("---")
        st.subheader("Architect Review")
        
        # Add feedback collection for learning
        with st.expander("🧠 Assessment Feedback (for AI Learning)", expanded=False):
            st.info("Help improve the AI's accuracy by providing feedback on this assessment:")
            
            col1_feedback, col2_feedback = st.columns(2)
            with col1_feedback:
                               actual_outcome = st.selectbox(
                    "What was the actual risk level?",
                    ["Select...", "High", "Medium", "Low"],
                    key="actual_outcome_feedback"
                )
            with col2_feedback:
                feedback_comments = st.text_area(
                    "Additional Comments (optional):",
                    height=100,
                    key="feedback_comments",
                    placeholder="Any insights about why the AI assessment was accurate/inaccurate..."
                )
        
        review_comment = st.text_area("Review Comments:", key="review_comment_tab1")
        
        col1_approve, col2_reject = st.columns(2)
        if col1_approve.button("Mark as Approved", key="approve_btn_tab1", use_container_width=True):
            if st.session_state.assessment_id:
                with st.spinner("Updating..."):
                    current_api_key = st.session_state.api_key_input_global
                    success = chroma_logic.update_assessment_status(chroma_logic.get_or_create_collection(current_api_key), st.session_state.assessment_id, "Approved", review_comment)
                    if success: 
                        st.success("Marked as Approved!")
                        st.session_state.assessment_result['status'] = "Approved"
                        st.session_state.assessment_result['comments'] = review_comment
                        
                        # Record feedback for learning if provided
                        if st.session_state.get("actual_outcome_feedback") != "Select...":
                            try:
                                project_type = st.session_state.current_context.get('project_type', '')
                                ai_prediction = st.session_state.assessment_result.get('risk', '')
                                actual_outcome = st.session_state.actual_outcome_feedback
                                user_comments = st.session_state.get('feedback_comments', '')
                                
                                feedback_recorded = historical_learning.record_assessment_feedback(
                                    assessment_id=st.session_state.assessment_id,
                                    requirement_text=st.session_state.current_requirement_text,
                                    ai_prediction=ai_prediction,
                                    actual_outcome=actual_outcome,
                                    user_comments=user_comments,
                                    project_type=project_type,
                                    requirement_category="NFT"
                                )
                                
                                if feedback_recorded:
                                    st.success("✅ Feedback recorded for AI learning!")
                                else:
                                    st.warning("⚠️ Could not record feedback for learning")
                            except Exception as e:
                                st.warning(f"⚠️ Feedback recording failed: {str(e)}")
                    else: 
                        st.error("Failed to update status.")
            else: 
                st.warning("No assessment ID. Run analysis first.")

        if col2_reject.button("Mark as Rejected", key="reject_btn_tab1", use_container_width=True):
            if st.session_state.assessment_id:
                with st.spinner("Updating..."):
                    current_api_key = st.session_state.api_key_input_global
                    success = chroma_logic.update_assessment_status(chroma_logic.get_or_create_collection(current_api_key), st.session_state.assessment_id, "Rejected", review_comment)
                    if success: 
                        st.success("Marked as Rejected!")
                        st.session_state.assessment_result['status'] = "Rejected"
                        st.session_state.assessment_result['comments'] = review_comment
                        
                        # Record feedback for learning if provided
                        if st.session_state.get("actual_outcome_feedback") != "Select...":
                            try:
                                project_type = st.session_state.current_context.get('project_type', '')
                                ai_prediction = st.session_state.assessment_result.get('risk', '')
                                actual_outcome = st.session_state.actual_outcome_feedback

                                user_comments = st.session_state.get('feedback_comments', '')
                                
                                feedback_recorded = historical_learning.record_assessment_feedback(
                                    assessment_id=st.session_state.assessment_id,
                                    requirement_text=st.session_state.current_requirement_text,
                                    ai_prediction=ai_prediction,
                                    actual_outcome=actual_outcome,
                                    user_comments=user_comments,
                                    project_type=project_type,
                                    requirement_category="NFT"
                                )
                                
                                if feedback_recorded:
                                    st.success("✅ Feedback recorded for AI learning!")
                                else:
                                    st.warning("⚠️ Could not record feedback for learning")
                            except Exception as e:
                                st.warning(f"⚠️ Feedback recording failed: {str(e)}")
                    else: 
                        st.error("Failed to update status.")
            else: 
                st.warning("No assessment ID. Run analysis first.")

        st.markdown("---")
        pdf_report_data = {  # Fixed missing underscore in 'pdf_report data'
            'requirement_text': st.session_state.current_requirement_text,
            'context': st.session_state.current_context, 
            **res,
            'status': st.session_state.assessment_result.get('status', 'Pending'),
            'comments': st.session_state.assessment_result.get('comments', ''),
            'timestamp': int(time.time()), 
            'id': st.session_state.assessment_id or "N/A",
            'project_name': st.session_state.current_context.get('project_name', 'N/A')
        }
        if 'approved' in pdf_report_data: 
            del pdf_report_data['approved']
        pdf_data = pdf_generator.generate_pdf_report(pdf_report_data)
        st.download_button("Download Report as PDF", pdf_data, f"assessment_{st.session_state.assessment_id or 'report'}.pdf", "application/pdf", key="download_pdf_tab1")

with tab2:
    st.header("Past Assessments")
    current_api_key_for_tab2 = st.session_state.get("api_key_input_global")  # Fixed missing opening parenthesis
    # ...existing code...
