#!/usr/bin/env python3
"""
Test script to verify the comprehensive prompt implementation works correctly.
This script tests that all the enhanced flows can properly create comprehensive prompts.
"""

import sys
import os

# Add the parent directory to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    # Test import of the intelligent assessment logic
    from core.intelligent_assessment_logic import IntelligentAssessmentDecision
    print("✓ Successfully imported IntelligentAssessmentDecision")
    
    # Test the comprehensive prompt creation method
    test_requirement = "The system should handle 1000 concurrent users with response time under 2 seconds"
    test_context = {
        'project_name': 'E-commerce Platform',
        'change_type': 'Performance Enhancement',
        'component_name': 'User Authentication Service',
        'ui_response_time': '< 2 seconds',
        'backend_volume': '1000 concurrent users'
    }
    test_app_overview = "This is a critical e-commerce platform serving millions of customers worldwide."
    test_ai_info = "Performance requirements indicate this is a high-traffic system requiring robust load testing."
    
    # Create comprehensive prompt
    prompt = IntelligentAssessmentDecision.create_comprehensive_prompt(
        requirement_text=test_requirement,
        context=test_context,
        application_overview=test_app_overview,
        ai_gathered_info=test_ai_info,
        similar_requirements=None
    )
    
    print("✓ Successfully created comprehensive prompt")
    print(f"✓ Prompt length: {len(prompt)} characters")
    
    # Verify that all information sources are included
    checks = [
        ("Requirement text", test_requirement in prompt),
        ("Application overview", test_app_overview in prompt),
        ("Context information", "E-commerce Platform" in prompt),
        ("AI gathered info", test_ai_info in prompt),
        ("Assessment framework", "ASSESSMENT FRAMEWORK" in prompt),
        ("JSON response format", "json" in prompt.lower())
    ]
    
    all_passed = True
    for check_name, result in checks:
        if result:
            print(f"✓ {check_name} included in prompt")
        else:
            print(f"✗ {check_name} NOT included in prompt")
            all_passed = False
    
    if all_passed:
        print("\n🎉 ALL TESTS PASSED! Comprehensive prompt implementation is working correctly.")
        print("\nThe enhanced implementation successfully includes:")
        print("- Application Overview integration")
        print("- Contextual information organization")
        print("- AI-gathered information inclusion")
        print("- Historical requirements analysis")
        print("- Structured assessment framework")
        print("- Comprehensive response format")
    else:
        print("\n❌ Some tests failed. Please check the implementation.")
    
except ImportError as e:
    print(f"✗ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"✗ Test error: {e}")
    sys.exit(1)
