"""
Intelligent Assessment Logic for NFT Risk Assessment Tool
Implements smart decision making for direct assessment vs question generation.
"""

import json
import datetime
import os
from typing import Dict, List, Optional, Any
from .ai_interaction_wrapper import wrapped_get_gpt_assessment

def categorize_testing_based_on_coverage(assessment_coverage: List[str]) -> tuple[List[str], List[str]]:
    """
    Categorizes testing types into mandatory and recommended based on user's Assessment Coverage selection.
    
    Args:
        assessment_coverage: List of selected assessment coverage options from the sidebar
        
    Returns:
        tuple: (mandatory_testing_types, recommended_testing_types)
    """
    # Define mapping from Assessment Coverage options to testing types
    coverage_to_testing_mapping = {
        'Performance Testing (Load, Stress, etc.)': 'Performance Testing',
        'Device Level Testing': 'Device Level Testing',
        'OAT': 'Operational Acceptance Testing',
        'Accessibility': 'Accessibility Testing',
        'Security': 'Security Testing',
        'All Non-Functional Testing': 'All Non-Functional Testing',
        # Add explicit mapping for Single-user Performance Testing 
        'Single-user Performance Testing': 'Single-user Performance Testing'
    }
    
    # Standard testing categories
    all_testing_categories = [
        'Performance Testing',
        'Operational Acceptance Testing', 
        'Single-user Performance Testing',
        'Security Testing',
        'Scalability Testing',
        'Reliability Testing',
        'Usability Testing',
        'Compatibility Testing',
        'Data Integrity Testing',
        'Integration Testing',
        'Accessibility Testing',
        'Compliance Testing',
        'Regression Testing',
        'Device Level Testing'
    ]
    
    # Convert selected coverage to testing types
    selected_testing_types = []
    for coverage in assessment_coverage:
        if coverage in coverage_to_testing_mapping:
            if coverage == 'All Non-Functional Testing':
                # If "All Non-Functional Testing" is selected, include all testing types as mandatory
                selected_testing_types = all_testing_categories.copy()
                break
            else:
                selected_testing_types.append(coverage_to_testing_mapping[coverage])
    
    # Use ONLY user-selected categories as mandatory, NO defaults
    mandatory_testing = selected_testing_types.copy()
    
    # All other testing types become recommended
    recommended_testing = [cat for cat in all_testing_categories if cat not in mandatory_testing]
    
    return mandatory_testing, recommended_testing

class IntelligentAssessmentDecision:
    """
    Intelligent system to decide whether AI can provide direct assessment 
    or needs to ask enhancement questions.
    """
    
    @staticmethod
    def analyze_information_completeness(requirement_text: str, context: Dict, application_overview: str = "") -> Dict[str, Any]:
        """
        Analyze the completeness of provided information to determine if direct assessment is possible.
        
        Args:
            requirement_text: The requirement text provided
            context: Contextual information from sidebar
            application_overview: Application overview text
            
        Returns:
            Dict containing analysis results and decision
        """
        
        # Initialize scoring system
        completeness_score = 0
        max_possible_score = 100
        missing_areas = []
        available_information = []
        
        # 1. Requirement Text Analysis (30 points max)
        req_analysis = IntelligentAssessmentDecision._analyze_requirement_text(requirement_text)
        completeness_score += req_analysis['score']
        if req_analysis['score'] < 20:
            missing_areas.extend(req_analysis['missing'])
        else:
            available_information.extend(req_analysis['available'])
        
        # 2. Application Overview Analysis (20 points max)
        app_analysis = IntelligentAssessmentDecision._analyze_application_overview(application_overview)
        completeness_score += app_analysis['score']
        if app_analysis['score'] < 15:
            missing_areas.extend(app_analysis['missing'])
        else:
            available_information.extend(app_analysis['available'])
        
        # 3. Contextual Information Analysis (50 points max)
        context_analysis = IntelligentAssessmentDecision._analyze_contextual_information(context)
        completeness_score += context_analysis['score']
        if context_analysis['score'] < 35:
            missing_areas.extend(context_analysis['missing'])
        else:
            available_information.extend(context_analysis['available'])
        
        # Calculate final percentage
        completeness_percentage = (completeness_score / max_possible_score) * 100
          # Decision Logic
        can_proceed_directly = completeness_percentage >= 65  # 65% threshold for direct assessment (more balanced)
        
        return {
            'completeness_score': completeness_score,
            'completeness_percentage': round(completeness_percentage, 1),
            'can_proceed_directly': can_proceed_directly,
            'missing_areas': missing_areas,
            'available_information': available_information,
            'decision_reason': IntelligentAssessmentDecision._get_decision_reason(
                completeness_percentage, missing_areas, can_proceed_directly
            ),
            'analysis_details': {
                'requirement_analysis': req_analysis,
                'application_analysis': app_analysis,
                'context_analysis': context_analysis
            }
        }
    
    @staticmethod
    def _analyze_requirement_text(requirement_text: str) -> Dict[str, Any]:
        """Analyze requirement text for completeness."""
        score = 0
        missing = []
        available = []
        
        if not requirement_text or len(requirement_text.strip()) < 10:
            missing.append("Detailed requirement description")
            return {'score': 0, 'missing': missing, 'available': available}
          # Word count analysis
        word_count = len(requirement_text.split())
        if word_count >= 30:
            score += 10
            available.append("Comprehensive requirement description")
        elif word_count >= 15:
            score += 7
            available.append("Adequate requirement description")
        elif word_count >= 8:
            score += 3
            available.append("Basic requirement description")
        else:
            missing.append("More detailed requirement description (minimum 8-10 words needed)")
        
        # NFR keyword analysis
        nfr_keywords = {
            'performance': ['performance', 'speed', 'response time', 'fast', 'slow', 'latency', 'throughput', 'load'],
            'security': ['security', 'authentication', 'authorization', 'encryption', 'secure', 'privacy'],
            'scalability': ['scalability', 'scale', 'users', 'concurrent', 'volume', 'capacity'],
            'availability': ['availability', 'uptime', 'downtime', '24/7', 'reliable', 'fault'],
            'integration': ['integration', 'api', 'interface', 'third-party', 'external', 'service'],
            'compliance': ['compliance', 'regulation', 'standard', 'audit', 'governance']
        }
        
        req_lower = requirement_text.lower()
        found_categories = 0
        
        for category, keywords in nfr_keywords.items():
            if any(keyword in req_lower for keyword in keywords):
                found_categories += 1
                available.append(f"{category.title()} requirements mentioned")
        
        # Score based on NFR coverage
        if found_categories >= 3:
            score += 15
        elif found_categories >= 2:
            score += 10
        elif found_categories >= 1:
            score += 5
        else:
            missing.append("Non-functional requirement categories (performance, security, etc.)")
        
        # Technical detail analysis
        technical_terms = ['system', 'application', 'database', 'server', 'network', 'infrastructure', 
                         'architecture', 'component', 'module', 'service', 'platform']
        
        if any(term in req_lower for term in technical_terms):
            score += 5
            available.append("Technical implementation details")
        else:
            missing.append("Technical implementation details")
        
        return {'score': min(score, 30), 'missing': missing, 'available': available}
    
    @staticmethod
    def _analyze_application_overview(application_overview: str) -> Dict[str, Any]:
        """Analyze application overview for completeness."""
        score = 0
        missing = []
        available = []
        
        if not application_overview or len(application_overview.strip()) < 20:
            missing.extend([
                "Application purpose and business context",
                "System architecture information", 
                "User base and usage patterns"
            ])
            return {'score': 0, 'missing': missing, 'available': available}
        
        overview_lower = application_overview.lower()
        
        # Business context
        business_keywords = ['business', 'customer', 'user', 'client', 'market', 'revenue', 'sales']
        if any(keyword in overview_lower for keyword in business_keywords):
            score += 7
            available.append("Business context and purpose")
        else:
            missing.append("Business context and purpose")
        
        # Technical architecture
        arch_keywords = ['architecture', 'microservice', 'database', 'server', 'cloud', 'platform', 'framework']
        if any(keyword in overview_lower for keyword in arch_keywords):
            score += 6
            available.append("System architecture information")
        else:
            missing.append("System architecture information")
        
        # User base/scale
        scale_keywords = ['users', 'daily', 'monthly', 'concurrent', 'volume', 'traffic', 'load']
        if any(keyword in overview_lower for keyword in scale_keywords):
            score += 7
            available.append("User base and scale information")
        else:
            missing.append("User base and scale information")
        
        return {'score': min(score, 20), 'missing': missing, 'available': available}
    
    @staticmethod
    def _analyze_contextual_information(context: Dict) -> Dict[str, Any]:
        """Analyze contextual information from sidebar for completeness."""
        score = 0
        missing = []
        available = []
        
        # Essential context fields with their importance weights
        essential_fields = {
            'project_name': {'weight': 5, 'label': 'Project identification'},
            'change_type': {'weight': 5, 'label': 'Change type classification'},
            'component_name': {'weight': 5, 'label': 'Component/application name'},
            'components_involved': {'weight': 8, 'label': 'Components involved details'},
            'customization_level': {'weight': 6, 'label': 'Customization complexity level'},
            'channel_impact': {'weight': 6, 'label': 'Channel/component impact assessment'},
            'performance_issues': {'weight': 8, 'label': 'Performance/scalability considerations'},
            'business_disruption': {'weight': 7, 'label': 'Business disruption impact'},
            'contingency_plans': {'weight': 5, 'label': 'Contingency planning details'},
            'assessment_coverage': {'weight': 5, 'label': 'Testing coverage requirements'}
        }
        
        for field, config in essential_fields.items():
            value = context.get(field, '')
            if value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...']:
                score += config['weight']
                available.append(config['label'])
            else:
                missing.append(config['label'])
        
        return {'score': min(score, 50), 'missing': missing, 'available': available}
    
    @staticmethod
    def _get_decision_reason(completeness_percentage: float, missing_areas: List[str], can_proceed: bool) -> str:
        """Generate human-readable decision reasoning."""
        if can_proceed:
            return f"Information completeness is {completeness_percentage}% which is sufficient for direct AI assessment. All critical areas are covered."
        else:
            missing_summary = ", ".join(missing_areas[:3])  # Show top 3 missing areas
            if len(missing_areas) > 3:
                missing_summary += f" and {len(missing_areas) - 3} other areas"
            return f"Information completeness is {completeness_percentage}% which requires additional information gathering. Missing: {missing_summary}."
    
    @staticmethod
    def log_ai_interaction(input_prompt: str, ai_response: str, context: Dict) -> Dict[str, Any]:
        """
        Log the AI interaction for transparency and auditing purposes.
        
        Args:
            input_prompt: The complete prompt sent to the AI
            ai_response: The complete raw response received from the AI
            context: The context information used for the assessment
            
        Returns:
            Dict containing interaction metadata
        """
        timestamp = datetime.datetime.now().isoformat()
        project_name = context.get('project_name', 'Unnamed Project')
        
        interaction_record = {
            'timestamp': timestamp,
            'project_name': project_name,
            'input_prompt_length': len(input_prompt),
            'ai_response_length': len(ai_response),
            'input_prompt': input_prompt,
            'ai_response': ai_response,
            'context_keys': list(context.keys()),
        }
        
        # Create a log directory if it doesn't exist
        log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ai_interaction_logs')
        os.makedirs(log_dir, exist_ok=True)
        
        # Save the interaction log
        filename = f"{project_name.replace(' ', '_')}_{timestamp.replace(':', '-').split('.')[0]}.json"
        filepath = os.path.join(log_dir, filename)
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(interaction_record, f, indent=2)
        except Exception as e:
            print(f"Error logging AI interaction: {e}")
        
        return {
            'log_timestamp': timestamp,
            'log_filepath': filepath,
            'interaction_id': filename.split('.')[0]
        }
    
    @staticmethod
    def create_comprehensive_prompt(requirement_text: str, context: Dict, application_overview: str = "", 
                                  ai_gathered_info: str = "", similar_requirements: Optional[List] = None) -> str:
        """
        Create a comprehensive prompt that includes ALL available information.
        
        Args:
            requirement_text: The requirement text
            context: Contextual information from sidebar
            application_overview: Application overview text
            ai_gathered_info: Information gathered through AI assistant
            similar_requirements: Similar historical requirements
            
        Returns:
            Comprehensive prompt string
        """
        
        # Get assessment coverage from context and categorize testing types
        assessment_coverage = context.get('assessment_coverage', [])
        mandatory_testing_types, recommended_testing_types = categorize_testing_based_on_coverage(assessment_coverage)
        
        # Add transparency metadata to track the request origin
        transparency_metadata = {
            "request_timestamp": datetime.datetime.now().isoformat(),
            "request_source": "NFT Risk Assessment Tool",
            "project_name": context.get('project_name', 'Unspecified'),
            "requirement_length": len(requirement_text),
            "context_fields_provided": len([k for k, v in context.items() if v]),
            "interaction_id": f"req_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        }
        
        prompt = f"""
You are an expert software risk analyst specializing in non-functional requirements assessment. Your task is to provide a comprehensive, accurate, and actionable risk assessment based on ALL the provided information.

**TRANSPARENCY METADATA:**
Request ID: {transparency_metadata['interaction_id']}
Timestamp: {transparency_metadata['request_timestamp']}
Project: {transparency_metadata['project_name']}

**CRITICAL INSTRUCTIONS:**
- Analyze ALL provided information sources comprehensively
- Provide detailed, specific analysis based on the actual requirement content and context
- Ensure all testing recommendations are practical and implementable
- Consider real-world constraints and industry best practices
- Be specific about tools, methods, and approaches
- Focus on non-functional risks that could impact system reliability, performance, security, and user experience

"""

        # Add requirement text
        prompt += f"""
**REQUIREMENT TO ANALYZE:**
```
{requirement_text}
```

"""

        # Add application overview if available
        if application_overview and application_overview.strip():
            prompt += f"""
**APPLICATION OVERVIEW:**
{application_overview}

This application background provides critical context for assessing the requirement's risk level and testing needs.

"""

        # Add contextual information from sidebar
        if context:
            prompt += "\n**CONTEXTUAL INFORMATION:**\n"
            
            # Organize context into logical groups
            context_groups = {
                'Project Information': ['project_name', 'change_type', 'application_component_name'],
                'Technical Details': ['components_involved', 'customization_level', 'channel_impact'],
                'Risk Assessment': ['performance_issues', 'business_disruption', 'contingency_plans'],
                'Testing Requirements': ['assessment_coverage'],
                'Performance Specifications': ['business_critical_volume', 'response_time_sla', 'growth_rate'],
                'Growth and Dependencies': ['infrastructure_changes', 'third_party_involvement']
            }
            
            for group_name, fields in context_groups.items():
                group_content = []
                for field in fields:
                    value = context.get(field, '')
                    if value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...']:
                        # Convert field names to readable labels
                        readable_field = field.replace('_', ' ').title()
                        if isinstance(value, list):
                            value = ', '.join(str(v) for v in value if v)
                        group_content.append(f"- **{readable_field}**: {value}")
                
                if group_content:
                    prompt += f"\n**{group_name}:**\n" + "\n".join(group_content) + "\n"
            
            # Add any other context not in predefined groups
            other_context = {k: v for k, v in context.items() 
                           if k not in [field for fields in context_groups.values() for field in fields]}
            
            if other_context:
                prompt += "\n**Additional Context:**\n"
                for key, value in other_context.items():
                    if value and str(value).strip() and str(value).lower() not in ['n/a', 'none', 'select...']:
                        readable_key = key.replace('_', ' ').title()
                        prompt += f"- **{readable_key}**: {value}\n"

        # Add AI gathered information if available
        if ai_gathered_info and ai_gathered_info.strip():
            prompt += f"""
**AI ASSISTANT GATHERED INFORMATION:**
{ai_gathered_info}

This information was collected through targeted questioning to fill knowledge gaps for comprehensive assessment.

"""

        # Add similar requirements analysis if available
        if similar_requirements:
            prompt += "\n**HISTORICAL ANALYSIS (Similar Requirements):**\n"
            for i, req in enumerate(similar_requirements[:3], 1):  # Limit to top 3
                past_meta = req.get('metadata', {})
                prompt += f"\n{i}. **Previous Assessment:**\n"
                prompt += f"   - Requirement: {past_meta.get('requirement_text', 'N/A')[:100]}...\n"
                prompt += f"   - Risk Level: {past_meta.get('risk', 'N/A')}\n"
                prompt += f"   - Key Reasoning: {past_meta.get('reasoning', 'N/A')[:200]}...\n"
                prompt += f"   - Outcome: {past_meta.get('approved', 'Unknown')}\n"
            
            prompt += "\n**Learning from History:** Use these past assessments to inform your analysis, but ensure your assessment is tailored to the current requirement's unique characteristics.\n"

        # Add assessment framework with dynamic testing categorization
        prompt += f"""

**ASSESSMENT FRAMEWORK:**

### **Risk Classification:**
Determine risk level (High/Medium/Low) based on:
- **Technical Complexity**: Integration points, performance requirements, scalability needs
- **Business Impact**: Criticality to operations, user experience implications, financial impact  
- **Implementation Challenges**: Resource requirements, timeline constraints, dependencies
- **Operational Risk**: Monitoring needs, maintenance complexity, failure scenarios

### **FINAL SCOPE ASSESSMENT:**

**MANDATORY TESTING SCOPE (Selected by User):**
{', '.join(mandatory_testing_types) if mandatory_testing_types else 'No specific testing types selected'}

**RECOMMENDED ADDITIONAL TESTING:**
{', '.join(recommended_testing_types[:5])}{"..." if len(recommended_testing_types) > 5 else ""}

### **Mandatory Testing Requirements:**
For each user-selected mandatory testing type, you MUST provide:
1. **Clear business justification** specifically linked to the requirement
2. **Specific testing methodology** with appropriate tools for this exact requirement
3. **Objective measurement criteria** tailored to this specific scenario
4. **Exact technical risks** that would be mitigated by this testing

### **Component Impact Analysis:**
Focus only on components explicitly mentioned in the requirement or context with:
1. **Component-specific risk exposure** directly tied to the requirement
2. **Testing scope specific to each component**
3. **Integration points requiring focused validation**
4. **Performance and reliability benchmarks** where applicable

**RESPONSE FORMAT:**
Provide your response in the following production-ready JSON structure with comprehensive and actionable content:

```json
{{
  "assessment_summary": {{
    "risk_level": "High|Medium|Low",
    "confidence_level": "High|Medium|Low",
    "confidence_score": 0.85,
    "executive_summary": "Concise 1-2 sentence executive summary of the assessment outcome",
    "key_risk_factors": [
      "Key risk factor 1 specific to this requirement",
      "Key risk factor 2 specific to this requirement"
    ],
    "primary_testing_focus": "The most critical testing type for this requirement"
  }},
  "risk_analysis": {{
    "technical_complexity": "High|Medium|Low",
    "business_impact": "High|Medium|Low",
    "implementation_risk": "High|Medium|Low",
    "detailed_reasoning": "Detailed analysis of why this risk level was assigned, with specific references to the requirement's characteristics, system components, and business context. Include quantifiable metrics where possible."
  }},
  "assessment_quality": {{
    "information_completeness": "High|Medium|Low",
    "context_quality": "High|Medium|Low", 
    "analysis_confidence": "Percentage (0-100) representing how confident the assessment is based on available information",
    "information_sources_used": ["requirement_text", "application_overview", "contextual_information", "ai_gathered_info"],
    "assessment_limitations": ["Any limitations in this assessment due to missing information"],
    "user_selected_coverage": {json.dumps(assessment_coverage) if assessment_coverage else "[]"}
  }},
  "mandatory_testing": {{"""

        # Dynamically generate mandatory testing structure - ONLY for user-selected testing types
        for i, testing_type in enumerate(mandatory_testing_types):
            prompt += f"""
    "{testing_type}": {{
      "rationale": "Business justification for {testing_type} specifically for this requirement",
      "methodology": "Precise {testing_type.lower()} approach with specific tools relevant to this scenario",
      "success_criteria": "Quantifiable acceptance thresholds for {testing_type.lower()} in this context",
      "tools": ["Specific Tool1", "Specific Tool2"],
      "timeline": "Realistic testing duration based on scope",
      "risk_coverage": "Exact technical risks mitigated by this testing"
    }}"""
            if i < len(mandatory_testing_types) - 1:
                prompt += ","

        prompt += """
  },
  "recommended_testing": {"""

        # Dynamically generate recommended testing structure - Only for non-selected testing types
        for i, testing_type in enumerate(recommended_testing_types[:5]):
            prompt += f"""
    "{testing_type}": {{
      "priority": "Critical|Important|Nice-to-have",
      "justification": "Why this additional testing would provide value for this specific requirement",
      "approach": "Brief description of necessary {testing_type.lower()} methodology for this scenario",
      "tools": ["Relevant Tool1", "Relevant Tool2"],
      "risk_mitigation": "Specific unaddressed risks that this testing would cover"
    }}"""
            if i < min(len(recommended_testing_types), 5) - 1:
                prompt += ","

        prompt += """
  },
  "component_analysis": {
    "ComponentName": {
      "risk_exposure": "High|Medium|Low",
      "risks": ["Specific technical risk related to this requirement", "Another specific risk"],
      "testing_focus": "Targeted testing approach for this component",
      "success_criteria": "Component-specific acceptance criteria"
    }
  },
  "final_recommendations": {{
    "critical_actions": [
      "Most important action required for successful delivery"
    ],
    "testing_recommendations": [
      "Specific, actionable testing recommendation"
    ],
    "risk_mitigation": [
      "Specific risk mitigation strategy"
    ],
    "monitoring_requirements": [
      "Post-implementation monitoring requirement"
    ]
  }},
  "approval_guidance": {{
    "recommended_decision": "Approve|Approve with conditions|Further review needed|Reject",
    "decision_justification": "Reasoning behind the recommended approval decision",
    "conditions": [
      "Specific condition that should be met before approval" 
    ]
  }}
}
```

**PRODUCTION QUALITY REQUIREMENTS:**
- Every assessment must be actionable for stakeholders with clear recommendations
- The confidence_score (0-1.0) represents your level of certainty in the assessment based on information quality
- Confidence_level (High: >0.8, Medium: 0.5-0.8, Low: <0.5) is derived from confidence_score
- Every mandatory testing type must have concrete, measurable success criteria
- All risk analysis must reference specific technologies, components, and business impacts
- Focus on providing decision-makers with clear approval guidance backed by technical evidence
- All assessment recommendations must follow software engineering best practices

**CRITICAL INSTRUCTION:**
The MANDATORY TESTING section must contain ONLY the testing types explicitly selected by the user: {str(assessment_coverage)}
All other potentially relevant testing types should be placed in the RECOMMENDED TESTING section.
The final assessment must be business-focused and provide clear guidance for decision-makers.
"""

        # Detect technology components in requirement text
        detected_components = IntelligentAssessmentDecision.detect_technology_components(requirement_text)
        
        # Add detected technology components if found
        if detected_components:
            prompt += "\n**DETECTED TECHNOLOGY COMPONENTS:**\n"
            for category, technologies in detected_components.items():
                prompt += f"- **{category}**: {', '.join(technologies)}\n"
            
            prompt += "\nThese technology components were automatically detected in the requirement and should be specifically addressed in your assessment.\n"

        return prompt
    
    @staticmethod
    def detect_technology_components(text: str) -> Dict[str, List[str]]:
        """
        Detects specific technology components mentioned in the requirement text.
        
        Args:
            text: The requirement text to analyze
            
        Returns:
            Dictionary with component categories and detected technologies
        """
        text_lower = text.lower()
        
        # Define technology components to detect
        component_categories = {
            'Cloud Platforms': {
                'Azure': ['azure', 'microsoft azure', 'azure cloud', 'azure ad', 'azure active directory'],
                'AWS': ['aws', 'amazon web services', 'amazon cloud', 'ec2', 's3', 'lambda'],
                'Google Cloud': ['google cloud', 'gcp', 'google cloud platform']
            },
            'API Management': {
                'Azure API Management': ['azure api management', 'apim', 'api gateway', 'api management'],
                'AWS API Gateway': ['aws api gateway', 'amazon api gateway'],
                'Kong': ['kong', 'kong gateway']
            },
            'CRM Systems': {
                'Dynamics 365': ['dynamics', 'dynamics 365', 'dynamics crm', 'microsoft dynamics'],
                'Salesforce': ['salesforce', 'salesforce crm'],
                'SAP': ['sap', 'sap crm', 'sap db']
            },
            'Databases': {
                'SQL Server': ['sql server', 'mssql', 'microsoft sql'],
                'Oracle': ['oracle', 'oracle db', 'oracle database'],
                'MongoDB': ['mongodb', 'mongo'],
                'CosmosDB': ['cosmosdb', 'cosmos db', 'azure cosmos']
            },
            'Mobile Technologies': {
                'Android': ['android'],
                'iOS': ['ios', 'iphone', 'ipad'],
                'React Native': ['react native'],
                'Flutter': ['flutter']
            },
            'Integration Services': {
                'Azure Logic Apps': ['logic apps', 'azure logic'],
                'Azure Service Bus': ['service bus'],
                'MuleSoft': ['mulesoft'],
                'Azure Event Hub': ['event hub', 'eventhub']
            }
        }
        
        # Detect components
        detected_components = {}
        
        for category, technologies in component_categories.items():
            category_matches = []
            
            for tech_name, keywords in technologies.items():
                if any(keyword in text_lower for keyword in keywords):
                    category_matches.append(tech_name)
            
            if category_matches:
                detected_components[category] = category_matches
        
        return detected_components
